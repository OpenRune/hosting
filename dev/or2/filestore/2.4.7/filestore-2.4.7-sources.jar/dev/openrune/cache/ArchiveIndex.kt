package dev.openrune.cache

const val ANIMATIONS = 0
const val SKELETONS = 1
const val CONFIGS = 2
const val INTERFACES = 3
const val SOUNDEFFECTS = 4
const val MAPS = 5
const val MUSIC_TRACKS = 6
const val MODELS = 7
const val SPRITES = 8
const val TEXTURES = 9
const val BINARY = 10
const val MUSIC_JINGLES = 11
const val CLIENTSCRIPT = 12
const val FONTS = 13
const val MUSIC_SAMPLES = 14
const val MUSIC_PATCHES = 15
const val NOT_USED = 16
const val DEFAULTS = 17
const val WORLDMAP_GEOGRAPHY = 18
const val WORLDMAPAREAS = 19
const val WORLDMAP_GROUND = 20
const val DBTABLEINDEX = 21
const val ANIMAYAS = 22
const val INTERFACES2 = 23
const val GAMEVALS = 24
const val MODELSRT7 = 25