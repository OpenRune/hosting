package dev.openrune.definition

import io.netty.buffer.ByteBuf

/**
 * Abstraction over a cache backend that can stream file data from
 * archive/group containers without exposing the underlying implementation
 * (e.g. JS5, disk layout, etc.).
 *
 * The cache is modelled as:
 * - An **archive** (commonly called an "index"), identified by [archiveId].
 * - A set of **groups** inside each archive, identified by [groupId].
 * - A set of **files** inside each group, identified by [fileId].
 *
 * Implementations are expected to:
 * - Load the requested archive/group lazily as needed.
 * - Provide file contents via [ByteBuf] instances.
 *
 * ### ByteBuf contract
 *
 * For all callbacks in this interface:
 * - The [ByteBuf] passed to the callback is only guaranteed to be valid for the
 *   duration of that callback invocation.
 * - Callers **must not** store or `release()` the buffer.
 * - If a caller needs to keep the buffer beyond the callback, it should call
 *   `retain()` and then manage the buffer’s lifecycle itself (including releasing it).
 */
interface ArchiveIterator {

    /**
     * Iterates over every file in a specific group within an archive.
     *
     * @param archiveId The cache archive to load. This is commonly called an "index". A valid of 2, holds the configs.
     * @param groupId The group within the archive whose files should be iterated. Some old tools called this archive.
     * @param block Callback invoked for each file in the group.
     * The [fileId] is the file identifier within the group, and [data] is the file contents.
     *
     * The [data] buffer is only guaranteed to be valid for the duration of [block].
     * Callers **must not** store or release the buffer. If long-term use is required,
     * callers should explicitly `retain()` the buffer and manage its lifecycle.
     */
    fun forEachFileInGroup(archiveId: Int, groupId: Int, block: (fileId: Int, data: ByteBuf) -> Unit)

    /**
     * Iterates over all groups within an archive and provides a way to iterate
     * the files of each group.
     *
     * @param archiveId The cache archive to load. This is commonly called an "index". A valid of 2, holds the configs.
     * @param block Callback invoked once per group. [groupId] is the group identifier.
     * The [groupFiles] function, when called, will iterate over all files in that group
     * and invoke [fileBlock] for each one.
     *
     * The [data] buffer passed to [fileBlock] is only guaranteed to be valid for the
     * duration of the callback. Callers **must not** store or release the buffer.
     * If long-term use is required, callers should explicitly `retain()` the buffer and
     * manage its lifecycle.
     */
    fun forEachGroup(archiveId: Int, block: (groupId: Int, groupFiles: (fileBlock: (fileId: Int, data: ByteBuf) -> Unit) -> Unit) -> Unit)
}