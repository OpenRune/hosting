package dev.openrune.definition.util

import dev.openrune.definition.Definition
import kotlin.reflect.KClass

private val VALID_REGEX = Regex("^[a-z0-9-:_.]*$")

private fun String.isValid() = VALID_REGEX.matches(this)

open class TypeList<T : Definition>(
    public val name: String,
    val typeClass: KClass<T>,
    private val types: MutableMap<Int, T> = mutableMapOf(),
    private val namedTypes: MutableMap<String, T> = mutableMapOf()
) : Iterable<T> {

    private var maxId = -1

    val size: Int
        get() = maxId + 1

    fun add(type: T) {
        if (types.containsKey(type.id)) {
            error("Index already exists for this TypeList (index=${type.id}, type=$name).")
        }
        this[type.id] = type
    }

    fun getOrNull(id: Int): T? {
        return types[id]
    }

    operator fun get(id: Int): T = getOrNull(id) ?: error("Missing $name type (id=$id).")

    operator fun set(id: Int, type: T) {
        maxId = maxId.coerceAtLeast(id)
        types[id] = type
    }

    fun containsKey(key: Int): Boolean {
        return types.containsKey(key)
    }

    fun containsValue(value: T): Boolean {
        return types.containsValue(value)
    }

    override fun iterator(): Iterator<T> {
        return types.values.iterator()
    }

    operator fun get(key: String): T? {
        key.validate()
        return namedTypes[key]
    }

    operator fun set(key: String, type: T) {
        key.validate()
        namedTypes[key] = type
    }

    private fun String.validate() {
        if (!isValid()) {
            error("Name \"$this\" must be lowercase alphanumeric '_' instead of spaces. : is also allowed for subtypes")
        }
    }

    fun getValue(key: String): T {
        val value = namedTypes[key]
        if (value == null && !namedTypes.containsKey(key)) {
            error("Key $key is missing in the map.")
        } else {
            return value as T
        }
    }

    fun populateTypes(
        mappings: Map<String, Map<String, Int>>
    ) {
        for ((name, id) in mappings[name].orEmpty()) {
            this[name] = this[id]
        }
    }

    companion object {
        inline fun <reified T : Definition> create(name: String): TypeList<T> = TypeList(name, T::class)
    }
}