package dev.openrune.cache.worldmap.worldmap.builder.blocks

import dev.openrune.cache.util.logger
import dev.openrune.cache.worldmap.worldmap.MapsquareMultiSection
import dev.openrune.cache.worldmap.worldmap.WorldMapMapsquare
import dev.openrune.cache.worldmap.worldmap.providers.MapProvider
import dev.openrune.cache.worldmap.worldmap.providers.ObjectProvider
import dev.openrune.filesystem.Cache

/**
 * @author Kris | 21/08/2022
 */
class WorldMapMultiMapsquareBuilder(val cache : Cache, private val section: MapsquareMultiSection) : WorldMapBlockBuilder<WorldMapMapsquare> {
    override fun build(mapProvider: MapProvider, objectProvider: ObjectProvider): List<WorldMapMapsquare> {
        val initial = (section.mapsquareSourceMaxX.inc() - section.mapsquareSourceMinX) * (section.mapsquareSourceMaxY.inc() - section.mapsquareSourceMinY)
        val list = ArrayList<WorldMapMapsquare>(initial)
        for (x in section.mapsquareSourceMinX..section.mapsquareSourceMaxX) {
            for (y in section.mapsquareSourceMinY..section.mapsquareSourceMaxY) {
                val mapsquare = try {
                    generateMapsquare(
                        cache,
                        mapProvider,
                        objectProvider,
                        section.level,
                        section.levelsCount,
                        x,
                        y,
                        section.mapsquareDestinationMinX + (x - section.mapsquareSourceMinX),
                        section.mapsquareDestinationMinY + (y - section.mapsquareSourceMinY),
                    )
                } catch (e: Exception) {
                    logger.warn { "Failed to build world map mapsquare $x,$y: $e" }
                    null
                }
                if (mapsquare != null) list += mapsquare
            }
        }
        return list
    }
}
