package dev.openrune.cache

import dev.openrune.cache.gameval.GameValHandler
import dev.openrune.cache.tools.Builder
import dev.openrune.cache.tools.tasks.CacheTask
import dev.openrune.cache.tools.tasks.TaskType
import dev.openrune.cache.tools.tasks.impl.defs.PackConfig
import dev.openrune.definition.GameValGroupTypes
import dev.openrune.filesystem.Cache
import java.io.File
import kotlin.io.path.Path
import kotlin.system.exitProcess

fun main(args : Array<String>) {
    val cache = Cache.load(Path("D:\\OpenRune\\OpenRune-WebServer\\cache\\oldschool\\live\\237\\data\\cache"))
    GameValHandler.readGameVal(GameValGroupTypes.VARCS, cache,237).forEach {
        println(it.name)
    }
}