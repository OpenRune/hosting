package dev.openrune.cache

import dev.openrune.OsrsCacheProvider
import dev.openrune.cache.tools.Builder
import dev.openrune.cache.tools.tasks.CacheTask
import dev.openrune.cache.tools.tasks.TaskType
import dev.openrune.cache.tools.tasks.impl.defs.PackConfig
import dev.openrune.filesystem.Cache
import java.io.File
import kotlin.system.exitProcess

fun getCacheLocation() = File("./data/","cache").path
fun getRawCacheLocation(dir : String) = File("./data/","raw-cache/$dir/")

fun main(args : Array<String>) {


     Builder(type = TaskType.FRESH_INSTALL, File(getCacheLocation())).revision(239).build().initialize()
    val cache = Cache.load(File("./data/","cache").toPath())
    OsrsCacheProvider(cache,239)
}