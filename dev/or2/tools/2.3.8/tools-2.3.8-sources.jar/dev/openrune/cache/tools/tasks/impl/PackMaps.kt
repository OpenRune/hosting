package dev.openrune.cache.tools.tasks.impl

import com.google.gson.GsonBuilder
import dev.openrune.cache.MAPS
import dev.openrune.cache.util.XteaLoader
import dev.openrune.cache.util.logger
import dev.openrune.cache.tools.tasks.CacheTask
import dev.openrune.cache.util.decompressGzipToBytes
import dev.openrune.cache.util.getFiles
import dev.openrune.cache.util.progress
import dev.openrune.filesystem.Cache
import java.io.File
import java.nio.file.Files
import kotlin.random.Random

enum class XteaType {
    NO_KEYS,
    EMPTY_KEYS,
    RANDOM_KEYS
}

class PackMaps(private val mapsDirectory: File, private val xteaLocation: File = File("xteas.json"), private val xteaType: XteaType = XteaType.NO_KEYS) : CacheTask() {
    override fun init(cache: Cache) {
        val supportsMapXteas = revision < 237
        if (!supportsMapXteas && xteaType != XteaType.NO_KEYS) {
            error("XTEA map packing is deprecated on revision 237+. Use XteaType.NO_KEYS for PackMaps.")
        }
        val encodeXteas = supportsMapXteas && xteaType != XteaType.NO_KEYS

        if (encodeXteas && !xteaLocation.exists()) {
            logger.info { "Unable to find Xteas File at $xteaLocation" }
            return
        } else if (encodeXteas) {
            XteaLoader.load(xteaLocation)
        }

        val mapSize = getFiles(mapsDirectory,"gz","dat").size
        val progressMaps = progress("Packing Maps", mapSize)
        if (mapSize != 0) {
            getFiles(mapsDirectory,"gz","dat").filter { it.name.startsWith("l") }.forEach { mapFile ->

                if (mapFile.name.first().toString() == "l") {


                    val objectFile = File(mapFile.parent,mapFile.name.replaceFirstChar { "m" })

                    if (objectFile.exists()) {

                        val loc = mapFile.nameWithoutExtension.replace(
                            "m",""
                        ).replace("l","").split("_")

                        val regionId = loc[0].toInt() shl 8 or loc[1].toInt()

                        var tileData = Files.readAllBytes(mapFile.toPath())
                        var objData = Files.readAllBytes(objectFile.toPath())

                        if (mapFile.name.endsWith(".gz")) {
                            tileData = decompressGzipToBytes(mapFile.toPath())
                        }
                        if (objectFile.name.endsWith(".gz")) {
                            objData = decompressGzipToBytes(objectFile.toPath())
                        }

                        val keys : IntArray? = when(xteaType) {
                            XteaType.NO_KEYS -> null
                            XteaType.EMPTY_KEYS -> intArrayOf(0,0,0,0)
                            XteaType.RANDOM_KEYS -> generateRandomIntArray()
                        }

                        if (encodeXteas && keys != null) {
                            XteaLoader.xteas[regionId]!!.key = keys
                        }

                        packMap(cache,loc[0].toInt(), loc[1].toInt(), tileData, objData, if (encodeXteas) keys else null)
                    } else {
                        println("MISSING MAP FILE: $objectFile")
                    }

                }

                progressMaps.stepBy(2)

            }

            if (encodeXteas) {
                val valuesList = XteaLoader.xteas.values.toList()
                xteaLocation.writeText(GsonBuilder().setPrettyPrinting().create().toJson(valuesList))
            }
            progressMaps.close()
        }
    }

    fun packMap(cache: Cache, regionX : Int, regionY : Int, tileData : ByteArray, objData : ByteArray, keys : IntArray?) {
        if (revision < 237) {
            val mapArchiveName = "m" + regionX + "_" + regionY
            val landArchiveName = "l" + regionX + "_" + regionY

            cache.write(MAPS, mapArchiveName, tileData)
            cache.write(MAPS, landArchiveName, objData, keys)
        } else {
            val groupId = (regionX shl 8) or (regionY and 0xFF)
            cache.write(MAPS, groupId, 0, tileData)
            cache.write(MAPS, groupId, 1, objData)
        }
    }

    fun generateRandomIntArray(): IntArray {
        return IntArray(4) { Random.nextInt(Int.MIN_VALUE, Int.MAX_VALUE) }
    }

}