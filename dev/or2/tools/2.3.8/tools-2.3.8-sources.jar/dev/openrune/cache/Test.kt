package dev.openrune.cache

import dev.openrune.OsrsCacheProvider
import dev.openrune.cache.filestore.definition.ModelDecoder
import dev.openrune.cache.gameval.GameValHandler
import dev.openrune.cache.gameval.GameValHandler.elementAs
import dev.openrune.cache.gameval.impl.Interface
import dev.openrune.cache.tools.Builder
import dev.openrune.cache.tools.tasks.CacheTask
import dev.openrune.cache.tools.tasks.TaskType
import dev.openrune.cache.tools.tasks.impl.defs.PackConfig
import dev.openrune.definition.GameValGroupTypes
import dev.openrune.definition.GameValGroupTypes.TABLETYPES
import dev.openrune.definition.codec.InventoryCodec
import dev.openrune.definition.type.InventoryType
import dev.openrune.definition.type.SequenceType
import dev.openrune.definition.type.SpotAnimType
import dev.openrune.filesystem.Cache
import java.io.File
import java.nio.file.Path
import java.util.Arrays


fun main() {

    //val builder = Builder(type = TaskType.FRESH_INSTALL, revision = 232, File("C:\\Users\\Home\\Desktop\\New folder"))
    //builder.extraTasks().build().initialize()

    val cache = Cache.load(Path.of("C:\\Users\\chris\\Desktop\\cache-oldschool-live-en-b237-2026-03-25-11-45-05-openrs2#2504\\cache"))

    CacheManager.init(OsrsCacheProvider(cache,237))


    val data : MutableMap<Int, InventoryType> = emptyMap<Int, InventoryType>().toMutableMap()
    OsrsCacheProvider.InventoryDecoder().load(cache,data)


}