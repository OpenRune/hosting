package dev.openrune.cache.util


import dev.openrune.OsrsCacheProvider
import dev.openrune.cache.gameval.GameValHandler
import dev.openrune.cache.gameval.GameValHandler.lookup
import dev.openrune.definition.GameValGroupTypes
import dev.openrune.definition.type.MapElementType
import dev.openrune.filesystem.Cache
import java.io.File

import com.google.gson.GsonBuilder
import dev.openrune.cache.CacheManager
import dev.openrune.cache.gameval.GameValElement
import dev.openrune.definition.type.EnumType

data class MapIconGroup(
    val category: String?,
    val categoryID: Int,
    val mapId: Int
)

fun orderCategoriesByPriorityAndSize(categoryMap: Map<String, List<Int>>): List<String> {
    val stores = listOf("store", "shop")

    val nonStores = categoryMap.keys
        .filter { stores.none { s -> it.lowercase().contains(s) } }
        .sortedBy { it.lowercase() } // alphabetical

    val storeCats = categoryMap.keys
        .filter { stores.any { s -> it.lowercase().contains(s) } }
        .sortedBy { it.lowercase() } // alphabetical, but at the end

    return nonStores + storeCats
}

fun main() {
    val cache = Cache.load(File("C:\\Users\\Home\\Desktop\\Alter-feature-support-231\\Alter-feature-support-231\\data\\cache").toPath())
    CacheManager.init(OsrsCacheProvider(cache,234))

    val area: MutableMap<Int, MapElementType> = mutableMapOf()
    val enum: MutableMap<Int, EnumType> = mutableMapOf()
    val objectGameVals = GameValHandler.readGameVal(GameValGroupTypes.LOCTYPES, cache)
    OsrsCacheProvider.AreaDecoder().load(cache, area)
    OsrsCacheProvider.EnumDecoder().load(cache, enum)

    writeMapFunctionData(objectGameVals,area,enum)


}



fun writeMapFunctionData(
    objectGameVals: List<GameValElement>,
    area: MutableMap<Int, MapElementType>,
    enum: MutableMap<Int, EnumType>
) {
    val objectsByMapArea = CacheManager.getObjects()
        .asSequence()
        .filterNot { it.value.mapAreaId == -1 }
        .groupBy { it.value.mapAreaId }

    data class CategoryEntry(
        val mapId: Int,
        val categoryID: Int,
        val objectIds: MutableList<Int>,
        var customName: String? = null
    )

    val categoryMap = mutableMapOf<String, CategoryEntry>()
    val realNameEnum = enum[1713]!!

    val transportRegex = Regex(
        "^(Transportation\\s+[A-Za-z]{1,3}|transportation_icon_[a-z]+)$",
        RegexOption.IGNORE_CASE
    )

    objectsByMapArea.forEach { (mapId, entries) ->
        val areaType = area[mapId] ?: return@forEach
        if (!areaType.renderOnMinimap) return@forEach

        val defaultName = realNameEnum.values[areaType.category.toString()]?.toString() ?: "Unknown"
        var categoryName = defaultName
        var customName: String? = null

        val firstObjectName = entries.mapNotNull { objectGameVals.lookup(it.key)?.name }
            .firstOrNull { it.isNotBlank() }

        if (firstObjectName != null) {
            when {
                firstObjectName.contains("Tutor", ignoreCase = true) -> {
                    categoryName = "Tutors"
                    customName = categoryName
                }
                transportRegex.matches(firstObjectName) -> {
                    categoryName = "Fairy Rings"
                    customName = categoryName
                }
            }
        }

        val entry = categoryMap.getOrPut(categoryName) {
            CategoryEntry(mapId, areaType.category, mutableListOf(), customName)
        }
        entry.objectIds.addAll(entries.map { it.key })
    }

    val finalCategories = orderCategoriesByPriorityAndSize(categoryMap.mapValues { it.value.objectIds })

    val result = finalCategories.map { cat ->
        val entry = categoryMap[cat]!!
        // only assign name if it's custom
        if (entry.customName != null) {
            MapIconGroup(entry.customName!!, entry.categoryID, entry.mapId)
        } else {
            MapIconGroup(null, entry.categoryID, entry.mapId)
        }
    }

    val gson = GsonBuilder().setPrettyPrinting().create()
    println(gson.toJson(result))
}