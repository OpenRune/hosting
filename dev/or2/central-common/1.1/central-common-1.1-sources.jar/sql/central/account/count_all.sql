SELECT COUNT(*) FROM accounts
