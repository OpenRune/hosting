SELECT COUNT(*) FROM sessions
