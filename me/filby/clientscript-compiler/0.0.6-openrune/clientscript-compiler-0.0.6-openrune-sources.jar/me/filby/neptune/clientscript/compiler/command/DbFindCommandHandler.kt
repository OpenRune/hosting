package me.filby.neptune.clientscript.compiler.command

import me.filby.neptune.clientscript.compiler.type.DbColumnType
import me.filby.neptune.clientscript.compiler.type.ScriptVarType
import me.filby.neptune.runescript.compiler.codegen.Opcode
import me.filby.neptune.runescript.compiler.configuration.command.CodeGeneratorContext
import me.filby.neptune.runescript.compiler.configuration.command.DynamicCommandHandler
import me.filby.neptune.runescript.compiler.configuration.command.TypeCheckingContext
import me.filby.neptune.runescript.compiler.type
import me.filby.neptune.runescript.compiler.type.MetaType
import me.filby.neptune.runescript.compiler.type.TupleType

class DbFindCommandHandler(private val withCount: Boolean) : DynamicCommandHandler {
    override fun TypeCheckingContext.typeCheck() {
        // lookup the column expression
        val columnExpr = checkArgument(0, DbColumnType(MetaType.Any))

        // typehint the second argument using the dbcolumn type if it was valid
        val keyType = (columnExpr?.type as? DbColumnType)?.inner
        checkArgument(1, keyType)

        // define the expected types based on what is currently known
        val expectedTypes = TupleType(
            DbColumnType(keyType ?: MetaType.Any),
            keyType ?: MetaType.Any,
        )

        // check that the key type is not a tuple type
        if (keyType is TupleType) {
            columnExpr.reportError(diagnostics, "Tuple columns are not supported.")
        } else {
            // compare the expected types with the actual types
            checkArgumentTypes(expectedTypes)
        }

        // set the return type
        expression.type = if (withCount) ScriptVarType.INT else MetaType.Unit
    }

    override fun CodeGeneratorContext.generateCode() {
        // should not get to this point unless first argument is a dbcolumn
        val columnType = (expression.arguments[0].type as DbColumnType).inner
        val stackType = checkNotNull(columnType.baseType)

        // emit the arguments
        expression.arguments.visit()

        // emit the stack type to pop the key value from
        instruction(Opcode.PushConstantInt, stackType.id)

        // emit the command
        command()
    }
}
