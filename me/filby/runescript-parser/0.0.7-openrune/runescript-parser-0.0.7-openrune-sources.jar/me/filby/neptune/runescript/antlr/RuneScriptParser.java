// Generated from C:\Users\home\Desktop\Programming\Rsps\OpenRune\neptune\runescript-parser\src\main\antlr\RuneScriptParser.g4 by ANTLR 4.10.1
package me.filby.neptune.runescript.antlr;
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public class RuneScriptParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.10.1", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		LPAREN=1, RPAREN=2, COLON=3, SEMICOLON=4, COMMA=5, LBRACK=6, RBRACK=7, 
		LBRACE=8, RBRACE=9, PLUS=10, MINUS=11, MUL=12, DIV=13, MOD=14, AND=15, 
		OR=16, EQ=17, EXCL=18, DOLLAR=19, CARET=20, TILDE=21, AT=22, GT=23, GTE=24, 
		LT=25, LTE=26, INCREMENT=27, DECREMENT=28, IF=29, ELSE=30, WHILE=31, CASE=32, 
		DEFAULT=33, RETURN=34, CALC=35, DEF_TYPE=36, SWITCH_TYPE=37, INTEGER_LITERAL=38, 
		HEX_LITERAL=39, COORD_LITERAL=40, BOOLEAN_LITERAL=41, CHAR_LITERAL=42, 
		NULL_LITERAL=43, LINE_COMMENT=44, BLOCK_COMMENT=45, QUOTE_OPEN=46, IDENTIFIER=47, 
		WHITESPACE=48, QUOTE_CLOSE=49, STRING_TEXT=50, STRING_TAG=51, STRING_CLOSE_TAG=52, 
		STRING_PARTIAL_TAG=53, STRING_P_TAG=54, STRING_SWITCH_TAG=55, STRING_EXPR_START=56, 
		STRING_EXPR_END=57, STRING_TEMPLATE=58;
	public static final int
		RULE_scriptFile = 0, RULE_script = 1, RULE_parameterList = 2, RULE_parameter = 3, 
		RULE_typeList = 4, RULE_statement = 5, RULE_blockStatement = 6, RULE_returnStatement = 7, 
		RULE_ifStatement = 8, RULE_whileStatement = 9, RULE_switchStatement = 10, 
		RULE_switchCase = 11, RULE_declarationStatement = 12, RULE_arrayDeclarationStatement = 13, 
		RULE_assignmentStatement = 14, RULE_expressionStatement = 15, RULE_emptyStatement = 16, 
		RULE_expressionList = 17, RULE_parenthesis = 18, RULE_singleExpression = 19, 
		RULE_expression = 20, RULE_condition = 21, RULE_calc = 22, RULE_arithmetic = 23, 
		RULE_call = 24, RULE_clientScript = 25, RULE_assignableVariableList = 26, 
		RULE_assignableVariable = 27, RULE_localVariable = 28, RULE_localArrayVariable = 29, 
		RULE_gameVariable = 30, RULE_constantVariable = 31, RULE_literal = 32, 
		RULE_stringLiteral = 33, RULE_stringLiteralContent = 34, RULE_joinedString = 35, 
		RULE_stringTag = 36, RULE_stringPTag = 37, RULE_stringSwitchTag = 38, 
		RULE_stringTemplate = 39, RULE_stringExpression = 40, RULE_identifier = 41, 
		RULE_advancedIdentifier = 42;
	private static String[] makeRuleNames() {
		return new String[] {
			"scriptFile", "script", "parameterList", "parameter", "typeList", "statement", 
			"blockStatement", "returnStatement", "ifStatement", "whileStatement", 
			"switchStatement", "switchCase", "declarationStatement", "arrayDeclarationStatement", 
			"assignmentStatement", "expressionStatement", "emptyStatement", "expressionList", 
			"parenthesis", "singleExpression", "expression", "condition", "calc", 
			"arithmetic", "call", "clientScript", "assignableVariableList", "assignableVariable", 
			"localVariable", "localArrayVariable", "gameVariable", "constantVariable", 
			"literal", "stringLiteral", "stringLiteralContent", "joinedString", "stringTag", 
			"stringPTag", "stringSwitchTag", "stringTemplate", "stringExpression", 
			"identifier", "advancedIdentifier"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, "'('", "')'", "':'", "';'", "','", "'['", "']'", "'{'", "'}'", 
			"'+'", "'-'", "'*'", "'/'", "'%'", "'&'", "'|'", "'='", "'!'", "'$'", 
			"'^'", "'~'", "'@'", null, "'>='", null, "'<='", "'++'", "'--'", "'if'", 
			"'else'", "'while'", "'case'", "'default'", "'return'", "'calc'", null, 
			null, null, null, null, null, null, "'null'"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, "LPAREN", "RPAREN", "COLON", "SEMICOLON", "COMMA", "LBRACK", "RBRACK", 
			"LBRACE", "RBRACE", "PLUS", "MINUS", "MUL", "DIV", "MOD", "AND", "OR", 
			"EQ", "EXCL", "DOLLAR", "CARET", "TILDE", "AT", "GT", "GTE", "LT", "LTE", 
			"INCREMENT", "DECREMENT", "IF", "ELSE", "WHILE", "CASE", "DEFAULT", "RETURN", 
			"CALC", "DEF_TYPE", "SWITCH_TYPE", "INTEGER_LITERAL", "HEX_LITERAL", 
			"COORD_LITERAL", "BOOLEAN_LITERAL", "CHAR_LITERAL", "NULL_LITERAL", "LINE_COMMENT", 
			"BLOCK_COMMENT", "QUOTE_OPEN", "IDENTIFIER", "WHITESPACE", "QUOTE_CLOSE", 
			"STRING_TEXT", "STRING_TAG", "STRING_CLOSE_TAG", "STRING_PARTIAL_TAG", 
			"STRING_P_TAG", "STRING_SWITCH_TAG", "STRING_EXPR_START", "STRING_EXPR_END", 
			"STRING_TEMPLATE"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "RuneScriptParser.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public RuneScriptParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	public static class ScriptFileContext extends ParserRuleContext {
		public TerminalNode EOF() { return getToken(RuneScriptParser.EOF, 0); }
		public List<ScriptContext> script() {
			return getRuleContexts(ScriptContext.class);
		}
		public ScriptContext script(int i) {
			return getRuleContext(ScriptContext.class,i);
		}
		public ScriptFileContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_scriptFile; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitScriptFile(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ScriptFileContext scriptFile() throws RecognitionException {
		ScriptFileContext _localctx = new ScriptFileContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_scriptFile);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(89);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==LBRACK) {
				{
				{
				setState(86);
				script();
				}
				}
				setState(91);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(92);
			match(EOF);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ScriptContext extends ParserRuleContext {
		public IdentifierContext trigger;
		public IdentifierContext name;
		public TerminalNode LBRACK() { return getToken(RuneScriptParser.LBRACK, 0); }
		public TerminalNode COMMA() { return getToken(RuneScriptParser.COMMA, 0); }
		public TerminalNode RBRACK() { return getToken(RuneScriptParser.RBRACK, 0); }
		public List<IdentifierContext> identifier() {
			return getRuleContexts(IdentifierContext.class);
		}
		public IdentifierContext identifier(int i) {
			return getRuleContext(IdentifierContext.class,i);
		}
		public TerminalNode MUL() { return getToken(RuneScriptParser.MUL, 0); }
		public List<StatementContext> statement() {
			return getRuleContexts(StatementContext.class);
		}
		public StatementContext statement(int i) {
			return getRuleContext(StatementContext.class,i);
		}
		public List<TerminalNode> LPAREN() { return getTokens(RuneScriptParser.LPAREN); }
		public TerminalNode LPAREN(int i) {
			return getToken(RuneScriptParser.LPAREN, i);
		}
		public List<TerminalNode> RPAREN() { return getTokens(RuneScriptParser.RPAREN); }
		public TerminalNode RPAREN(int i) {
			return getToken(RuneScriptParser.RPAREN, i);
		}
		public ParameterListContext parameterList() {
			return getRuleContext(ParameterListContext.class,0);
		}
		public TypeListContext typeList() {
			return getRuleContext(TypeListContext.class,0);
		}
		public ScriptContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_script; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitScript(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ScriptContext script() throws RecognitionException {
		ScriptContext _localctx = new ScriptContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_script);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(94);
			match(LBRACK);
			setState(95);
			((ScriptContext)_localctx).trigger = identifier();
			setState(96);
			match(COMMA);
			setState(97);
			((ScriptContext)_localctx).name = identifier();
			setState(99);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==MUL) {
				{
				setState(98);
				match(MUL);
				}
			}

			setState(101);
			match(RBRACK);
			setState(115);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,5,_ctx) ) {
			case 1:
				{
				{
				setState(102);
				match(LPAREN);
				setState(104);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==IDENTIFIER) {
					{
					setState(103);
					parameterList();
					}
				}

				setState(106);
				match(RPAREN);
				}
				setState(113);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,4,_ctx) ) {
				case 1:
					{
					setState(108);
					match(LPAREN);
					setState(110);
					_errHandler.sync(this);
					_la = _input.LA(1);
					if (_la==IDENTIFIER) {
						{
						setState(109);
						typeList();
						}
					}

					setState(112);
					match(RPAREN);
					}
					break;
				}
				}
				break;
			}
			setState(120);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << LPAREN) | (1L << SEMICOLON) | (1L << LBRACE) | (1L << MOD) | (1L << DOLLAR) | (1L << CARET) | (1L << TILDE) | (1L << AT) | (1L << INCREMENT) | (1L << DECREMENT) | (1L << IF) | (1L << WHILE) | (1L << DEFAULT) | (1L << RETURN) | (1L << CALC) | (1L << DEF_TYPE) | (1L << SWITCH_TYPE) | (1L << INTEGER_LITERAL) | (1L << HEX_LITERAL) | (1L << COORD_LITERAL) | (1L << BOOLEAN_LITERAL) | (1L << CHAR_LITERAL) | (1L << NULL_LITERAL) | (1L << QUOTE_OPEN) | (1L << IDENTIFIER))) != 0)) {
				{
				{
				setState(117);
				statement();
				}
				}
				setState(122);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ParameterListContext extends ParserRuleContext {
		public List<ParameterContext> parameter() {
			return getRuleContexts(ParameterContext.class);
		}
		public ParameterContext parameter(int i) {
			return getRuleContext(ParameterContext.class,i);
		}
		public List<TerminalNode> COMMA() { return getTokens(RuneScriptParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(RuneScriptParser.COMMA, i);
		}
		public ParameterListContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_parameterList; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitParameterList(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ParameterListContext parameterList() throws RecognitionException {
		ParameterListContext _localctx = new ParameterListContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_parameterList);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(123);
			parameter();
			setState(128);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==COMMA) {
				{
				{
				setState(124);
				match(COMMA);
				setState(125);
				parameter();
				}
				}
				setState(130);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ParameterContext extends ParserRuleContext {
		public Token type;
		public TerminalNode DOLLAR() { return getToken(RuneScriptParser.DOLLAR, 0); }
		public AdvancedIdentifierContext advancedIdentifier() {
			return getRuleContext(AdvancedIdentifierContext.class,0);
		}
		public TerminalNode IDENTIFIER() { return getToken(RuneScriptParser.IDENTIFIER, 0); }
		public ParameterContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_parameter; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitParameter(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ParameterContext parameter() throws RecognitionException {
		ParameterContext _localctx = new ParameterContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_parameter);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(131);
			((ParameterContext)_localctx).type = match(IDENTIFIER);
			setState(132);
			match(DOLLAR);
			setState(133);
			advancedIdentifier();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class TypeListContext extends ParserRuleContext {
		public List<TerminalNode> IDENTIFIER() { return getTokens(RuneScriptParser.IDENTIFIER); }
		public TerminalNode IDENTIFIER(int i) {
			return getToken(RuneScriptParser.IDENTIFIER, i);
		}
		public List<TerminalNode> COMMA() { return getTokens(RuneScriptParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(RuneScriptParser.COMMA, i);
		}
		public TypeListContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_typeList; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitTypeList(this);
			else return visitor.visitChildren(this);
		}
	}

	public final TypeListContext typeList() throws RecognitionException {
		TypeListContext _localctx = new TypeListContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_typeList);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(135);
			match(IDENTIFIER);
			setState(140);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==COMMA) {
				{
				{
				setState(136);
				match(COMMA);
				setState(137);
				match(IDENTIFIER);
				}
				}
				setState(142);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class StatementContext extends ParserRuleContext {
		public BlockStatementContext blockStatement() {
			return getRuleContext(BlockStatementContext.class,0);
		}
		public ReturnStatementContext returnStatement() {
			return getRuleContext(ReturnStatementContext.class,0);
		}
		public IfStatementContext ifStatement() {
			return getRuleContext(IfStatementContext.class,0);
		}
		public WhileStatementContext whileStatement() {
			return getRuleContext(WhileStatementContext.class,0);
		}
		public SwitchStatementContext switchStatement() {
			return getRuleContext(SwitchStatementContext.class,0);
		}
		public DeclarationStatementContext declarationStatement() {
			return getRuleContext(DeclarationStatementContext.class,0);
		}
		public ArrayDeclarationStatementContext arrayDeclarationStatement() {
			return getRuleContext(ArrayDeclarationStatementContext.class,0);
		}
		public AssignmentStatementContext assignmentStatement() {
			return getRuleContext(AssignmentStatementContext.class,0);
		}
		public ExpressionStatementContext expressionStatement() {
			return getRuleContext(ExpressionStatementContext.class,0);
		}
		public EmptyStatementContext emptyStatement() {
			return getRuleContext(EmptyStatementContext.class,0);
		}
		public StatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_statement; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitStatement(this);
			else return visitor.visitChildren(this);
		}
	}

	public final StatementContext statement() throws RecognitionException {
		StatementContext _localctx = new StatementContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_statement);
		try {
			setState(153);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,9,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(143);
				blockStatement();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(144);
				returnStatement();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(145);
				ifStatement();
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(146);
				whileStatement();
				}
				break;
			case 5:
				enterOuterAlt(_localctx, 5);
				{
				setState(147);
				switchStatement();
				}
				break;
			case 6:
				enterOuterAlt(_localctx, 6);
				{
				setState(148);
				declarationStatement();
				}
				break;
			case 7:
				enterOuterAlt(_localctx, 7);
				{
				setState(149);
				arrayDeclarationStatement();
				}
				break;
			case 8:
				enterOuterAlt(_localctx, 8);
				{
				setState(150);
				assignmentStatement();
				}
				break;
			case 9:
				enterOuterAlt(_localctx, 9);
				{
				setState(151);
				expressionStatement();
				}
				break;
			case 10:
				enterOuterAlt(_localctx, 10);
				{
				setState(152);
				emptyStatement();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class BlockStatementContext extends ParserRuleContext {
		public TerminalNode LBRACE() { return getToken(RuneScriptParser.LBRACE, 0); }
		public TerminalNode RBRACE() { return getToken(RuneScriptParser.RBRACE, 0); }
		public List<StatementContext> statement() {
			return getRuleContexts(StatementContext.class);
		}
		public StatementContext statement(int i) {
			return getRuleContext(StatementContext.class,i);
		}
		public BlockStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_blockStatement; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitBlockStatement(this);
			else return visitor.visitChildren(this);
		}
	}

	public final BlockStatementContext blockStatement() throws RecognitionException {
		BlockStatementContext _localctx = new BlockStatementContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_blockStatement);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(155);
			match(LBRACE);
			setState(159);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << LPAREN) | (1L << SEMICOLON) | (1L << LBRACE) | (1L << MOD) | (1L << DOLLAR) | (1L << CARET) | (1L << TILDE) | (1L << AT) | (1L << INCREMENT) | (1L << DECREMENT) | (1L << IF) | (1L << WHILE) | (1L << DEFAULT) | (1L << RETURN) | (1L << CALC) | (1L << DEF_TYPE) | (1L << SWITCH_TYPE) | (1L << INTEGER_LITERAL) | (1L << HEX_LITERAL) | (1L << COORD_LITERAL) | (1L << BOOLEAN_LITERAL) | (1L << CHAR_LITERAL) | (1L << NULL_LITERAL) | (1L << QUOTE_OPEN) | (1L << IDENTIFIER))) != 0)) {
				{
				{
				setState(156);
				statement();
				}
				}
				setState(161);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(162);
			match(RBRACE);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ReturnStatementContext extends ParserRuleContext {
		public TerminalNode RETURN() { return getToken(RuneScriptParser.RETURN, 0); }
		public TerminalNode SEMICOLON() { return getToken(RuneScriptParser.SEMICOLON, 0); }
		public TerminalNode LPAREN() { return getToken(RuneScriptParser.LPAREN, 0); }
		public TerminalNode RPAREN() { return getToken(RuneScriptParser.RPAREN, 0); }
		public ExpressionListContext expressionList() {
			return getRuleContext(ExpressionListContext.class,0);
		}
		public ReturnStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_returnStatement; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitReturnStatement(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ReturnStatementContext returnStatement() throws RecognitionException {
		ReturnStatementContext _localctx = new ReturnStatementContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_returnStatement);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(164);
			match(RETURN);
			setState(170);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==LPAREN) {
				{
				setState(165);
				match(LPAREN);
				setState(167);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << LPAREN) | (1L << MOD) | (1L << DOLLAR) | (1L << CARET) | (1L << TILDE) | (1L << AT) | (1L << INCREMENT) | (1L << DECREMENT) | (1L << DEFAULT) | (1L << CALC) | (1L << DEF_TYPE) | (1L << SWITCH_TYPE) | (1L << INTEGER_LITERAL) | (1L << HEX_LITERAL) | (1L << COORD_LITERAL) | (1L << BOOLEAN_LITERAL) | (1L << CHAR_LITERAL) | (1L << NULL_LITERAL) | (1L << QUOTE_OPEN) | (1L << IDENTIFIER))) != 0)) {
					{
					setState(166);
					expressionList();
					}
				}

				setState(169);
				match(RPAREN);
				}
			}

			setState(172);
			match(SEMICOLON);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class IfStatementContext extends ParserRuleContext {
		public TerminalNode IF() { return getToken(RuneScriptParser.IF, 0); }
		public TerminalNode LPAREN() { return getToken(RuneScriptParser.LPAREN, 0); }
		public ConditionContext condition() {
			return getRuleContext(ConditionContext.class,0);
		}
		public TerminalNode RPAREN() { return getToken(RuneScriptParser.RPAREN, 0); }
		public List<StatementContext> statement() {
			return getRuleContexts(StatementContext.class);
		}
		public StatementContext statement(int i) {
			return getRuleContext(StatementContext.class,i);
		}
		public TerminalNode ELSE() { return getToken(RuneScriptParser.ELSE, 0); }
		public IfStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_ifStatement; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitIfStatement(this);
			else return visitor.visitChildren(this);
		}
	}

	public final IfStatementContext ifStatement() throws RecognitionException {
		IfStatementContext _localctx = new IfStatementContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_ifStatement);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(174);
			match(IF);
			setState(175);
			match(LPAREN);
			setState(176);
			condition(0);
			setState(177);
			match(RPAREN);
			setState(178);
			statement();
			setState(181);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,13,_ctx) ) {
			case 1:
				{
				setState(179);
				match(ELSE);
				setState(180);
				statement();
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class WhileStatementContext extends ParserRuleContext {
		public TerminalNode WHILE() { return getToken(RuneScriptParser.WHILE, 0); }
		public TerminalNode LPAREN() { return getToken(RuneScriptParser.LPAREN, 0); }
		public ConditionContext condition() {
			return getRuleContext(ConditionContext.class,0);
		}
		public TerminalNode RPAREN() { return getToken(RuneScriptParser.RPAREN, 0); }
		public StatementContext statement() {
			return getRuleContext(StatementContext.class,0);
		}
		public WhileStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_whileStatement; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitWhileStatement(this);
			else return visitor.visitChildren(this);
		}
	}

	public final WhileStatementContext whileStatement() throws RecognitionException {
		WhileStatementContext _localctx = new WhileStatementContext(_ctx, getState());
		enterRule(_localctx, 18, RULE_whileStatement);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(183);
			match(WHILE);
			setState(184);
			match(LPAREN);
			setState(185);
			condition(0);
			setState(186);
			match(RPAREN);
			setState(187);
			statement();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class SwitchStatementContext extends ParserRuleContext {
		public TerminalNode SWITCH_TYPE() { return getToken(RuneScriptParser.SWITCH_TYPE, 0); }
		public ParenthesisContext parenthesis() {
			return getRuleContext(ParenthesisContext.class,0);
		}
		public TerminalNode LBRACE() { return getToken(RuneScriptParser.LBRACE, 0); }
		public TerminalNode RBRACE() { return getToken(RuneScriptParser.RBRACE, 0); }
		public List<SwitchCaseContext> switchCase() {
			return getRuleContexts(SwitchCaseContext.class);
		}
		public SwitchCaseContext switchCase(int i) {
			return getRuleContext(SwitchCaseContext.class,i);
		}
		public SwitchStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_switchStatement; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitSwitchStatement(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SwitchStatementContext switchStatement() throws RecognitionException {
		SwitchStatementContext _localctx = new SwitchStatementContext(_ctx, getState());
		enterRule(_localctx, 20, RULE_switchStatement);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(189);
			match(SWITCH_TYPE);
			setState(190);
			parenthesis();
			setState(191);
			match(LBRACE);
			setState(195);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==CASE) {
				{
				{
				setState(192);
				switchCase();
				}
				}
				setState(197);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(198);
			match(RBRACE);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class SwitchCaseContext extends ParserRuleContext {
		public TerminalNode CASE() { return getToken(RuneScriptParser.CASE, 0); }
		public TerminalNode COLON() { return getToken(RuneScriptParser.COLON, 0); }
		public TerminalNode DEFAULT() { return getToken(RuneScriptParser.DEFAULT, 0); }
		public ExpressionListContext expressionList() {
			return getRuleContext(ExpressionListContext.class,0);
		}
		public List<StatementContext> statement() {
			return getRuleContexts(StatementContext.class);
		}
		public StatementContext statement(int i) {
			return getRuleContext(StatementContext.class,i);
		}
		public SwitchCaseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_switchCase; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitSwitchCase(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SwitchCaseContext switchCase() throws RecognitionException {
		SwitchCaseContext _localctx = new SwitchCaseContext(_ctx, getState());
		enterRule(_localctx, 22, RULE_switchCase);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(200);
			match(CASE);
			setState(203);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,15,_ctx) ) {
			case 1:
				{
				setState(201);
				match(DEFAULT);
				}
				break;
			case 2:
				{
				setState(202);
				expressionList();
				}
				break;
			}
			setState(205);
			match(COLON);
			setState(209);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << LPAREN) | (1L << SEMICOLON) | (1L << LBRACE) | (1L << MOD) | (1L << DOLLAR) | (1L << CARET) | (1L << TILDE) | (1L << AT) | (1L << INCREMENT) | (1L << DECREMENT) | (1L << IF) | (1L << WHILE) | (1L << DEFAULT) | (1L << RETURN) | (1L << CALC) | (1L << DEF_TYPE) | (1L << SWITCH_TYPE) | (1L << INTEGER_LITERAL) | (1L << HEX_LITERAL) | (1L << COORD_LITERAL) | (1L << BOOLEAN_LITERAL) | (1L << CHAR_LITERAL) | (1L << NULL_LITERAL) | (1L << QUOTE_OPEN) | (1L << IDENTIFIER))) != 0)) {
				{
				{
				setState(206);
				statement();
				}
				}
				setState(211);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class DeclarationStatementContext extends ParserRuleContext {
		public TerminalNode DEF_TYPE() { return getToken(RuneScriptParser.DEF_TYPE, 0); }
		public TerminalNode DOLLAR() { return getToken(RuneScriptParser.DOLLAR, 0); }
		public AdvancedIdentifierContext advancedIdentifier() {
			return getRuleContext(AdvancedIdentifierContext.class,0);
		}
		public TerminalNode SEMICOLON() { return getToken(RuneScriptParser.SEMICOLON, 0); }
		public TerminalNode EQ() { return getToken(RuneScriptParser.EQ, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public DeclarationStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_declarationStatement; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitDeclarationStatement(this);
			else return visitor.visitChildren(this);
		}
	}

	public final DeclarationStatementContext declarationStatement() throws RecognitionException {
		DeclarationStatementContext _localctx = new DeclarationStatementContext(_ctx, getState());
		enterRule(_localctx, 24, RULE_declarationStatement);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(212);
			match(DEF_TYPE);
			setState(213);
			match(DOLLAR);
			setState(214);
			advancedIdentifier();
			setState(217);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==EQ) {
				{
				setState(215);
				match(EQ);
				setState(216);
				expression();
				}
			}

			setState(219);
			match(SEMICOLON);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ArrayDeclarationStatementContext extends ParserRuleContext {
		public TerminalNode DEF_TYPE() { return getToken(RuneScriptParser.DEF_TYPE, 0); }
		public TerminalNode DOLLAR() { return getToken(RuneScriptParser.DOLLAR, 0); }
		public AdvancedIdentifierContext advancedIdentifier() {
			return getRuleContext(AdvancedIdentifierContext.class,0);
		}
		public ParenthesisContext parenthesis() {
			return getRuleContext(ParenthesisContext.class,0);
		}
		public TerminalNode SEMICOLON() { return getToken(RuneScriptParser.SEMICOLON, 0); }
		public ArrayDeclarationStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_arrayDeclarationStatement; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitArrayDeclarationStatement(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ArrayDeclarationStatementContext arrayDeclarationStatement() throws RecognitionException {
		ArrayDeclarationStatementContext _localctx = new ArrayDeclarationStatementContext(_ctx, getState());
		enterRule(_localctx, 26, RULE_arrayDeclarationStatement);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(221);
			match(DEF_TYPE);
			setState(222);
			match(DOLLAR);
			setState(223);
			advancedIdentifier();
			setState(224);
			parenthesis();
			setState(225);
			match(SEMICOLON);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AssignmentStatementContext extends ParserRuleContext {
		public AssignableVariableListContext assignableVariableList() {
			return getRuleContext(AssignableVariableListContext.class,0);
		}
		public TerminalNode EQ() { return getToken(RuneScriptParser.EQ, 0); }
		public ExpressionListContext expressionList() {
			return getRuleContext(ExpressionListContext.class,0);
		}
		public TerminalNode SEMICOLON() { return getToken(RuneScriptParser.SEMICOLON, 0); }
		public AssignmentStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_assignmentStatement; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitAssignmentStatement(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AssignmentStatementContext assignmentStatement() throws RecognitionException {
		AssignmentStatementContext _localctx = new AssignmentStatementContext(_ctx, getState());
		enterRule(_localctx, 28, RULE_assignmentStatement);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(227);
			assignableVariableList();
			setState(228);
			match(EQ);
			setState(229);
			expressionList();
			setState(230);
			match(SEMICOLON);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ExpressionStatementContext extends ParserRuleContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public TerminalNode SEMICOLON() { return getToken(RuneScriptParser.SEMICOLON, 0); }
		public ExpressionStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_expressionStatement; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitExpressionStatement(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ExpressionStatementContext expressionStatement() throws RecognitionException {
		ExpressionStatementContext _localctx = new ExpressionStatementContext(_ctx, getState());
		enterRule(_localctx, 30, RULE_expressionStatement);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(232);
			expression();
			setState(233);
			match(SEMICOLON);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class EmptyStatementContext extends ParserRuleContext {
		public TerminalNode SEMICOLON() { return getToken(RuneScriptParser.SEMICOLON, 0); }
		public EmptyStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_emptyStatement; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitEmptyStatement(this);
			else return visitor.visitChildren(this);
		}
	}

	public final EmptyStatementContext emptyStatement() throws RecognitionException {
		EmptyStatementContext _localctx = new EmptyStatementContext(_ctx, getState());
		enterRule(_localctx, 32, RULE_emptyStatement);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(235);
			match(SEMICOLON);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ExpressionListContext extends ParserRuleContext {
		public List<ExpressionContext> expression() {
			return getRuleContexts(ExpressionContext.class);
		}
		public ExpressionContext expression(int i) {
			return getRuleContext(ExpressionContext.class,i);
		}
		public List<TerminalNode> COMMA() { return getTokens(RuneScriptParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(RuneScriptParser.COMMA, i);
		}
		public ExpressionListContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_expressionList; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitExpressionList(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ExpressionListContext expressionList() throws RecognitionException {
		ExpressionListContext _localctx = new ExpressionListContext(_ctx, getState());
		enterRule(_localctx, 34, RULE_expressionList);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(237);
			expression();
			setState(242);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==COMMA) {
				{
				{
				setState(238);
				match(COMMA);
				setState(239);
				expression();
				}
				}
				setState(244);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ParenthesisContext extends ParserRuleContext {
		public TerminalNode LPAREN() { return getToken(RuneScriptParser.LPAREN, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public TerminalNode RPAREN() { return getToken(RuneScriptParser.RPAREN, 0); }
		public ParenthesisContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_parenthesis; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitParenthesis(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ParenthesisContext parenthesis() throws RecognitionException {
		ParenthesisContext _localctx = new ParenthesisContext(_ctx, getState());
		enterRule(_localctx, 36, RULE_parenthesis);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(245);
			match(LPAREN);
			setState(246);
			expression();
			setState(247);
			match(RPAREN);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class SingleExpressionContext extends ParserRuleContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public TerminalNode EOF() { return getToken(RuneScriptParser.EOF, 0); }
		public SingleExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_singleExpression; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitSingleExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SingleExpressionContext singleExpression() throws RecognitionException {
		SingleExpressionContext _localctx = new SingleExpressionContext(_ctx, getState());
		enterRule(_localctx, 38, RULE_singleExpression);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(249);
			expression();
			setState(250);
			match(EOF);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ExpressionContext extends ParserRuleContext {
		public ExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_expression; }
	 
		public ExpressionContext() { }
		public void copyFrom(ExpressionContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class ParenthesizedExpressionContext extends ExpressionContext {
		public ParenthesisContext parenthesis() {
			return getRuleContext(ParenthesisContext.class,0);
		}
		public ParenthesizedExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitParenthesizedExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class LocalVariableExpressionContext extends ExpressionContext {
		public LocalVariableContext localVariable() {
			return getRuleContext(LocalVariableContext.class,0);
		}
		public LocalVariableExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitLocalVariableExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class ConstantVariableExpressionContext extends ExpressionContext {
		public ConstantVariableContext constantVariable() {
			return getRuleContext(ConstantVariableContext.class,0);
		}
		public ConstantVariableExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitConstantVariableExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class LiteralExpressionContext extends ExpressionContext {
		public LiteralContext literal() {
			return getRuleContext(LiteralContext.class,0);
		}
		public LiteralExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitLiteralExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class PrefixExpressionContext extends ExpressionContext {
		public Token op;
		public AssignableVariableContext expr;
		public AssignableVariableContext assignableVariable() {
			return getRuleContext(AssignableVariableContext.class,0);
		}
		public TerminalNode INCREMENT() { return getToken(RuneScriptParser.INCREMENT, 0); }
		public TerminalNode DECREMENT() { return getToken(RuneScriptParser.DECREMENT, 0); }
		public PrefixExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitPrefixExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class PostfixExpressionContext extends ExpressionContext {
		public AssignableVariableContext expr;
		public Token op;
		public AssignableVariableContext assignableVariable() {
			return getRuleContext(AssignableVariableContext.class,0);
		}
		public TerminalNode INCREMENT() { return getToken(RuneScriptParser.INCREMENT, 0); }
		public TerminalNode DECREMENT() { return getToken(RuneScriptParser.DECREMENT, 0); }
		public PostfixExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitPostfixExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class JoinedStringExpressionContext extends ExpressionContext {
		public JoinedStringContext joinedString() {
			return getRuleContext(JoinedStringContext.class,0);
		}
		public JoinedStringExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitJoinedStringExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class CalcExpressionContext extends ExpressionContext {
		public CalcContext calc() {
			return getRuleContext(CalcContext.class,0);
		}
		public CalcExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitCalcExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class GameVariableExpressionContext extends ExpressionContext {
		public GameVariableContext gameVariable() {
			return getRuleContext(GameVariableContext.class,0);
		}
		public GameVariableExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitGameVariableExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class CallExpressionContext extends ExpressionContext {
		public CallContext call() {
			return getRuleContext(CallContext.class,0);
		}
		public CallExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitCallExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class LocalArrayVariableExpressionContext extends ExpressionContext {
		public LocalArrayVariableContext localArrayVariable() {
			return getRuleContext(LocalArrayVariableContext.class,0);
		}
		public LocalArrayVariableExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitLocalArrayVariableExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class IdentifierExpressionContext extends ExpressionContext {
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public IdentifierExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitIdentifierExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ExpressionContext expression() throws RecognitionException {
		ExpressionContext _localctx = new ExpressionContext(_ctx, getState());
		enterRule(_localctx, 40, RULE_expression);
		int _la;
		try {
			setState(267);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,19,_ctx) ) {
			case 1:
				_localctx = new ParenthesizedExpressionContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(252);
				parenthesis();
				}
				break;
			case 2:
				_localctx = new CalcExpressionContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(253);
				calc();
				}
				break;
			case 3:
				_localctx = new CallExpressionContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(254);
				call();
				}
				break;
			case 4:
				_localctx = new LocalVariableExpressionContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(255);
				localVariable();
				}
				break;
			case 5:
				_localctx = new LocalArrayVariableExpressionContext(_localctx);
				enterOuterAlt(_localctx, 5);
				{
				setState(256);
				localArrayVariable();
				}
				break;
			case 6:
				_localctx = new GameVariableExpressionContext(_localctx);
				enterOuterAlt(_localctx, 6);
				{
				setState(257);
				gameVariable();
				}
				break;
			case 7:
				_localctx = new ConstantVariableExpressionContext(_localctx);
				enterOuterAlt(_localctx, 7);
				{
				setState(258);
				constantVariable();
				}
				break;
			case 8:
				_localctx = new LiteralExpressionContext(_localctx);
				enterOuterAlt(_localctx, 8);
				{
				setState(259);
				literal();
				}
				break;
			case 9:
				_localctx = new JoinedStringExpressionContext(_localctx);
				enterOuterAlt(_localctx, 9);
				{
				setState(260);
				joinedString();
				}
				break;
			case 10:
				_localctx = new PrefixExpressionContext(_localctx);
				enterOuterAlt(_localctx, 10);
				{
				setState(261);
				((PrefixExpressionContext)_localctx).op = _input.LT(1);
				_la = _input.LA(1);
				if ( !(_la==INCREMENT || _la==DECREMENT) ) {
					((PrefixExpressionContext)_localctx).op = (Token)_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(262);
				((PrefixExpressionContext)_localctx).expr = assignableVariable();
				}
				break;
			case 11:
				_localctx = new PostfixExpressionContext(_localctx);
				enterOuterAlt(_localctx, 11);
				{
				setState(263);
				((PostfixExpressionContext)_localctx).expr = assignableVariable();
				setState(264);
				((PostfixExpressionContext)_localctx).op = _input.LT(1);
				_la = _input.LA(1);
				if ( !(_la==INCREMENT || _la==DECREMENT) ) {
					((PostfixExpressionContext)_localctx).op = (Token)_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
				break;
			case 12:
				_localctx = new IdentifierExpressionContext(_localctx);
				enterOuterAlt(_localctx, 12);
				{
				setState(266);
				identifier();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ConditionContext extends ParserRuleContext {
		public ConditionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_condition; }
	 
		public ConditionContext() { }
		public void copyFrom(ConditionContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class ConditionNormalExpressionContext extends ConditionContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public ConditionNormalExpressionContext(ConditionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitConditionNormalExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class ConditionBinaryExpressionContext extends ConditionContext {
		public Token op;
		public List<ConditionContext> condition() {
			return getRuleContexts(ConditionContext.class);
		}
		public ConditionContext condition(int i) {
			return getRuleContext(ConditionContext.class,i);
		}
		public TerminalNode LT() { return getToken(RuneScriptParser.LT, 0); }
		public TerminalNode GT() { return getToken(RuneScriptParser.GT, 0); }
		public TerminalNode LTE() { return getToken(RuneScriptParser.LTE, 0); }
		public TerminalNode GTE() { return getToken(RuneScriptParser.GTE, 0); }
		public TerminalNode EQ() { return getToken(RuneScriptParser.EQ, 0); }
		public TerminalNode EXCL() { return getToken(RuneScriptParser.EXCL, 0); }
		public TerminalNode AND() { return getToken(RuneScriptParser.AND, 0); }
		public TerminalNode OR() { return getToken(RuneScriptParser.OR, 0); }
		public ConditionBinaryExpressionContext(ConditionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitConditionBinaryExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class ConditionParenthesizedExpressionContext extends ConditionContext {
		public TerminalNode LPAREN() { return getToken(RuneScriptParser.LPAREN, 0); }
		public ConditionContext condition() {
			return getRuleContext(ConditionContext.class,0);
		}
		public TerminalNode RPAREN() { return getToken(RuneScriptParser.RPAREN, 0); }
		public ConditionParenthesizedExpressionContext(ConditionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitConditionParenthesizedExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ConditionContext condition() throws RecognitionException {
		return condition(0);
	}

	private ConditionContext condition(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		ConditionContext _localctx = new ConditionContext(_ctx, _parentState);
		ConditionContext _prevctx = _localctx;
		int _startState = 42;
		enterRecursionRule(_localctx, 42, RULE_condition, _p);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(275);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,20,_ctx) ) {
			case 1:
				{
				_localctx = new ConditionParenthesizedExpressionContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;

				setState(270);
				match(LPAREN);
				setState(271);
				condition(0);
				setState(272);
				match(RPAREN);
				}
				break;
			case 2:
				{
				_localctx = new ConditionNormalExpressionContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(274);
				expression();
				}
				break;
			}
			_ctx.stop = _input.LT(-1);
			setState(291);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,22,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					setState(289);
					_errHandler.sync(this);
					switch ( getInterpreter().adaptivePredict(_input,21,_ctx) ) {
					case 1:
						{
						_localctx = new ConditionBinaryExpressionContext(new ConditionContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_condition);
						setState(277);
						if (!(precpred(_ctx, 5))) throw new FailedPredicateException(this, "precpred(_ctx, 5)");
						setState(278);
						((ConditionBinaryExpressionContext)_localctx).op = _input.LT(1);
						_la = _input.LA(1);
						if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << GT) | (1L << GTE) | (1L << LT) | (1L << LTE))) != 0)) ) {
							((ConditionBinaryExpressionContext)_localctx).op = (Token)_errHandler.recoverInline(this);
						}
						else {
							if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
							_errHandler.reportMatch(this);
							consume();
						}
						setState(279);
						condition(6);
						}
						break;
					case 2:
						{
						_localctx = new ConditionBinaryExpressionContext(new ConditionContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_condition);
						setState(280);
						if (!(precpred(_ctx, 4))) throw new FailedPredicateException(this, "precpred(_ctx, 4)");
						setState(281);
						((ConditionBinaryExpressionContext)_localctx).op = _input.LT(1);
						_la = _input.LA(1);
						if ( !(_la==EQ || _la==EXCL) ) {
							((ConditionBinaryExpressionContext)_localctx).op = (Token)_errHandler.recoverInline(this);
						}
						else {
							if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
							_errHandler.reportMatch(this);
							consume();
						}
						setState(282);
						condition(5);
						}
						break;
					case 3:
						{
						_localctx = new ConditionBinaryExpressionContext(new ConditionContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_condition);
						setState(283);
						if (!(precpred(_ctx, 3))) throw new FailedPredicateException(this, "precpred(_ctx, 3)");
						setState(284);
						((ConditionBinaryExpressionContext)_localctx).op = match(AND);
						setState(285);
						condition(4);
						}
						break;
					case 4:
						{
						_localctx = new ConditionBinaryExpressionContext(new ConditionContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_condition);
						setState(286);
						if (!(precpred(_ctx, 2))) throw new FailedPredicateException(this, "precpred(_ctx, 2)");
						setState(287);
						((ConditionBinaryExpressionContext)_localctx).op = match(OR);
						setState(288);
						condition(3);
						}
						break;
					}
					} 
				}
				setState(293);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,22,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	public static class CalcContext extends ParserRuleContext {
		public TerminalNode CALC() { return getToken(RuneScriptParser.CALC, 0); }
		public TerminalNode LPAREN() { return getToken(RuneScriptParser.LPAREN, 0); }
		public ArithmeticContext arithmetic() {
			return getRuleContext(ArithmeticContext.class,0);
		}
		public TerminalNode RPAREN() { return getToken(RuneScriptParser.RPAREN, 0); }
		public CalcContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_calc; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitCalc(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CalcContext calc() throws RecognitionException {
		CalcContext _localctx = new CalcContext(_ctx, getState());
		enterRule(_localctx, 44, RULE_calc);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(294);
			match(CALC);
			setState(295);
			match(LPAREN);
			setState(296);
			arithmetic(0);
			setState(297);
			match(RPAREN);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ArithmeticContext extends ParserRuleContext {
		public ArithmeticContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_arithmetic; }
	 
		public ArithmeticContext() { }
		public void copyFrom(ArithmeticContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class ArithmeticBinaryExpressionContext extends ArithmeticContext {
		public Token op;
		public List<ArithmeticContext> arithmetic() {
			return getRuleContexts(ArithmeticContext.class);
		}
		public ArithmeticContext arithmetic(int i) {
			return getRuleContext(ArithmeticContext.class,i);
		}
		public TerminalNode MUL() { return getToken(RuneScriptParser.MUL, 0); }
		public TerminalNode DIV() { return getToken(RuneScriptParser.DIV, 0); }
		public TerminalNode MOD() { return getToken(RuneScriptParser.MOD, 0); }
		public TerminalNode PLUS() { return getToken(RuneScriptParser.PLUS, 0); }
		public TerminalNode MINUS() { return getToken(RuneScriptParser.MINUS, 0); }
		public TerminalNode AND() { return getToken(RuneScriptParser.AND, 0); }
		public TerminalNode OR() { return getToken(RuneScriptParser.OR, 0); }
		public ArithmeticBinaryExpressionContext(ArithmeticContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitArithmeticBinaryExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class ArithmeticParenthesizedExpressionContext extends ArithmeticContext {
		public TerminalNode LPAREN() { return getToken(RuneScriptParser.LPAREN, 0); }
		public ArithmeticContext arithmetic() {
			return getRuleContext(ArithmeticContext.class,0);
		}
		public TerminalNode RPAREN() { return getToken(RuneScriptParser.RPAREN, 0); }
		public ArithmeticParenthesizedExpressionContext(ArithmeticContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitArithmeticParenthesizedExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class ArithmeticNormalExpressionContext extends ArithmeticContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public ArithmeticNormalExpressionContext(ArithmeticContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitArithmeticNormalExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ArithmeticContext arithmetic() throws RecognitionException {
		return arithmetic(0);
	}

	private ArithmeticContext arithmetic(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		ArithmeticContext _localctx = new ArithmeticContext(_ctx, _parentState);
		ArithmeticContext _prevctx = _localctx;
		int _startState = 46;
		enterRecursionRule(_localctx, 46, RULE_arithmetic, _p);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(305);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,23,_ctx) ) {
			case 1:
				{
				_localctx = new ArithmeticParenthesizedExpressionContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;

				setState(300);
				match(LPAREN);
				setState(301);
				arithmetic(0);
				setState(302);
				match(RPAREN);
				}
				break;
			case 2:
				{
				_localctx = new ArithmeticNormalExpressionContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(304);
				expression();
				}
				break;
			}
			_ctx.stop = _input.LT(-1);
			setState(321);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,25,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					setState(319);
					_errHandler.sync(this);
					switch ( getInterpreter().adaptivePredict(_input,24,_ctx) ) {
					case 1:
						{
						_localctx = new ArithmeticBinaryExpressionContext(new ArithmeticContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_arithmetic);
						setState(307);
						if (!(precpred(_ctx, 5))) throw new FailedPredicateException(this, "precpred(_ctx, 5)");
						setState(308);
						((ArithmeticBinaryExpressionContext)_localctx).op = _input.LT(1);
						_la = _input.LA(1);
						if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << MUL) | (1L << DIV) | (1L << MOD))) != 0)) ) {
							((ArithmeticBinaryExpressionContext)_localctx).op = (Token)_errHandler.recoverInline(this);
						}
						else {
							if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
							_errHandler.reportMatch(this);
							consume();
						}
						setState(309);
						arithmetic(6);
						}
						break;
					case 2:
						{
						_localctx = new ArithmeticBinaryExpressionContext(new ArithmeticContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_arithmetic);
						setState(310);
						if (!(precpred(_ctx, 4))) throw new FailedPredicateException(this, "precpred(_ctx, 4)");
						setState(311);
						((ArithmeticBinaryExpressionContext)_localctx).op = _input.LT(1);
						_la = _input.LA(1);
						if ( !(_la==PLUS || _la==MINUS) ) {
							((ArithmeticBinaryExpressionContext)_localctx).op = (Token)_errHandler.recoverInline(this);
						}
						else {
							if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
							_errHandler.reportMatch(this);
							consume();
						}
						setState(312);
						arithmetic(5);
						}
						break;
					case 3:
						{
						_localctx = new ArithmeticBinaryExpressionContext(new ArithmeticContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_arithmetic);
						setState(313);
						if (!(precpred(_ctx, 3))) throw new FailedPredicateException(this, "precpred(_ctx, 3)");
						setState(314);
						((ArithmeticBinaryExpressionContext)_localctx).op = match(AND);
						setState(315);
						arithmetic(4);
						}
						break;
					case 4:
						{
						_localctx = new ArithmeticBinaryExpressionContext(new ArithmeticContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_arithmetic);
						setState(316);
						if (!(precpred(_ctx, 2))) throw new FailedPredicateException(this, "precpred(_ctx, 2)");
						setState(317);
						((ArithmeticBinaryExpressionContext)_localctx).op = match(OR);
						setState(318);
						arithmetic(3);
						}
						break;
					}
					} 
				}
				setState(323);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,25,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	public static class CallContext extends ParserRuleContext {
		public CallContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_call; }
	 
		public CallContext() { }
		public void copyFrom(CallContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class JumpCallExpressionContext extends CallContext {
		public TerminalNode AT() { return getToken(RuneScriptParser.AT, 0); }
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public TerminalNode LPAREN() { return getToken(RuneScriptParser.LPAREN, 0); }
		public TerminalNode RPAREN() { return getToken(RuneScriptParser.RPAREN, 0); }
		public ExpressionListContext expressionList() {
			return getRuleContext(ExpressionListContext.class,0);
		}
		public JumpCallExpressionContext(CallContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitJumpCallExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class CommandCallExpressionContext extends CallContext {
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public TerminalNode MUL() { return getToken(RuneScriptParser.MUL, 0); }
		public List<TerminalNode> LPAREN() { return getTokens(RuneScriptParser.LPAREN); }
		public TerminalNode LPAREN(int i) {
			return getToken(RuneScriptParser.LPAREN, i);
		}
		public List<TerminalNode> RPAREN() { return getTokens(RuneScriptParser.RPAREN); }
		public TerminalNode RPAREN(int i) {
			return getToken(RuneScriptParser.RPAREN, i);
		}
		public List<ExpressionListContext> expressionList() {
			return getRuleContexts(ExpressionListContext.class);
		}
		public ExpressionListContext expressionList(int i) {
			return getRuleContext(ExpressionListContext.class,i);
		}
		public CommandCallExpressionContext(CallContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitCommandCallExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class ProcCallExpressionContext extends CallContext {
		public TerminalNode TILDE() { return getToken(RuneScriptParser.TILDE, 0); }
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public TerminalNode LPAREN() { return getToken(RuneScriptParser.LPAREN, 0); }
		public TerminalNode RPAREN() { return getToken(RuneScriptParser.RPAREN, 0); }
		public ExpressionListContext expressionList() {
			return getRuleContext(ExpressionListContext.class,0);
		}
		public ProcCallExpressionContext(CallContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitProcCallExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CallContext call() throws RecognitionException {
		CallContext _localctx = new CallContext(_ctx, getState());
		enterRule(_localctx, 48, RULE_call);
		int _la;
		try {
			setState(362);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,33,_ctx) ) {
			case 1:
				_localctx = new CommandCallExpressionContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(324);
				identifier();
				setState(325);
				match(MUL);
				setState(326);
				match(LPAREN);
				setState(328);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << LPAREN) | (1L << MOD) | (1L << DOLLAR) | (1L << CARET) | (1L << TILDE) | (1L << AT) | (1L << INCREMENT) | (1L << DECREMENT) | (1L << DEFAULT) | (1L << CALC) | (1L << DEF_TYPE) | (1L << SWITCH_TYPE) | (1L << INTEGER_LITERAL) | (1L << HEX_LITERAL) | (1L << COORD_LITERAL) | (1L << BOOLEAN_LITERAL) | (1L << CHAR_LITERAL) | (1L << NULL_LITERAL) | (1L << QUOTE_OPEN) | (1L << IDENTIFIER))) != 0)) {
					{
					setState(327);
					expressionList();
					}
				}

				setState(330);
				match(RPAREN);
				setState(331);
				match(LPAREN);
				setState(333);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << LPAREN) | (1L << MOD) | (1L << DOLLAR) | (1L << CARET) | (1L << TILDE) | (1L << AT) | (1L << INCREMENT) | (1L << DECREMENT) | (1L << DEFAULT) | (1L << CALC) | (1L << DEF_TYPE) | (1L << SWITCH_TYPE) | (1L << INTEGER_LITERAL) | (1L << HEX_LITERAL) | (1L << COORD_LITERAL) | (1L << BOOLEAN_LITERAL) | (1L << CHAR_LITERAL) | (1L << NULL_LITERAL) | (1L << QUOTE_OPEN) | (1L << IDENTIFIER))) != 0)) {
					{
					setState(332);
					expressionList();
					}
				}

				setState(335);
				match(RPAREN);
				}
				break;
			case 2:
				_localctx = new CommandCallExpressionContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(337);
				identifier();
				setState(338);
				match(LPAREN);
				setState(340);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << LPAREN) | (1L << MOD) | (1L << DOLLAR) | (1L << CARET) | (1L << TILDE) | (1L << AT) | (1L << INCREMENT) | (1L << DECREMENT) | (1L << DEFAULT) | (1L << CALC) | (1L << DEF_TYPE) | (1L << SWITCH_TYPE) | (1L << INTEGER_LITERAL) | (1L << HEX_LITERAL) | (1L << COORD_LITERAL) | (1L << BOOLEAN_LITERAL) | (1L << CHAR_LITERAL) | (1L << NULL_LITERAL) | (1L << QUOTE_OPEN) | (1L << IDENTIFIER))) != 0)) {
					{
					setState(339);
					expressionList();
					}
				}

				setState(342);
				match(RPAREN);
				}
				break;
			case 3:
				_localctx = new ProcCallExpressionContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(344);
				match(TILDE);
				setState(345);
				identifier();
				setState(351);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,30,_ctx) ) {
				case 1:
					{
					setState(346);
					match(LPAREN);
					setState(348);
					_errHandler.sync(this);
					_la = _input.LA(1);
					if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << LPAREN) | (1L << MOD) | (1L << DOLLAR) | (1L << CARET) | (1L << TILDE) | (1L << AT) | (1L << INCREMENT) | (1L << DECREMENT) | (1L << DEFAULT) | (1L << CALC) | (1L << DEF_TYPE) | (1L << SWITCH_TYPE) | (1L << INTEGER_LITERAL) | (1L << HEX_LITERAL) | (1L << COORD_LITERAL) | (1L << BOOLEAN_LITERAL) | (1L << CHAR_LITERAL) | (1L << NULL_LITERAL) | (1L << QUOTE_OPEN) | (1L << IDENTIFIER))) != 0)) {
						{
						setState(347);
						expressionList();
						}
					}

					setState(350);
					match(RPAREN);
					}
					break;
				}
				}
				break;
			case 4:
				_localctx = new JumpCallExpressionContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(353);
				match(AT);
				setState(354);
				identifier();
				setState(360);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,32,_ctx) ) {
				case 1:
					{
					setState(355);
					match(LPAREN);
					setState(357);
					_errHandler.sync(this);
					_la = _input.LA(1);
					if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << LPAREN) | (1L << MOD) | (1L << DOLLAR) | (1L << CARET) | (1L << TILDE) | (1L << AT) | (1L << INCREMENT) | (1L << DECREMENT) | (1L << DEFAULT) | (1L << CALC) | (1L << DEF_TYPE) | (1L << SWITCH_TYPE) | (1L << INTEGER_LITERAL) | (1L << HEX_LITERAL) | (1L << COORD_LITERAL) | (1L << BOOLEAN_LITERAL) | (1L << CHAR_LITERAL) | (1L << NULL_LITERAL) | (1L << QUOTE_OPEN) | (1L << IDENTIFIER))) != 0)) {
						{
						setState(356);
						expressionList();
						}
					}

					setState(359);
					match(RPAREN);
					}
					break;
				}
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ClientScriptContext extends ParserRuleContext {
		public ExpressionListContext args;
		public ExpressionListContext triggers;
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public TerminalNode EOF() { return getToken(RuneScriptParser.EOF, 0); }
		public TerminalNode LPAREN() { return getToken(RuneScriptParser.LPAREN, 0); }
		public TerminalNode RPAREN() { return getToken(RuneScriptParser.RPAREN, 0); }
		public TerminalNode LBRACE() { return getToken(RuneScriptParser.LBRACE, 0); }
		public TerminalNode RBRACE() { return getToken(RuneScriptParser.RBRACE, 0); }
		public List<ExpressionListContext> expressionList() {
			return getRuleContexts(ExpressionListContext.class);
		}
		public ExpressionListContext expressionList(int i) {
			return getRuleContext(ExpressionListContext.class,i);
		}
		public ClientScriptContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_clientScript; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitClientScript(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ClientScriptContext clientScript() throws RecognitionException {
		ClientScriptContext _localctx = new ClientScriptContext(_ctx, getState());
		enterRule(_localctx, 50, RULE_clientScript);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(364);
			identifier();
			setState(370);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==LPAREN) {
				{
				setState(365);
				match(LPAREN);
				setState(367);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << LPAREN) | (1L << MOD) | (1L << DOLLAR) | (1L << CARET) | (1L << TILDE) | (1L << AT) | (1L << INCREMENT) | (1L << DECREMENT) | (1L << DEFAULT) | (1L << CALC) | (1L << DEF_TYPE) | (1L << SWITCH_TYPE) | (1L << INTEGER_LITERAL) | (1L << HEX_LITERAL) | (1L << COORD_LITERAL) | (1L << BOOLEAN_LITERAL) | (1L << CHAR_LITERAL) | (1L << NULL_LITERAL) | (1L << QUOTE_OPEN) | (1L << IDENTIFIER))) != 0)) {
					{
					setState(366);
					((ClientScriptContext)_localctx).args = expressionList();
					}
				}

				setState(369);
				match(RPAREN);
				}
			}

			setState(377);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==LBRACE) {
				{
				setState(372);
				match(LBRACE);
				setState(374);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << LPAREN) | (1L << MOD) | (1L << DOLLAR) | (1L << CARET) | (1L << TILDE) | (1L << AT) | (1L << INCREMENT) | (1L << DECREMENT) | (1L << DEFAULT) | (1L << CALC) | (1L << DEF_TYPE) | (1L << SWITCH_TYPE) | (1L << INTEGER_LITERAL) | (1L << HEX_LITERAL) | (1L << COORD_LITERAL) | (1L << BOOLEAN_LITERAL) | (1L << CHAR_LITERAL) | (1L << NULL_LITERAL) | (1L << QUOTE_OPEN) | (1L << IDENTIFIER))) != 0)) {
					{
					setState(373);
					((ClientScriptContext)_localctx).triggers = expressionList();
					}
				}

				setState(376);
				match(RBRACE);
				}
			}

			setState(379);
			match(EOF);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AssignableVariableListContext extends ParserRuleContext {
		public List<AssignableVariableContext> assignableVariable() {
			return getRuleContexts(AssignableVariableContext.class);
		}
		public AssignableVariableContext assignableVariable(int i) {
			return getRuleContext(AssignableVariableContext.class,i);
		}
		public List<TerminalNode> COMMA() { return getTokens(RuneScriptParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(RuneScriptParser.COMMA, i);
		}
		public AssignableVariableListContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_assignableVariableList; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitAssignableVariableList(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AssignableVariableListContext assignableVariableList() throws RecognitionException {
		AssignableVariableListContext _localctx = new AssignableVariableListContext(_ctx, getState());
		enterRule(_localctx, 52, RULE_assignableVariableList);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(381);
			assignableVariable();
			setState(386);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==COMMA) {
				{
				{
				setState(382);
				match(COMMA);
				setState(383);
				assignableVariable();
				}
				}
				setState(388);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AssignableVariableContext extends ParserRuleContext {
		public LocalVariableContext localVariable() {
			return getRuleContext(LocalVariableContext.class,0);
		}
		public LocalArrayVariableContext localArrayVariable() {
			return getRuleContext(LocalArrayVariableContext.class,0);
		}
		public GameVariableContext gameVariable() {
			return getRuleContext(GameVariableContext.class,0);
		}
		public AssignableVariableContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_assignableVariable; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitAssignableVariable(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AssignableVariableContext assignableVariable() throws RecognitionException {
		AssignableVariableContext _localctx = new AssignableVariableContext(_ctx, getState());
		enterRule(_localctx, 54, RULE_assignableVariable);
		try {
			setState(392);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,39,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(389);
				localVariable();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(390);
				localArrayVariable();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(391);
				gameVariable();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class LocalVariableContext extends ParserRuleContext {
		public TerminalNode DOLLAR() { return getToken(RuneScriptParser.DOLLAR, 0); }
		public AdvancedIdentifierContext advancedIdentifier() {
			return getRuleContext(AdvancedIdentifierContext.class,0);
		}
		public LocalVariableContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_localVariable; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitLocalVariable(this);
			else return visitor.visitChildren(this);
		}
	}

	public final LocalVariableContext localVariable() throws RecognitionException {
		LocalVariableContext _localctx = new LocalVariableContext(_ctx, getState());
		enterRule(_localctx, 56, RULE_localVariable);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(394);
			match(DOLLAR);
			setState(395);
			advancedIdentifier();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class LocalArrayVariableContext extends ParserRuleContext {
		public TerminalNode DOLLAR() { return getToken(RuneScriptParser.DOLLAR, 0); }
		public AdvancedIdentifierContext advancedIdentifier() {
			return getRuleContext(AdvancedIdentifierContext.class,0);
		}
		public ParenthesisContext parenthesis() {
			return getRuleContext(ParenthesisContext.class,0);
		}
		public LocalArrayVariableContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_localArrayVariable; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitLocalArrayVariable(this);
			else return visitor.visitChildren(this);
		}
	}

	public final LocalArrayVariableContext localArrayVariable() throws RecognitionException {
		LocalArrayVariableContext _localctx = new LocalArrayVariableContext(_ctx, getState());
		enterRule(_localctx, 58, RULE_localArrayVariable);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(397);
			match(DOLLAR);
			setState(398);
			advancedIdentifier();
			setState(399);
			parenthesis();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class GameVariableContext extends ParserRuleContext {
		public TerminalNode MOD() { return getToken(RuneScriptParser.MOD, 0); }
		public AdvancedIdentifierContext advancedIdentifier() {
			return getRuleContext(AdvancedIdentifierContext.class,0);
		}
		public GameVariableContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_gameVariable; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitGameVariable(this);
			else return visitor.visitChildren(this);
		}
	}

	public final GameVariableContext gameVariable() throws RecognitionException {
		GameVariableContext _localctx = new GameVariableContext(_ctx, getState());
		enterRule(_localctx, 60, RULE_gameVariable);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(401);
			match(MOD);
			setState(402);
			advancedIdentifier();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ConstantVariableContext extends ParserRuleContext {
		public TerminalNode CARET() { return getToken(RuneScriptParser.CARET, 0); }
		public AdvancedIdentifierContext advancedIdentifier() {
			return getRuleContext(AdvancedIdentifierContext.class,0);
		}
		public ConstantVariableContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_constantVariable; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitConstantVariable(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ConstantVariableContext constantVariable() throws RecognitionException {
		ConstantVariableContext _localctx = new ConstantVariableContext(_ctx, getState());
		enterRule(_localctx, 62, RULE_constantVariable);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(404);
			match(CARET);
			setState(405);
			advancedIdentifier();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class LiteralContext extends ParserRuleContext {
		public LiteralContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_literal; }
	 
		public LiteralContext() { }
		public void copyFrom(LiteralContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class StringLiteralExpressionContext extends LiteralContext {
		public StringLiteralContext stringLiteral() {
			return getRuleContext(StringLiteralContext.class,0);
		}
		public StringLiteralExpressionContext(LiteralContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitStringLiteralExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class BooleanLiteralContext extends LiteralContext {
		public TerminalNode BOOLEAN_LITERAL() { return getToken(RuneScriptParser.BOOLEAN_LITERAL, 0); }
		public BooleanLiteralContext(LiteralContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitBooleanLiteral(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class HexLiteralContext extends LiteralContext {
		public TerminalNode HEX_LITERAL() { return getToken(RuneScriptParser.HEX_LITERAL, 0); }
		public HexLiteralContext(LiteralContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitHexLiteral(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class CoordLiteralContext extends LiteralContext {
		public TerminalNode COORD_LITERAL() { return getToken(RuneScriptParser.COORD_LITERAL, 0); }
		public CoordLiteralContext(LiteralContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitCoordLiteral(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class NullLiteralContext extends LiteralContext {
		public TerminalNode NULL_LITERAL() { return getToken(RuneScriptParser.NULL_LITERAL, 0); }
		public NullLiteralContext(LiteralContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitNullLiteral(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class IntegerLiteralContext extends LiteralContext {
		public TerminalNode INTEGER_LITERAL() { return getToken(RuneScriptParser.INTEGER_LITERAL, 0); }
		public IntegerLiteralContext(LiteralContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitIntegerLiteral(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class CharacterLiteralContext extends LiteralContext {
		public TerminalNode CHAR_LITERAL() { return getToken(RuneScriptParser.CHAR_LITERAL, 0); }
		public CharacterLiteralContext(LiteralContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitCharacterLiteral(this);
			else return visitor.visitChildren(this);
		}
	}

	public final LiteralContext literal() throws RecognitionException {
		LiteralContext _localctx = new LiteralContext(_ctx, getState());
		enterRule(_localctx, 64, RULE_literal);
		try {
			setState(414);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case INTEGER_LITERAL:
				_localctx = new IntegerLiteralContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(407);
				match(INTEGER_LITERAL);
				}
				break;
			case HEX_LITERAL:
				_localctx = new HexLiteralContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(408);
				match(HEX_LITERAL);
				}
				break;
			case COORD_LITERAL:
				_localctx = new CoordLiteralContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(409);
				match(COORD_LITERAL);
				}
				break;
			case BOOLEAN_LITERAL:
				_localctx = new BooleanLiteralContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(410);
				match(BOOLEAN_LITERAL);
				}
				break;
			case CHAR_LITERAL:
				_localctx = new CharacterLiteralContext(_localctx);
				enterOuterAlt(_localctx, 5);
				{
				setState(411);
				match(CHAR_LITERAL);
				}
				break;
			case NULL_LITERAL:
				_localctx = new NullLiteralContext(_localctx);
				enterOuterAlt(_localctx, 6);
				{
				setState(412);
				match(NULL_LITERAL);
				}
				break;
			case QUOTE_OPEN:
				_localctx = new StringLiteralExpressionContext(_localctx);
				enterOuterAlt(_localctx, 7);
				{
				setState(413);
				stringLiteral();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class StringLiteralContext extends ParserRuleContext {
		public TerminalNode QUOTE_OPEN() { return getToken(RuneScriptParser.QUOTE_OPEN, 0); }
		public TerminalNode QUOTE_CLOSE() { return getToken(RuneScriptParser.QUOTE_CLOSE, 0); }
		public List<StringLiteralContentContext> stringLiteralContent() {
			return getRuleContexts(StringLiteralContentContext.class);
		}
		public StringLiteralContentContext stringLiteralContent(int i) {
			return getRuleContext(StringLiteralContentContext.class,i);
		}
		public StringLiteralContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_stringLiteral; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitStringLiteral(this);
			else return visitor.visitChildren(this);
		}
	}

	public final StringLiteralContext stringLiteral() throws RecognitionException {
		StringLiteralContext _localctx = new StringLiteralContext(_ctx, getState());
		enterRule(_localctx, 66, RULE_stringLiteral);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(416);
			match(QUOTE_OPEN);
			setState(420);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==STRING_TEXT) {
				{
				{
				setState(417);
				stringLiteralContent();
				}
				}
				setState(422);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(423);
			match(QUOTE_CLOSE);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class StringLiteralContentContext extends ParserRuleContext {
		public TerminalNode STRING_TEXT() { return getToken(RuneScriptParser.STRING_TEXT, 0); }
		public StringLiteralContentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_stringLiteralContent; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitStringLiteralContent(this);
			else return visitor.visitChildren(this);
		}
	}

	public final StringLiteralContentContext stringLiteralContent() throws RecognitionException {
		StringLiteralContentContext _localctx = new StringLiteralContentContext(_ctx, getState());
		enterRule(_localctx, 68, RULE_stringLiteralContent);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(425);
			match(STRING_TEXT);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class JoinedStringContext extends ParserRuleContext {
		public TerminalNode QUOTE_OPEN() { return getToken(RuneScriptParser.QUOTE_OPEN, 0); }
		public TerminalNode QUOTE_CLOSE() { return getToken(RuneScriptParser.QUOTE_CLOSE, 0); }
		public List<StringLiteralContentContext> stringLiteralContent() {
			return getRuleContexts(StringLiteralContentContext.class);
		}
		public StringLiteralContentContext stringLiteralContent(int i) {
			return getRuleContext(StringLiteralContentContext.class,i);
		}
		public List<StringTagContext> stringTag() {
			return getRuleContexts(StringTagContext.class);
		}
		public StringTagContext stringTag(int i) {
			return getRuleContext(StringTagContext.class,i);
		}
		public List<StringPTagContext> stringPTag() {
			return getRuleContexts(StringPTagContext.class);
		}
		public StringPTagContext stringPTag(int i) {
			return getRuleContext(StringPTagContext.class,i);
		}
		public List<StringSwitchTagContext> stringSwitchTag() {
			return getRuleContexts(StringSwitchTagContext.class);
		}
		public StringSwitchTagContext stringSwitchTag(int i) {
			return getRuleContext(StringSwitchTagContext.class,i);
		}
		public List<StringTemplateContext> stringTemplate() {
			return getRuleContexts(StringTemplateContext.class);
		}
		public StringTemplateContext stringTemplate(int i) {
			return getRuleContext(StringTemplateContext.class,i);
		}
		public List<StringExpressionContext> stringExpression() {
			return getRuleContexts(StringExpressionContext.class);
		}
		public StringExpressionContext stringExpression(int i) {
			return getRuleContext(StringExpressionContext.class,i);
		}
		public JoinedStringContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_joinedString; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitJoinedString(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JoinedStringContext joinedString() throws RecognitionException {
		JoinedStringContext _localctx = new JoinedStringContext(_ctx, getState());
		enterRule(_localctx, 70, RULE_joinedString);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(427);
			match(QUOTE_OPEN);
			setState(436);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << STRING_TEXT) | (1L << STRING_TAG) | (1L << STRING_CLOSE_TAG) | (1L << STRING_PARTIAL_TAG) | (1L << STRING_P_TAG) | (1L << STRING_SWITCH_TAG) | (1L << STRING_EXPR_START) | (1L << STRING_TEMPLATE))) != 0)) {
				{
				setState(434);
				_errHandler.sync(this);
				switch (_input.LA(1)) {
				case STRING_TEXT:
					{
					setState(428);
					stringLiteralContent();
					}
					break;
				case STRING_TAG:
				case STRING_CLOSE_TAG:
				case STRING_PARTIAL_TAG:
					{
					setState(429);
					stringTag();
					}
					break;
				case STRING_P_TAG:
					{
					setState(430);
					stringPTag();
					}
					break;
				case STRING_SWITCH_TAG:
					{
					setState(431);
					stringSwitchTag();
					}
					break;
				case STRING_TEMPLATE:
					{
					setState(432);
					stringTemplate();
					}
					break;
				case STRING_EXPR_START:
					{
					setState(433);
					stringExpression();
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				}
				setState(438);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(439);
			match(QUOTE_CLOSE);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class StringTagContext extends ParserRuleContext {
		public TerminalNode STRING_TAG() { return getToken(RuneScriptParser.STRING_TAG, 0); }
		public TerminalNode STRING_CLOSE_TAG() { return getToken(RuneScriptParser.STRING_CLOSE_TAG, 0); }
		public TerminalNode STRING_PARTIAL_TAG() { return getToken(RuneScriptParser.STRING_PARTIAL_TAG, 0); }
		public StringTagContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_stringTag; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitStringTag(this);
			else return visitor.visitChildren(this);
		}
	}

	public final StringTagContext stringTag() throws RecognitionException {
		StringTagContext _localctx = new StringTagContext(_ctx, getState());
		enterRule(_localctx, 72, RULE_stringTag);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(441);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << STRING_TAG) | (1L << STRING_CLOSE_TAG) | (1L << STRING_PARTIAL_TAG))) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class StringPTagContext extends ParserRuleContext {
		public TerminalNode STRING_P_TAG() { return getToken(RuneScriptParser.STRING_P_TAG, 0); }
		public StringPTagContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_stringPTag; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitStringPTag(this);
			else return visitor.visitChildren(this);
		}
	}

	public final StringPTagContext stringPTag() throws RecognitionException {
		StringPTagContext _localctx = new StringPTagContext(_ctx, getState());
		enterRule(_localctx, 74, RULE_stringPTag);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(443);
			match(STRING_P_TAG);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class StringSwitchTagContext extends ParserRuleContext {
		public TerminalNode STRING_SWITCH_TAG() { return getToken(RuneScriptParser.STRING_SWITCH_TAG, 0); }
		public StringSwitchTagContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_stringSwitchTag; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitStringSwitchTag(this);
			else return visitor.visitChildren(this);
		}
	}

	public final StringSwitchTagContext stringSwitchTag() throws RecognitionException {
		StringSwitchTagContext _localctx = new StringSwitchTagContext(_ctx, getState());
		enterRule(_localctx, 76, RULE_stringSwitchTag);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(445);
			match(STRING_SWITCH_TAG);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class StringTemplateContext extends ParserRuleContext {
		public TerminalNode STRING_TEMPLATE() { return getToken(RuneScriptParser.STRING_TEMPLATE, 0); }
		public StringTemplateContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_stringTemplate; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitStringTemplate(this);
			else return visitor.visitChildren(this);
		}
	}

	public final StringTemplateContext stringTemplate() throws RecognitionException {
		StringTemplateContext _localctx = new StringTemplateContext(_ctx, getState());
		enterRule(_localctx, 78, RULE_stringTemplate);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(447);
			match(STRING_TEMPLATE);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class StringExpressionContext extends ParserRuleContext {
		public TerminalNode STRING_EXPR_START() { return getToken(RuneScriptParser.STRING_EXPR_START, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public TerminalNode STRING_EXPR_END() { return getToken(RuneScriptParser.STRING_EXPR_END, 0); }
		public StringExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_stringExpression; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitStringExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final StringExpressionContext stringExpression() throws RecognitionException {
		StringExpressionContext _localctx = new StringExpressionContext(_ctx, getState());
		enterRule(_localctx, 80, RULE_stringExpression);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(449);
			match(STRING_EXPR_START);
			setState(450);
			expression();
			setState(451);
			match(STRING_EXPR_END);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class IdentifierContext extends ParserRuleContext {
		public TerminalNode IDENTIFIER() { return getToken(RuneScriptParser.IDENTIFIER, 0); }
		public TerminalNode HEX_LITERAL() { return getToken(RuneScriptParser.HEX_LITERAL, 0); }
		public TerminalNode BOOLEAN_LITERAL() { return getToken(RuneScriptParser.BOOLEAN_LITERAL, 0); }
		public TerminalNode NULL_LITERAL() { return getToken(RuneScriptParser.NULL_LITERAL, 0); }
		public TerminalNode SWITCH_TYPE() { return getToken(RuneScriptParser.SWITCH_TYPE, 0); }
		public TerminalNode DEF_TYPE() { return getToken(RuneScriptParser.DEF_TYPE, 0); }
		public TerminalNode DEFAULT() { return getToken(RuneScriptParser.DEFAULT, 0); }
		public IdentifierContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_identifier; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitIdentifier(this);
			else return visitor.visitChildren(this);
		}
	}

	public final IdentifierContext identifier() throws RecognitionException {
		IdentifierContext _localctx = new IdentifierContext(_ctx, getState());
		enterRule(_localctx, 82, RULE_identifier);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(453);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << DEFAULT) | (1L << DEF_TYPE) | (1L << SWITCH_TYPE) | (1L << HEX_LITERAL) | (1L << BOOLEAN_LITERAL) | (1L << NULL_LITERAL) | (1L << IDENTIFIER))) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AdvancedIdentifierContext extends ParserRuleContext {
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public TerminalNode INTEGER_LITERAL() { return getToken(RuneScriptParser.INTEGER_LITERAL, 0); }
		public TerminalNode IF() { return getToken(RuneScriptParser.IF, 0); }
		public TerminalNode ELSE() { return getToken(RuneScriptParser.ELSE, 0); }
		public TerminalNode WHILE() { return getToken(RuneScriptParser.WHILE, 0); }
		public TerminalNode RETURN() { return getToken(RuneScriptParser.RETURN, 0); }
		public TerminalNode CALC() { return getToken(RuneScriptParser.CALC, 0); }
		public AdvancedIdentifierContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_advancedIdentifier; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitAdvancedIdentifier(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AdvancedIdentifierContext advancedIdentifier() throws RecognitionException {
		AdvancedIdentifierContext _localctx = new AdvancedIdentifierContext(_ctx, getState());
		enterRule(_localctx, 84, RULE_advancedIdentifier);
		try {
			setState(462);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case DEFAULT:
			case DEF_TYPE:
			case SWITCH_TYPE:
			case HEX_LITERAL:
			case BOOLEAN_LITERAL:
			case NULL_LITERAL:
			case IDENTIFIER:
				enterOuterAlt(_localctx, 1);
				{
				setState(455);
				identifier();
				}
				break;
			case INTEGER_LITERAL:
				enterOuterAlt(_localctx, 2);
				{
				setState(456);
				match(INTEGER_LITERAL);
				}
				break;
			case IF:
				enterOuterAlt(_localctx, 3);
				{
				setState(457);
				match(IF);
				}
				break;
			case ELSE:
				enterOuterAlt(_localctx, 4);
				{
				setState(458);
				match(ELSE);
				}
				break;
			case WHILE:
				enterOuterAlt(_localctx, 5);
				{
				setState(459);
				match(WHILE);
				}
				break;
			case RETURN:
				enterOuterAlt(_localctx, 6);
				{
				setState(460);
				match(RETURN);
				}
				break;
			case CALC:
				enterOuterAlt(_localctx, 7);
				{
				setState(461);
				match(CALC);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public boolean sempred(RuleContext _localctx, int ruleIndex, int predIndex) {
		switch (ruleIndex) {
		case 21:
			return condition_sempred((ConditionContext)_localctx, predIndex);
		case 23:
			return arithmetic_sempred((ArithmeticContext)_localctx, predIndex);
		}
		return true;
	}
	private boolean condition_sempred(ConditionContext _localctx, int predIndex) {
		switch (predIndex) {
		case 0:
			return precpred(_ctx, 5);
		case 1:
			return precpred(_ctx, 4);
		case 2:
			return precpred(_ctx, 3);
		case 3:
			return precpred(_ctx, 2);
		}
		return true;
	}
	private boolean arithmetic_sempred(ArithmeticContext _localctx, int predIndex) {
		switch (predIndex) {
		case 4:
			return precpred(_ctx, 5);
		case 5:
			return precpred(_ctx, 4);
		case 6:
			return precpred(_ctx, 3);
		case 7:
			return precpred(_ctx, 2);
		}
		return true;
	}

	public static final String _serializedATN =
		"\u0004\u0001:\u01d1\u0002\u0000\u0007\u0000\u0002\u0001\u0007\u0001\u0002"+
		"\u0002\u0007\u0002\u0002\u0003\u0007\u0003\u0002\u0004\u0007\u0004\u0002"+
		"\u0005\u0007\u0005\u0002\u0006\u0007\u0006\u0002\u0007\u0007\u0007\u0002"+
		"\b\u0007\b\u0002\t\u0007\t\u0002\n\u0007\n\u0002\u000b\u0007\u000b\u0002"+
		"\f\u0007\f\u0002\r\u0007\r\u0002\u000e\u0007\u000e\u0002\u000f\u0007\u000f"+
		"\u0002\u0010\u0007\u0010\u0002\u0011\u0007\u0011\u0002\u0012\u0007\u0012"+
		"\u0002\u0013\u0007\u0013\u0002\u0014\u0007\u0014\u0002\u0015\u0007\u0015"+
		"\u0002\u0016\u0007\u0016\u0002\u0017\u0007\u0017\u0002\u0018\u0007\u0018"+
		"\u0002\u0019\u0007\u0019\u0002\u001a\u0007\u001a\u0002\u001b\u0007\u001b"+
		"\u0002\u001c\u0007\u001c\u0002\u001d\u0007\u001d\u0002\u001e\u0007\u001e"+
		"\u0002\u001f\u0007\u001f\u0002 \u0007 \u0002!\u0007!\u0002\"\u0007\"\u0002"+
		"#\u0007#\u0002$\u0007$\u0002%\u0007%\u0002&\u0007&\u0002\'\u0007\'\u0002"+
		"(\u0007(\u0002)\u0007)\u0002*\u0007*\u0001\u0000\u0005\u0000X\b\u0000"+
		"\n\u0000\f\u0000[\t\u0000\u0001\u0000\u0001\u0000\u0001\u0001\u0001\u0001"+
		"\u0001\u0001\u0001\u0001\u0001\u0001\u0003\u0001d\b\u0001\u0001\u0001"+
		"\u0001\u0001\u0001\u0001\u0003\u0001i\b\u0001\u0001\u0001\u0001\u0001"+
		"\u0001\u0001\u0001\u0001\u0003\u0001o\b\u0001\u0001\u0001\u0003\u0001"+
		"r\b\u0001\u0003\u0001t\b\u0001\u0001\u0001\u0005\u0001w\b\u0001\n\u0001"+
		"\f\u0001z\t\u0001\u0001\u0002\u0001\u0002\u0001\u0002\u0005\u0002\u007f"+
		"\b\u0002\n\u0002\f\u0002\u0082\t\u0002\u0001\u0003\u0001\u0003\u0001\u0003"+
		"\u0001\u0003\u0001\u0004\u0001\u0004\u0001\u0004\u0005\u0004\u008b\b\u0004"+
		"\n\u0004\f\u0004\u008e\t\u0004\u0001\u0005\u0001\u0005\u0001\u0005\u0001"+
		"\u0005\u0001\u0005\u0001\u0005\u0001\u0005\u0001\u0005\u0001\u0005\u0001"+
		"\u0005\u0003\u0005\u009a\b\u0005\u0001\u0006\u0001\u0006\u0005\u0006\u009e"+
		"\b\u0006\n\u0006\f\u0006\u00a1\t\u0006\u0001\u0006\u0001\u0006\u0001\u0007"+
		"\u0001\u0007\u0001\u0007\u0003\u0007\u00a8\b\u0007\u0001\u0007\u0003\u0007"+
		"\u00ab\b\u0007\u0001\u0007\u0001\u0007\u0001\b\u0001\b\u0001\b\u0001\b"+
		"\u0001\b\u0001\b\u0001\b\u0003\b\u00b6\b\b\u0001\t\u0001\t\u0001\t\u0001"+
		"\t\u0001\t\u0001\t\u0001\n\u0001\n\u0001\n\u0001\n\u0005\n\u00c2\b\n\n"+
		"\n\f\n\u00c5\t\n\u0001\n\u0001\n\u0001\u000b\u0001\u000b\u0001\u000b\u0003"+
		"\u000b\u00cc\b\u000b\u0001\u000b\u0001\u000b\u0005\u000b\u00d0\b\u000b"+
		"\n\u000b\f\u000b\u00d3\t\u000b\u0001\f\u0001\f\u0001\f\u0001\f\u0001\f"+
		"\u0003\f\u00da\b\f\u0001\f\u0001\f\u0001\r\u0001\r\u0001\r\u0001\r\u0001"+
		"\r\u0001\r\u0001\u000e\u0001\u000e\u0001\u000e\u0001\u000e\u0001\u000e"+
		"\u0001\u000f\u0001\u000f\u0001\u000f\u0001\u0010\u0001\u0010\u0001\u0011"+
		"\u0001\u0011\u0001\u0011\u0005\u0011\u00f1\b\u0011\n\u0011\f\u0011\u00f4"+
		"\t\u0011\u0001\u0012\u0001\u0012\u0001\u0012\u0001\u0012\u0001\u0013\u0001"+
		"\u0013\u0001\u0013\u0001\u0014\u0001\u0014\u0001\u0014\u0001\u0014\u0001"+
		"\u0014\u0001\u0014\u0001\u0014\u0001\u0014\u0001\u0014\u0001\u0014\u0001"+
		"\u0014\u0001\u0014\u0001\u0014\u0001\u0014\u0001\u0014\u0003\u0014\u010c"+
		"\b\u0014\u0001\u0015\u0001\u0015\u0001\u0015\u0001\u0015\u0001\u0015\u0001"+
		"\u0015\u0003\u0015\u0114\b\u0015\u0001\u0015\u0001\u0015\u0001\u0015\u0001"+
		"\u0015\u0001\u0015\u0001\u0015\u0001\u0015\u0001\u0015\u0001\u0015\u0001"+
		"\u0015\u0001\u0015\u0001\u0015\u0005\u0015\u0122\b\u0015\n\u0015\f\u0015"+
		"\u0125\t\u0015\u0001\u0016\u0001\u0016\u0001\u0016\u0001\u0016\u0001\u0016"+
		"\u0001\u0017\u0001\u0017\u0001\u0017\u0001\u0017\u0001\u0017\u0001\u0017"+
		"\u0003\u0017\u0132\b\u0017\u0001\u0017\u0001\u0017\u0001\u0017\u0001\u0017"+
		"\u0001\u0017\u0001\u0017\u0001\u0017\u0001\u0017\u0001\u0017\u0001\u0017"+
		"\u0001\u0017\u0001\u0017\u0005\u0017\u0140\b\u0017\n\u0017\f\u0017\u0143"+
		"\t\u0017\u0001\u0018\u0001\u0018\u0001\u0018\u0001\u0018\u0003\u0018\u0149"+
		"\b\u0018\u0001\u0018\u0001\u0018\u0001\u0018\u0003\u0018\u014e\b\u0018"+
		"\u0001\u0018\u0001\u0018\u0001\u0018\u0001\u0018\u0001\u0018\u0003\u0018"+
		"\u0155\b\u0018\u0001\u0018\u0001\u0018\u0001\u0018\u0001\u0018\u0001\u0018"+
		"\u0001\u0018\u0003\u0018\u015d\b\u0018\u0001\u0018\u0003\u0018\u0160\b"+
		"\u0018\u0001\u0018\u0001\u0018\u0001\u0018\u0001\u0018\u0003\u0018\u0166"+
		"\b\u0018\u0001\u0018\u0003\u0018\u0169\b\u0018\u0003\u0018\u016b\b\u0018"+
		"\u0001\u0019\u0001\u0019\u0001\u0019\u0003\u0019\u0170\b\u0019\u0001\u0019"+
		"\u0003\u0019\u0173\b\u0019\u0001\u0019\u0001\u0019\u0003\u0019\u0177\b"+
		"\u0019\u0001\u0019\u0003\u0019\u017a\b\u0019\u0001\u0019\u0001\u0019\u0001"+
		"\u001a\u0001\u001a\u0001\u001a\u0005\u001a\u0181\b\u001a\n\u001a\f\u001a"+
		"\u0184\t\u001a\u0001\u001b\u0001\u001b\u0001\u001b\u0003\u001b\u0189\b"+
		"\u001b\u0001\u001c\u0001\u001c\u0001\u001c\u0001\u001d\u0001\u001d\u0001"+
		"\u001d\u0001\u001d\u0001\u001e\u0001\u001e\u0001\u001e\u0001\u001f\u0001"+
		"\u001f\u0001\u001f\u0001 \u0001 \u0001 \u0001 \u0001 \u0001 \u0001 \u0003"+
		" \u019f\b \u0001!\u0001!\u0005!\u01a3\b!\n!\f!\u01a6\t!\u0001!\u0001!"+
		"\u0001\"\u0001\"\u0001#\u0001#\u0001#\u0001#\u0001#\u0001#\u0001#\u0005"+
		"#\u01b3\b#\n#\f#\u01b6\t#\u0001#\u0001#\u0001$\u0001$\u0001%\u0001%\u0001"+
		"&\u0001&\u0001\'\u0001\'\u0001(\u0001(\u0001(\u0001(\u0001)\u0001)\u0001"+
		"*\u0001*\u0001*\u0001*\u0001*\u0001*\u0001*\u0003*\u01cf\b*\u0001*\u0000"+
		"\u0002*.+\u0000\u0002\u0004\u0006\b\n\f\u000e\u0010\u0012\u0014\u0016"+
		"\u0018\u001a\u001c\u001e \"$&(*,.02468:<>@BDFHJLNPRT\u0000\u0007\u0001"+
		"\u0000\u001b\u001c\u0001\u0000\u0017\u001a\u0001\u0000\u0011\u0012\u0001"+
		"\u0000\f\u000e\u0001\u0000\n\u000b\u0001\u000035\u0006\u0000!!$%\'\')"+
		")++//\u01f9\u0000Y\u0001\u0000\u0000\u0000\u0002^\u0001\u0000\u0000\u0000"+
		"\u0004{\u0001\u0000\u0000\u0000\u0006\u0083\u0001\u0000\u0000\u0000\b"+
		"\u0087\u0001\u0000\u0000\u0000\n\u0099\u0001\u0000\u0000\u0000\f\u009b"+
		"\u0001\u0000\u0000\u0000\u000e\u00a4\u0001\u0000\u0000\u0000\u0010\u00ae"+
		"\u0001\u0000\u0000\u0000\u0012\u00b7\u0001\u0000\u0000\u0000\u0014\u00bd"+
		"\u0001\u0000\u0000\u0000\u0016\u00c8\u0001\u0000\u0000\u0000\u0018\u00d4"+
		"\u0001\u0000\u0000\u0000\u001a\u00dd\u0001\u0000\u0000\u0000\u001c\u00e3"+
		"\u0001\u0000\u0000\u0000\u001e\u00e8\u0001\u0000\u0000\u0000 \u00eb\u0001"+
		"\u0000\u0000\u0000\"\u00ed\u0001\u0000\u0000\u0000$\u00f5\u0001\u0000"+
		"\u0000\u0000&\u00f9\u0001\u0000\u0000\u0000(\u010b\u0001\u0000\u0000\u0000"+
		"*\u0113\u0001\u0000\u0000\u0000,\u0126\u0001\u0000\u0000\u0000.\u0131"+
		"\u0001\u0000\u0000\u00000\u016a\u0001\u0000\u0000\u00002\u016c\u0001\u0000"+
		"\u0000\u00004\u017d\u0001\u0000\u0000\u00006\u0188\u0001\u0000\u0000\u0000"+
		"8\u018a\u0001\u0000\u0000\u0000:\u018d\u0001\u0000\u0000\u0000<\u0191"+
		"\u0001\u0000\u0000\u0000>\u0194\u0001\u0000\u0000\u0000@\u019e\u0001\u0000"+
		"\u0000\u0000B\u01a0\u0001\u0000\u0000\u0000D\u01a9\u0001\u0000\u0000\u0000"+
		"F\u01ab\u0001\u0000\u0000\u0000H\u01b9\u0001\u0000\u0000\u0000J\u01bb"+
		"\u0001\u0000\u0000\u0000L\u01bd\u0001\u0000\u0000\u0000N\u01bf\u0001\u0000"+
		"\u0000\u0000P\u01c1\u0001\u0000\u0000\u0000R\u01c5\u0001\u0000\u0000\u0000"+
		"T\u01ce\u0001\u0000\u0000\u0000VX\u0003\u0002\u0001\u0000WV\u0001\u0000"+
		"\u0000\u0000X[\u0001\u0000\u0000\u0000YW\u0001\u0000\u0000\u0000YZ\u0001"+
		"\u0000\u0000\u0000Z\\\u0001\u0000\u0000\u0000[Y\u0001\u0000\u0000\u0000"+
		"\\]\u0005\u0000\u0000\u0001]\u0001\u0001\u0000\u0000\u0000^_\u0005\u0006"+
		"\u0000\u0000_`\u0003R)\u0000`a\u0005\u0005\u0000\u0000ac\u0003R)\u0000"+
		"bd\u0005\f\u0000\u0000cb\u0001\u0000\u0000\u0000cd\u0001\u0000\u0000\u0000"+
		"de\u0001\u0000\u0000\u0000es\u0005\u0007\u0000\u0000fh\u0005\u0001\u0000"+
		"\u0000gi\u0003\u0004\u0002\u0000hg\u0001\u0000\u0000\u0000hi\u0001\u0000"+
		"\u0000\u0000ij\u0001\u0000\u0000\u0000jk\u0005\u0002\u0000\u0000kq\u0001"+
		"\u0000\u0000\u0000ln\u0005\u0001\u0000\u0000mo\u0003\b\u0004\u0000nm\u0001"+
		"\u0000\u0000\u0000no\u0001\u0000\u0000\u0000op\u0001\u0000\u0000\u0000"+
		"pr\u0005\u0002\u0000\u0000ql\u0001\u0000\u0000\u0000qr\u0001\u0000\u0000"+
		"\u0000rt\u0001\u0000\u0000\u0000sf\u0001\u0000\u0000\u0000st\u0001\u0000"+
		"\u0000\u0000tx\u0001\u0000\u0000\u0000uw\u0003\n\u0005\u0000vu\u0001\u0000"+
		"\u0000\u0000wz\u0001\u0000\u0000\u0000xv\u0001\u0000\u0000\u0000xy\u0001"+
		"\u0000\u0000\u0000y\u0003\u0001\u0000\u0000\u0000zx\u0001\u0000\u0000"+
		"\u0000{\u0080\u0003\u0006\u0003\u0000|}\u0005\u0005\u0000\u0000}\u007f"+
		"\u0003\u0006\u0003\u0000~|\u0001\u0000\u0000\u0000\u007f\u0082\u0001\u0000"+
		"\u0000\u0000\u0080~\u0001\u0000\u0000\u0000\u0080\u0081\u0001\u0000\u0000"+
		"\u0000\u0081\u0005\u0001\u0000\u0000\u0000\u0082\u0080\u0001\u0000\u0000"+
		"\u0000\u0083\u0084\u0005/\u0000\u0000\u0084\u0085\u0005\u0013\u0000\u0000"+
		"\u0085\u0086\u0003T*\u0000\u0086\u0007\u0001\u0000\u0000\u0000\u0087\u008c"+
		"\u0005/\u0000\u0000\u0088\u0089\u0005\u0005\u0000\u0000\u0089\u008b\u0005"+
		"/\u0000\u0000\u008a\u0088\u0001\u0000\u0000\u0000\u008b\u008e\u0001\u0000"+
		"\u0000\u0000\u008c\u008a\u0001\u0000\u0000\u0000\u008c\u008d\u0001\u0000"+
		"\u0000\u0000\u008d\t\u0001\u0000\u0000\u0000\u008e\u008c\u0001\u0000\u0000"+
		"\u0000\u008f\u009a\u0003\f\u0006\u0000\u0090\u009a\u0003\u000e\u0007\u0000"+
		"\u0091\u009a\u0003\u0010\b\u0000\u0092\u009a\u0003\u0012\t\u0000\u0093"+
		"\u009a\u0003\u0014\n\u0000\u0094\u009a\u0003\u0018\f\u0000\u0095\u009a"+
		"\u0003\u001a\r\u0000\u0096\u009a\u0003\u001c\u000e\u0000\u0097\u009a\u0003"+
		"\u001e\u000f\u0000\u0098\u009a\u0003 \u0010\u0000\u0099\u008f\u0001\u0000"+
		"\u0000\u0000\u0099\u0090\u0001\u0000\u0000\u0000\u0099\u0091\u0001\u0000"+
		"\u0000\u0000\u0099\u0092\u0001\u0000\u0000\u0000\u0099\u0093\u0001\u0000"+
		"\u0000\u0000\u0099\u0094\u0001\u0000\u0000\u0000\u0099\u0095\u0001\u0000"+
		"\u0000\u0000\u0099\u0096\u0001\u0000\u0000\u0000\u0099\u0097\u0001\u0000"+
		"\u0000\u0000\u0099\u0098\u0001\u0000\u0000\u0000\u009a\u000b\u0001\u0000"+
		"\u0000\u0000\u009b\u009f\u0005\b\u0000\u0000\u009c\u009e\u0003\n\u0005"+
		"\u0000\u009d\u009c\u0001\u0000\u0000\u0000\u009e\u00a1\u0001\u0000\u0000"+
		"\u0000\u009f\u009d\u0001\u0000\u0000\u0000\u009f\u00a0\u0001\u0000\u0000"+
		"\u0000\u00a0\u00a2\u0001\u0000\u0000\u0000\u00a1\u009f\u0001\u0000\u0000"+
		"\u0000\u00a2\u00a3\u0005\t\u0000\u0000\u00a3\r\u0001\u0000\u0000\u0000"+
		"\u00a4\u00aa\u0005\"\u0000\u0000\u00a5\u00a7\u0005\u0001\u0000\u0000\u00a6"+
		"\u00a8\u0003\"\u0011\u0000\u00a7\u00a6\u0001\u0000\u0000\u0000\u00a7\u00a8"+
		"\u0001\u0000\u0000\u0000\u00a8\u00a9\u0001\u0000\u0000\u0000\u00a9\u00ab"+
		"\u0005\u0002\u0000\u0000\u00aa\u00a5\u0001\u0000\u0000\u0000\u00aa\u00ab"+
		"\u0001\u0000\u0000\u0000\u00ab\u00ac\u0001\u0000\u0000\u0000\u00ac\u00ad"+
		"\u0005\u0004\u0000\u0000\u00ad\u000f\u0001\u0000\u0000\u0000\u00ae\u00af"+
		"\u0005\u001d\u0000\u0000\u00af\u00b0\u0005\u0001\u0000\u0000\u00b0\u00b1"+
		"\u0003*\u0015\u0000\u00b1\u00b2\u0005\u0002\u0000\u0000\u00b2\u00b5\u0003"+
		"\n\u0005\u0000\u00b3\u00b4\u0005\u001e\u0000\u0000\u00b4\u00b6\u0003\n"+
		"\u0005\u0000\u00b5\u00b3\u0001\u0000\u0000\u0000\u00b5\u00b6\u0001\u0000"+
		"\u0000\u0000\u00b6\u0011\u0001\u0000\u0000\u0000\u00b7\u00b8\u0005\u001f"+
		"\u0000\u0000\u00b8\u00b9\u0005\u0001\u0000\u0000\u00b9\u00ba\u0003*\u0015"+
		"\u0000\u00ba\u00bb\u0005\u0002\u0000\u0000\u00bb\u00bc\u0003\n\u0005\u0000"+
		"\u00bc\u0013\u0001\u0000\u0000\u0000\u00bd\u00be\u0005%\u0000\u0000\u00be"+
		"\u00bf\u0003$\u0012\u0000\u00bf\u00c3\u0005\b\u0000\u0000\u00c0\u00c2"+
		"\u0003\u0016\u000b\u0000\u00c1\u00c0\u0001\u0000\u0000\u0000\u00c2\u00c5"+
		"\u0001\u0000\u0000\u0000\u00c3\u00c1\u0001\u0000\u0000\u0000\u00c3\u00c4"+
		"\u0001\u0000\u0000\u0000\u00c4\u00c6\u0001\u0000\u0000\u0000\u00c5\u00c3"+
		"\u0001\u0000\u0000\u0000\u00c6\u00c7\u0005\t\u0000\u0000\u00c7\u0015\u0001"+
		"\u0000\u0000\u0000\u00c8\u00cb\u0005 \u0000\u0000\u00c9\u00cc\u0005!\u0000"+
		"\u0000\u00ca\u00cc\u0003\"\u0011\u0000\u00cb\u00c9\u0001\u0000\u0000\u0000"+
		"\u00cb\u00ca\u0001\u0000\u0000\u0000\u00cc\u00cd\u0001\u0000\u0000\u0000"+
		"\u00cd\u00d1\u0005\u0003\u0000\u0000\u00ce\u00d0\u0003\n\u0005\u0000\u00cf"+
		"\u00ce\u0001\u0000\u0000\u0000\u00d0\u00d3\u0001\u0000\u0000\u0000\u00d1"+
		"\u00cf\u0001\u0000\u0000\u0000\u00d1\u00d2\u0001\u0000\u0000\u0000\u00d2"+
		"\u0017\u0001\u0000\u0000\u0000\u00d3\u00d1\u0001\u0000\u0000\u0000\u00d4"+
		"\u00d5\u0005$\u0000\u0000\u00d5\u00d6\u0005\u0013\u0000\u0000\u00d6\u00d9"+
		"\u0003T*\u0000\u00d7\u00d8\u0005\u0011\u0000\u0000\u00d8\u00da\u0003("+
		"\u0014\u0000\u00d9\u00d7\u0001\u0000\u0000\u0000\u00d9\u00da\u0001\u0000"+
		"\u0000\u0000\u00da\u00db\u0001\u0000\u0000\u0000\u00db\u00dc\u0005\u0004"+
		"\u0000\u0000\u00dc\u0019\u0001\u0000\u0000\u0000\u00dd\u00de\u0005$\u0000"+
		"\u0000\u00de\u00df\u0005\u0013\u0000\u0000\u00df\u00e0\u0003T*\u0000\u00e0"+
		"\u00e1\u0003$\u0012\u0000\u00e1\u00e2\u0005\u0004\u0000\u0000\u00e2\u001b"+
		"\u0001\u0000\u0000\u0000\u00e3\u00e4\u00034\u001a\u0000\u00e4\u00e5\u0005"+
		"\u0011\u0000\u0000\u00e5\u00e6\u0003\"\u0011\u0000\u00e6\u00e7\u0005\u0004"+
		"\u0000\u0000\u00e7\u001d\u0001\u0000\u0000\u0000\u00e8\u00e9\u0003(\u0014"+
		"\u0000\u00e9\u00ea\u0005\u0004\u0000\u0000\u00ea\u001f\u0001\u0000\u0000"+
		"\u0000\u00eb\u00ec\u0005\u0004\u0000\u0000\u00ec!\u0001\u0000\u0000\u0000"+
		"\u00ed\u00f2\u0003(\u0014\u0000\u00ee\u00ef\u0005\u0005\u0000\u0000\u00ef"+
		"\u00f1\u0003(\u0014\u0000\u00f0\u00ee\u0001\u0000\u0000\u0000\u00f1\u00f4"+
		"\u0001\u0000\u0000\u0000\u00f2\u00f0\u0001\u0000\u0000\u0000\u00f2\u00f3"+
		"\u0001\u0000\u0000\u0000\u00f3#\u0001\u0000\u0000\u0000\u00f4\u00f2\u0001"+
		"\u0000\u0000\u0000\u00f5\u00f6\u0005\u0001\u0000\u0000\u00f6\u00f7\u0003"+
		"(\u0014\u0000\u00f7\u00f8\u0005\u0002\u0000\u0000\u00f8%\u0001\u0000\u0000"+
		"\u0000\u00f9\u00fa\u0003(\u0014\u0000\u00fa\u00fb\u0005\u0000\u0000\u0001"+
		"\u00fb\'\u0001\u0000\u0000\u0000\u00fc\u010c\u0003$\u0012\u0000\u00fd"+
		"\u010c\u0003,\u0016\u0000\u00fe\u010c\u00030\u0018\u0000\u00ff\u010c\u0003"+
		"8\u001c\u0000\u0100\u010c\u0003:\u001d\u0000\u0101\u010c\u0003<\u001e"+
		"\u0000\u0102\u010c\u0003>\u001f\u0000\u0103\u010c\u0003@ \u0000\u0104"+
		"\u010c\u0003F#\u0000\u0105\u0106\u0007\u0000\u0000\u0000\u0106\u010c\u0003"+
		"6\u001b\u0000\u0107\u0108\u00036\u001b\u0000\u0108\u0109\u0007\u0000\u0000"+
		"\u0000\u0109\u010c\u0001\u0000\u0000\u0000\u010a\u010c\u0003R)\u0000\u010b"+
		"\u00fc\u0001\u0000\u0000\u0000\u010b\u00fd\u0001\u0000\u0000\u0000\u010b"+
		"\u00fe\u0001\u0000\u0000\u0000\u010b\u00ff\u0001\u0000\u0000\u0000\u010b"+
		"\u0100\u0001\u0000\u0000\u0000\u010b\u0101\u0001\u0000\u0000\u0000\u010b"+
		"\u0102\u0001\u0000\u0000\u0000\u010b\u0103\u0001\u0000\u0000\u0000\u010b"+
		"\u0104\u0001\u0000\u0000\u0000\u010b\u0105\u0001\u0000\u0000\u0000\u010b"+
		"\u0107\u0001\u0000\u0000\u0000\u010b\u010a\u0001\u0000\u0000\u0000\u010c"+
		")\u0001\u0000\u0000\u0000\u010d\u010e\u0006\u0015\uffff\uffff\u0000\u010e"+
		"\u010f\u0005\u0001\u0000\u0000\u010f\u0110\u0003*\u0015\u0000\u0110\u0111"+
		"\u0005\u0002\u0000\u0000\u0111\u0114\u0001\u0000\u0000\u0000\u0112\u0114"+
		"\u0003(\u0014\u0000\u0113\u010d\u0001\u0000\u0000\u0000\u0113\u0112\u0001"+
		"\u0000\u0000\u0000\u0114\u0123\u0001\u0000\u0000\u0000\u0115\u0116\n\u0005"+
		"\u0000\u0000\u0116\u0117\u0007\u0001\u0000\u0000\u0117\u0122\u0003*\u0015"+
		"\u0006\u0118\u0119\n\u0004\u0000\u0000\u0119\u011a\u0007\u0002\u0000\u0000"+
		"\u011a\u0122\u0003*\u0015\u0005\u011b\u011c\n\u0003\u0000\u0000\u011c"+
		"\u011d\u0005\u000f\u0000\u0000\u011d\u0122\u0003*\u0015\u0004\u011e\u011f"+
		"\n\u0002\u0000\u0000\u011f\u0120\u0005\u0010\u0000\u0000\u0120\u0122\u0003"+
		"*\u0015\u0003\u0121\u0115\u0001\u0000\u0000\u0000\u0121\u0118\u0001\u0000"+
		"\u0000\u0000\u0121\u011b\u0001\u0000\u0000\u0000\u0121\u011e\u0001\u0000"+
		"\u0000\u0000\u0122\u0125\u0001\u0000\u0000\u0000\u0123\u0121\u0001\u0000"+
		"\u0000\u0000\u0123\u0124\u0001\u0000\u0000\u0000\u0124+\u0001\u0000\u0000"+
		"\u0000\u0125\u0123\u0001\u0000\u0000\u0000\u0126\u0127\u0005#\u0000\u0000"+
		"\u0127\u0128\u0005\u0001\u0000\u0000\u0128\u0129\u0003.\u0017\u0000\u0129"+
		"\u012a\u0005\u0002\u0000\u0000\u012a-\u0001\u0000\u0000\u0000\u012b\u012c"+
		"\u0006\u0017\uffff\uffff\u0000\u012c\u012d\u0005\u0001\u0000\u0000\u012d"+
		"\u012e\u0003.\u0017\u0000\u012e\u012f\u0005\u0002\u0000\u0000\u012f\u0132"+
		"\u0001\u0000\u0000\u0000\u0130\u0132\u0003(\u0014\u0000\u0131\u012b\u0001"+
		"\u0000\u0000\u0000\u0131\u0130\u0001\u0000\u0000\u0000\u0132\u0141\u0001"+
		"\u0000\u0000\u0000\u0133\u0134\n\u0005\u0000\u0000\u0134\u0135\u0007\u0003"+
		"\u0000\u0000\u0135\u0140\u0003.\u0017\u0006\u0136\u0137\n\u0004\u0000"+
		"\u0000\u0137\u0138\u0007\u0004\u0000\u0000\u0138\u0140\u0003.\u0017\u0005"+
		"\u0139\u013a\n\u0003\u0000\u0000\u013a\u013b\u0005\u000f\u0000\u0000\u013b"+
		"\u0140\u0003.\u0017\u0004\u013c\u013d\n\u0002\u0000\u0000\u013d\u013e"+
		"\u0005\u0010\u0000\u0000\u013e\u0140\u0003.\u0017\u0003\u013f\u0133\u0001"+
		"\u0000\u0000\u0000\u013f\u0136\u0001\u0000\u0000\u0000\u013f\u0139\u0001"+
		"\u0000\u0000\u0000\u013f\u013c\u0001\u0000\u0000\u0000\u0140\u0143\u0001"+
		"\u0000\u0000\u0000\u0141\u013f\u0001\u0000\u0000\u0000\u0141\u0142\u0001"+
		"\u0000\u0000\u0000\u0142/\u0001\u0000\u0000\u0000\u0143\u0141\u0001\u0000"+
		"\u0000\u0000\u0144\u0145\u0003R)\u0000\u0145\u0146\u0005\f\u0000\u0000"+
		"\u0146\u0148\u0005\u0001\u0000\u0000\u0147\u0149\u0003\"\u0011\u0000\u0148"+
		"\u0147\u0001\u0000\u0000\u0000\u0148\u0149\u0001\u0000\u0000\u0000\u0149"+
		"\u014a\u0001\u0000\u0000\u0000\u014a\u014b\u0005\u0002\u0000\u0000\u014b"+
		"\u014d\u0005\u0001\u0000\u0000\u014c\u014e\u0003\"\u0011\u0000\u014d\u014c"+
		"\u0001\u0000\u0000\u0000\u014d\u014e\u0001\u0000\u0000\u0000\u014e\u014f"+
		"\u0001\u0000\u0000\u0000\u014f\u0150\u0005\u0002\u0000\u0000\u0150\u016b"+
		"\u0001\u0000\u0000\u0000\u0151\u0152\u0003R)\u0000\u0152\u0154\u0005\u0001"+
		"\u0000\u0000\u0153\u0155\u0003\"\u0011\u0000\u0154\u0153\u0001\u0000\u0000"+
		"\u0000\u0154\u0155\u0001\u0000\u0000\u0000\u0155\u0156\u0001\u0000\u0000"+
		"\u0000\u0156\u0157\u0005\u0002\u0000\u0000\u0157\u016b\u0001\u0000\u0000"+
		"\u0000\u0158\u0159\u0005\u0015\u0000\u0000\u0159\u015f\u0003R)\u0000\u015a"+
		"\u015c\u0005\u0001\u0000\u0000\u015b\u015d\u0003\"\u0011\u0000\u015c\u015b"+
		"\u0001\u0000\u0000\u0000\u015c\u015d\u0001\u0000\u0000\u0000\u015d\u015e"+
		"\u0001\u0000\u0000\u0000\u015e\u0160\u0005\u0002\u0000\u0000\u015f\u015a"+
		"\u0001\u0000\u0000\u0000\u015f\u0160\u0001\u0000\u0000\u0000\u0160\u016b"+
		"\u0001\u0000\u0000\u0000\u0161\u0162\u0005\u0016\u0000\u0000\u0162\u0168"+
		"\u0003R)\u0000\u0163\u0165\u0005\u0001\u0000\u0000\u0164\u0166\u0003\""+
		"\u0011\u0000\u0165\u0164\u0001\u0000\u0000\u0000\u0165\u0166\u0001\u0000"+
		"\u0000\u0000\u0166\u0167\u0001\u0000\u0000\u0000\u0167\u0169\u0005\u0002"+
		"\u0000\u0000\u0168\u0163\u0001\u0000\u0000\u0000\u0168\u0169\u0001\u0000"+
		"\u0000\u0000\u0169\u016b\u0001\u0000\u0000\u0000\u016a\u0144\u0001\u0000"+
		"\u0000\u0000\u016a\u0151\u0001\u0000\u0000\u0000\u016a\u0158\u0001\u0000"+
		"\u0000\u0000\u016a\u0161\u0001\u0000\u0000\u0000\u016b1\u0001\u0000\u0000"+
		"\u0000\u016c\u0172\u0003R)\u0000\u016d\u016f\u0005\u0001\u0000\u0000\u016e"+
		"\u0170\u0003\"\u0011\u0000\u016f\u016e\u0001\u0000\u0000\u0000\u016f\u0170"+
		"\u0001\u0000\u0000\u0000\u0170\u0171\u0001\u0000\u0000\u0000\u0171\u0173"+
		"\u0005\u0002\u0000\u0000\u0172\u016d\u0001\u0000\u0000\u0000\u0172\u0173"+
		"\u0001\u0000\u0000\u0000\u0173\u0179\u0001\u0000\u0000\u0000\u0174\u0176"+
		"\u0005\b\u0000\u0000\u0175\u0177\u0003\"\u0011\u0000\u0176\u0175\u0001"+
		"\u0000\u0000\u0000\u0176\u0177\u0001\u0000\u0000\u0000\u0177\u0178\u0001"+
		"\u0000\u0000\u0000\u0178\u017a\u0005\t\u0000\u0000\u0179\u0174\u0001\u0000"+
		"\u0000\u0000\u0179\u017a\u0001\u0000\u0000\u0000\u017a\u017b\u0001\u0000"+
		"\u0000\u0000\u017b\u017c\u0005\u0000\u0000\u0001\u017c3\u0001\u0000\u0000"+
		"\u0000\u017d\u0182\u00036\u001b\u0000\u017e\u017f\u0005\u0005\u0000\u0000"+
		"\u017f\u0181\u00036\u001b\u0000\u0180\u017e\u0001\u0000\u0000\u0000\u0181"+
		"\u0184\u0001\u0000\u0000\u0000\u0182\u0180\u0001\u0000\u0000\u0000\u0182"+
		"\u0183\u0001\u0000\u0000\u0000\u01835\u0001\u0000\u0000\u0000\u0184\u0182"+
		"\u0001\u0000\u0000\u0000\u0185\u0189\u00038\u001c\u0000\u0186\u0189\u0003"+
		":\u001d\u0000\u0187\u0189\u0003<\u001e\u0000\u0188\u0185\u0001\u0000\u0000"+
		"\u0000\u0188\u0186\u0001\u0000\u0000\u0000\u0188\u0187\u0001\u0000\u0000"+
		"\u0000\u01897\u0001\u0000\u0000\u0000\u018a\u018b\u0005\u0013\u0000\u0000"+
		"\u018b\u018c\u0003T*\u0000\u018c9\u0001\u0000\u0000\u0000\u018d\u018e"+
		"\u0005\u0013\u0000\u0000\u018e\u018f\u0003T*\u0000\u018f\u0190\u0003$"+
		"\u0012\u0000\u0190;\u0001\u0000\u0000\u0000\u0191\u0192\u0005\u000e\u0000"+
		"\u0000\u0192\u0193\u0003T*\u0000\u0193=\u0001\u0000\u0000\u0000\u0194"+
		"\u0195\u0005\u0014\u0000\u0000\u0195\u0196\u0003T*\u0000\u0196?\u0001"+
		"\u0000\u0000\u0000\u0197\u019f\u0005&\u0000\u0000\u0198\u019f\u0005\'"+
		"\u0000\u0000\u0199\u019f\u0005(\u0000\u0000\u019a\u019f\u0005)\u0000\u0000"+
		"\u019b\u019f\u0005*\u0000\u0000\u019c\u019f\u0005+\u0000\u0000\u019d\u019f"+
		"\u0003B!\u0000\u019e\u0197\u0001\u0000\u0000\u0000\u019e\u0198\u0001\u0000"+
		"\u0000\u0000\u019e\u0199\u0001\u0000\u0000\u0000\u019e\u019a\u0001\u0000"+
		"\u0000\u0000\u019e\u019b\u0001\u0000\u0000\u0000\u019e\u019c\u0001\u0000"+
		"\u0000\u0000\u019e\u019d\u0001\u0000\u0000\u0000\u019fA\u0001\u0000\u0000"+
		"\u0000\u01a0\u01a4\u0005.\u0000\u0000\u01a1\u01a3\u0003D\"\u0000\u01a2"+
		"\u01a1\u0001\u0000\u0000\u0000\u01a3\u01a6\u0001\u0000\u0000\u0000\u01a4"+
		"\u01a2\u0001\u0000\u0000\u0000\u01a4\u01a5\u0001\u0000\u0000\u0000\u01a5"+
		"\u01a7\u0001\u0000\u0000\u0000\u01a6\u01a4\u0001\u0000\u0000\u0000\u01a7"+
		"\u01a8\u00051\u0000\u0000\u01a8C\u0001\u0000\u0000\u0000\u01a9\u01aa\u0005"+
		"2\u0000\u0000\u01aaE\u0001\u0000\u0000\u0000\u01ab\u01b4\u0005.\u0000"+
		"\u0000\u01ac\u01b3\u0003D\"\u0000\u01ad\u01b3\u0003H$\u0000\u01ae\u01b3"+
		"\u0003J%\u0000\u01af\u01b3\u0003L&\u0000\u01b0\u01b3\u0003N\'\u0000\u01b1"+
		"\u01b3\u0003P(\u0000\u01b2\u01ac\u0001\u0000\u0000\u0000\u01b2\u01ad\u0001"+
		"\u0000\u0000\u0000\u01b2\u01ae\u0001\u0000\u0000\u0000\u01b2\u01af\u0001"+
		"\u0000\u0000\u0000\u01b2\u01b0\u0001\u0000\u0000\u0000\u01b2\u01b1\u0001"+
		"\u0000\u0000\u0000\u01b3\u01b6\u0001\u0000\u0000\u0000\u01b4\u01b2\u0001"+
		"\u0000\u0000\u0000\u01b4\u01b5\u0001\u0000\u0000\u0000\u01b5\u01b7\u0001"+
		"\u0000\u0000\u0000\u01b6\u01b4\u0001\u0000\u0000\u0000\u01b7\u01b8\u0005"+
		"1\u0000\u0000\u01b8G\u0001\u0000\u0000\u0000\u01b9\u01ba\u0007\u0005\u0000"+
		"\u0000\u01baI\u0001\u0000\u0000\u0000\u01bb\u01bc\u00056\u0000\u0000\u01bc"+
		"K\u0001\u0000\u0000\u0000\u01bd\u01be\u00057\u0000\u0000\u01beM\u0001"+
		"\u0000\u0000\u0000\u01bf\u01c0\u0005:\u0000\u0000\u01c0O\u0001\u0000\u0000"+
		"\u0000\u01c1\u01c2\u00058\u0000\u0000\u01c2\u01c3\u0003(\u0014\u0000\u01c3"+
		"\u01c4\u00059\u0000\u0000\u01c4Q\u0001\u0000\u0000\u0000\u01c5\u01c6\u0007"+
		"\u0006\u0000\u0000\u01c6S\u0001\u0000\u0000\u0000\u01c7\u01cf\u0003R)"+
		"\u0000\u01c8\u01cf\u0005&\u0000\u0000\u01c9\u01cf\u0005\u001d\u0000\u0000"+
		"\u01ca\u01cf\u0005\u001e\u0000\u0000\u01cb\u01cf\u0005\u001f\u0000\u0000"+
		"\u01cc\u01cf\u0005\"\u0000\u0000\u01cd\u01cf\u0005#\u0000\u0000\u01ce"+
		"\u01c7\u0001\u0000\u0000\u0000\u01ce\u01c8\u0001\u0000\u0000\u0000\u01ce"+
		"\u01c9\u0001\u0000\u0000\u0000\u01ce\u01ca\u0001\u0000\u0000\u0000\u01ce"+
		"\u01cb\u0001\u0000\u0000\u0000\u01ce\u01cc\u0001\u0000\u0000\u0000\u01ce"+
		"\u01cd\u0001\u0000\u0000\u0000\u01cfU\u0001\u0000\u0000\u0000-Ychnqsx"+
		"\u0080\u008c\u0099\u009f\u00a7\u00aa\u00b5\u00c3\u00cb\u00d1\u00d9\u00f2"+
		"\u010b\u0113\u0121\u0123\u0131\u013f\u0141\u0148\u014d\u0154\u015c\u015f"+
		"\u0165\u0168\u016a\u016f\u0172\u0176\u0179\u0182\u0188\u019e\u01a4\u01b2"+
		"\u01b4\u01ce";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}