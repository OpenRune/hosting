// Generated from C:\Users\home\Desktop\Programming\Rsps\OpenRune\neptune\runescript-parser\src\main\antlr\RuneScriptParser.g4 by ANTLR 4.10.1
package me.filby.neptune.runescript.antlr;
import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link RuneScriptParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface RuneScriptParserVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link RuneScriptParser#scriptFile}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitScriptFile(RuneScriptParser.ScriptFileContext ctx);
	/**
	 * Visit a parse tree produced by {@link RuneScriptParser#script}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitScript(RuneScriptParser.ScriptContext ctx);
	/**
	 * Visit a parse tree produced by {@link RuneScriptParser#parameterList}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParameterList(RuneScriptParser.ParameterListContext ctx);
	/**
	 * Visit a parse tree produced by {@link RuneScriptParser#parameter}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParameter(RuneScriptParser.ParameterContext ctx);
	/**
	 * Visit a parse tree produced by {@link RuneScriptParser#typeList}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTypeList(RuneScriptParser.TypeListContext ctx);
	/**
	 * Visit a parse tree produced by {@link RuneScriptParser#statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStatement(RuneScriptParser.StatementContext ctx);
	/**
	 * Visit a parse tree produced by {@link RuneScriptParser#blockStatement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBlockStatement(RuneScriptParser.BlockStatementContext ctx);
	/**
	 * Visit a parse tree produced by {@link RuneScriptParser#returnStatement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitReturnStatement(RuneScriptParser.ReturnStatementContext ctx);
	/**
	 * Visit a parse tree produced by {@link RuneScriptParser#ifStatement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIfStatement(RuneScriptParser.IfStatementContext ctx);
	/**
	 * Visit a parse tree produced by {@link RuneScriptParser#whileStatement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWhileStatement(RuneScriptParser.WhileStatementContext ctx);
	/**
	 * Visit a parse tree produced by {@link RuneScriptParser#switchStatement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSwitchStatement(RuneScriptParser.SwitchStatementContext ctx);
	/**
	 * Visit a parse tree produced by {@link RuneScriptParser#switchCase}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSwitchCase(RuneScriptParser.SwitchCaseContext ctx);
	/**
	 * Visit a parse tree produced by {@link RuneScriptParser#declarationStatement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDeclarationStatement(RuneScriptParser.DeclarationStatementContext ctx);
	/**
	 * Visit a parse tree produced by {@link RuneScriptParser#arrayDeclarationStatement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitArrayDeclarationStatement(RuneScriptParser.ArrayDeclarationStatementContext ctx);
	/**
	 * Visit a parse tree produced by {@link RuneScriptParser#assignmentStatement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAssignmentStatement(RuneScriptParser.AssignmentStatementContext ctx);
	/**
	 * Visit a parse tree produced by {@link RuneScriptParser#expressionStatement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExpressionStatement(RuneScriptParser.ExpressionStatementContext ctx);
	/**
	 * Visit a parse tree produced by {@link RuneScriptParser#emptyStatement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEmptyStatement(RuneScriptParser.EmptyStatementContext ctx);
	/**
	 * Visit a parse tree produced by {@link RuneScriptParser#expressionList}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExpressionList(RuneScriptParser.ExpressionListContext ctx);
	/**
	 * Visit a parse tree produced by {@link RuneScriptParser#parenthesis}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParenthesis(RuneScriptParser.ParenthesisContext ctx);
	/**
	 * Visit a parse tree produced by {@link RuneScriptParser#singleExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSingleExpression(RuneScriptParser.SingleExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code ParenthesizedExpression}
	 * labeled alternative in {@link RuneScriptParser#expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParenthesizedExpression(RuneScriptParser.ParenthesizedExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code CalcExpression}
	 * labeled alternative in {@link RuneScriptParser#expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCalcExpression(RuneScriptParser.CalcExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code CallExpression}
	 * labeled alternative in {@link RuneScriptParser#expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCallExpression(RuneScriptParser.CallExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code LocalVariableExpression}
	 * labeled alternative in {@link RuneScriptParser#expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLocalVariableExpression(RuneScriptParser.LocalVariableExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code LocalArrayVariableExpression}
	 * labeled alternative in {@link RuneScriptParser#expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLocalArrayVariableExpression(RuneScriptParser.LocalArrayVariableExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code GameVariableExpression}
	 * labeled alternative in {@link RuneScriptParser#expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGameVariableExpression(RuneScriptParser.GameVariableExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code ConstantVariableExpression}
	 * labeled alternative in {@link RuneScriptParser#expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConstantVariableExpression(RuneScriptParser.ConstantVariableExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code LiteralExpression}
	 * labeled alternative in {@link RuneScriptParser#expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLiteralExpression(RuneScriptParser.LiteralExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code JoinedStringExpression}
	 * labeled alternative in {@link RuneScriptParser#expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitJoinedStringExpression(RuneScriptParser.JoinedStringExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code PrefixExpression}
	 * labeled alternative in {@link RuneScriptParser#expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPrefixExpression(RuneScriptParser.PrefixExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code PostfixExpression}
	 * labeled alternative in {@link RuneScriptParser#expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPostfixExpression(RuneScriptParser.PostfixExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code IdentifierExpression}
	 * labeled alternative in {@link RuneScriptParser#expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIdentifierExpression(RuneScriptParser.IdentifierExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code ConditionNormalExpression}
	 * labeled alternative in {@link RuneScriptParser#condition}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConditionNormalExpression(RuneScriptParser.ConditionNormalExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code ConditionBinaryExpression}
	 * labeled alternative in {@link RuneScriptParser#condition}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConditionBinaryExpression(RuneScriptParser.ConditionBinaryExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code ConditionParenthesizedExpression}
	 * labeled alternative in {@link RuneScriptParser#condition}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConditionParenthesizedExpression(RuneScriptParser.ConditionParenthesizedExpressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link RuneScriptParser#calc}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCalc(RuneScriptParser.CalcContext ctx);
	/**
	 * Visit a parse tree produced by the {@code ArithmeticBinaryExpression}
	 * labeled alternative in {@link RuneScriptParser#arithmetic}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitArithmeticBinaryExpression(RuneScriptParser.ArithmeticBinaryExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code ArithmeticParenthesizedExpression}
	 * labeled alternative in {@link RuneScriptParser#arithmetic}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitArithmeticParenthesizedExpression(RuneScriptParser.ArithmeticParenthesizedExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code ArithmeticNormalExpression}
	 * labeled alternative in {@link RuneScriptParser#arithmetic}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitArithmeticNormalExpression(RuneScriptParser.ArithmeticNormalExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code CommandCallExpression}
	 * labeled alternative in {@link RuneScriptParser#call}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCommandCallExpression(RuneScriptParser.CommandCallExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code ProcCallExpression}
	 * labeled alternative in {@link RuneScriptParser#call}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitProcCallExpression(RuneScriptParser.ProcCallExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code JumpCallExpression}
	 * labeled alternative in {@link RuneScriptParser#call}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitJumpCallExpression(RuneScriptParser.JumpCallExpressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link RuneScriptParser#clientScript}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitClientScript(RuneScriptParser.ClientScriptContext ctx);
	/**
	 * Visit a parse tree produced by {@link RuneScriptParser#assignableVariableList}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAssignableVariableList(RuneScriptParser.AssignableVariableListContext ctx);
	/**
	 * Visit a parse tree produced by {@link RuneScriptParser#assignableVariable}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAssignableVariable(RuneScriptParser.AssignableVariableContext ctx);
	/**
	 * Visit a parse tree produced by {@link RuneScriptParser#localVariable}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLocalVariable(RuneScriptParser.LocalVariableContext ctx);
	/**
	 * Visit a parse tree produced by {@link RuneScriptParser#localArrayVariable}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLocalArrayVariable(RuneScriptParser.LocalArrayVariableContext ctx);
	/**
	 * Visit a parse tree produced by {@link RuneScriptParser#gameVariable}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGameVariable(RuneScriptParser.GameVariableContext ctx);
	/**
	 * Visit a parse tree produced by {@link RuneScriptParser#constantVariable}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConstantVariable(RuneScriptParser.ConstantVariableContext ctx);
	/**
	 * Visit a parse tree produced by the {@code IntegerLiteral}
	 * labeled alternative in {@link RuneScriptParser#literal}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIntegerLiteral(RuneScriptParser.IntegerLiteralContext ctx);
	/**
	 * Visit a parse tree produced by the {@code HexLiteral}
	 * labeled alternative in {@link RuneScriptParser#literal}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitHexLiteral(RuneScriptParser.HexLiteralContext ctx);
	/**
	 * Visit a parse tree produced by the {@code CoordLiteral}
	 * labeled alternative in {@link RuneScriptParser#literal}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCoordLiteral(RuneScriptParser.CoordLiteralContext ctx);
	/**
	 * Visit a parse tree produced by the {@code BooleanLiteral}
	 * labeled alternative in {@link RuneScriptParser#literal}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBooleanLiteral(RuneScriptParser.BooleanLiteralContext ctx);
	/**
	 * Visit a parse tree produced by the {@code CharacterLiteral}
	 * labeled alternative in {@link RuneScriptParser#literal}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCharacterLiteral(RuneScriptParser.CharacterLiteralContext ctx);
	/**
	 * Visit a parse tree produced by the {@code NullLiteral}
	 * labeled alternative in {@link RuneScriptParser#literal}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNullLiteral(RuneScriptParser.NullLiteralContext ctx);
	/**
	 * Visit a parse tree produced by the {@code StringLiteralExpression}
	 * labeled alternative in {@link RuneScriptParser#literal}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStringLiteralExpression(RuneScriptParser.StringLiteralExpressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link RuneScriptParser#stringLiteral}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStringLiteral(RuneScriptParser.StringLiteralContext ctx);
	/**
	 * Visit a parse tree produced by {@link RuneScriptParser#stringLiteralContent}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStringLiteralContent(RuneScriptParser.StringLiteralContentContext ctx);
	/**
	 * Visit a parse tree produced by {@link RuneScriptParser#joinedString}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitJoinedString(RuneScriptParser.JoinedStringContext ctx);
	/**
	 * Visit a parse tree produced by {@link RuneScriptParser#stringTag}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStringTag(RuneScriptParser.StringTagContext ctx);
	/**
	 * Visit a parse tree produced by {@link RuneScriptParser#stringPTag}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStringPTag(RuneScriptParser.StringPTagContext ctx);
	/**
	 * Visit a parse tree produced by {@link RuneScriptParser#stringSwitchTag}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStringSwitchTag(RuneScriptParser.StringSwitchTagContext ctx);
	/**
	 * Visit a parse tree produced by {@link RuneScriptParser#stringTemplate}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStringTemplate(RuneScriptParser.StringTemplateContext ctx);
	/**
	 * Visit a parse tree produced by {@link RuneScriptParser#stringExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStringExpression(RuneScriptParser.StringExpressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link RuneScriptParser#identifier}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIdentifier(RuneScriptParser.IdentifierContext ctx);
	/**
	 * Visit a parse tree produced by {@link RuneScriptParser#advancedIdentifier}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAdvancedIdentifier(RuneScriptParser.AdvancedIdentifierContext ctx);
}