// Generated from D:\OpenRune\neptune\runescript-parser\src\main\antlr\RuneScriptParser.g4 by ANTLR 4.10.1
package me.filby.neptune.runescript.antlr;
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public class RuneScriptParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.10.1", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		LPAREN=1, RPAREN=2, COLON=3, SEMICOLON=4, COMMA=5, LBRACK=6, RBRACK=7, 
		LBRACE=8, RBRACE=9, PLUS=10, MINUS=11, MUL=12, DIV=13, MOD=14, AND=15, 
		OR=16, EQ=17, EXCL=18, DOLLAR=19, CARET=20, TILDE=21, AT=22, GT=23, GTE=24, 
		LT=25, LTE=26, INCREMENT=27, DECREMENT=28, IF=29, ELSE=30, WHILE=31, CASE=32, 
		DEFAULT=33, RETURN=34, CALC=35, DEF_TYPE=36, SWITCH_TYPE=37, INTEGER_LITERAL=38, 
		HEX_LITERAL=39, COORD_LITERAL=40, BOOLEAN_LITERAL=41, CHAR_LITERAL=42, 
		NULL_LITERAL=43, LINE_COMMENT=44, BLOCK_COMMENT=45, QUOTE_OPEN=46, IDENTIFIER=47, 
		WHITESPACE=48, QUOTE_CLOSE=49, STRING_TEXT=50, STRING_TAG=51, STRING_CLOSE_TAG=52, 
		STRING_PARTIAL_TAG=53, STRING_P_TAG=54, STRING_EXPR_START=55, STRING_EXPR_END=56, 
		STRING_TEMPLATE=57;
	public static final int
		RULE_scriptFile = 0, RULE_script = 1, RULE_parameterList = 2, RULE_parameter = 3, 
		RULE_typeList = 4, RULE_statement = 5, RULE_blockStatement = 6, RULE_returnStatement = 7, 
		RULE_ifStatement = 8, RULE_whileStatement = 9, RULE_switchStatement = 10, 
		RULE_switchCase = 11, RULE_declarationStatement = 12, RULE_arrayDeclarationStatement = 13, 
		RULE_assignmentStatement = 14, RULE_expressionStatement = 15, RULE_emptyStatement = 16, 
		RULE_expressionList = 17, RULE_parenthesis = 18, RULE_singleExpression = 19, 
		RULE_expression = 20, RULE_condition = 21, RULE_calc = 22, RULE_arithmetic = 23, 
		RULE_call = 24, RULE_clientScript = 25, RULE_assignableVariableList = 26, 
		RULE_assignableVariable = 27, RULE_localVariable = 28, RULE_localArrayVariable = 29, 
		RULE_gameVariable = 30, RULE_constantVariable = 31, RULE_literal = 32, 
		RULE_stringLiteral = 33, RULE_stringLiteralContent = 34, RULE_joinedString = 35, 
		RULE_stringTag = 36, RULE_stringPTag = 37, RULE_stringTemplate = 38, RULE_stringExpression = 39, 
		RULE_identifier = 40, RULE_advancedIdentifier = 41;
	private static String[] makeRuleNames() {
		return new String[] {
			"scriptFile", "script", "parameterList", "parameter", "typeList", "statement", 
			"blockStatement", "returnStatement", "ifStatement", "whileStatement", 
			"switchStatement", "switchCase", "declarationStatement", "arrayDeclarationStatement", 
			"assignmentStatement", "expressionStatement", "emptyStatement", "expressionList", 
			"parenthesis", "singleExpression", "expression", "condition", "calc", 
			"arithmetic", "call", "clientScript", "assignableVariableList", "assignableVariable", 
			"localVariable", "localArrayVariable", "gameVariable", "constantVariable", 
			"literal", "stringLiteral", "stringLiteralContent", "joinedString", "stringTag", 
			"stringPTag", "stringTemplate", "stringExpression", "identifier", "advancedIdentifier"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, "'('", "')'", "':'", "';'", "','", "'['", "']'", "'{'", "'}'", 
			"'+'", "'-'", "'*'", "'/'", "'%'", "'&'", "'|'", "'='", "'!'", "'$'", 
			"'^'", "'~'", "'@'", null, "'>='", null, "'<='", "'++'", "'--'", "'if'", 
			"'else'", "'while'", "'case'", "'default'", "'return'", "'calc'", null, 
			null, null, null, null, null, null, "'null'"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, "LPAREN", "RPAREN", "COLON", "SEMICOLON", "COMMA", "LBRACK", "RBRACK", 
			"LBRACE", "RBRACE", "PLUS", "MINUS", "MUL", "DIV", "MOD", "AND", "OR", 
			"EQ", "EXCL", "DOLLAR", "CARET", "TILDE", "AT", "GT", "GTE", "LT", "LTE", 
			"INCREMENT", "DECREMENT", "IF", "ELSE", "WHILE", "CASE", "DEFAULT", "RETURN", 
			"CALC", "DEF_TYPE", "SWITCH_TYPE", "INTEGER_LITERAL", "HEX_LITERAL", 
			"COORD_LITERAL", "BOOLEAN_LITERAL", "CHAR_LITERAL", "NULL_LITERAL", "LINE_COMMENT", 
			"BLOCK_COMMENT", "QUOTE_OPEN", "IDENTIFIER", "WHITESPACE", "QUOTE_CLOSE", 
			"STRING_TEXT", "STRING_TAG", "STRING_CLOSE_TAG", "STRING_PARTIAL_TAG", 
			"STRING_P_TAG", "STRING_EXPR_START", "STRING_EXPR_END", "STRING_TEMPLATE"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "RuneScriptParser.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public RuneScriptParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	public static class ScriptFileContext extends ParserRuleContext {
		public TerminalNode EOF() { return getToken(RuneScriptParser.EOF, 0); }
		public List<ScriptContext> script() {
			return getRuleContexts(ScriptContext.class);
		}
		public ScriptContext script(int i) {
			return getRuleContext(ScriptContext.class,i);
		}
		public ScriptFileContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_scriptFile; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitScriptFile(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ScriptFileContext scriptFile() throws RecognitionException {
		ScriptFileContext _localctx = new ScriptFileContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_scriptFile);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(87);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==LBRACK) {
				{
				{
				setState(84);
				script();
				}
				}
				setState(89);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(90);
			match(EOF);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ScriptContext extends ParserRuleContext {
		public IdentifierContext trigger;
		public IdentifierContext name;
		public TerminalNode LBRACK() { return getToken(RuneScriptParser.LBRACK, 0); }
		public TerminalNode COMMA() { return getToken(RuneScriptParser.COMMA, 0); }
		public TerminalNode RBRACK() { return getToken(RuneScriptParser.RBRACK, 0); }
		public List<IdentifierContext> identifier() {
			return getRuleContexts(IdentifierContext.class);
		}
		public IdentifierContext identifier(int i) {
			return getRuleContext(IdentifierContext.class,i);
		}
		public TerminalNode MUL() { return getToken(RuneScriptParser.MUL, 0); }
		public List<StatementContext> statement() {
			return getRuleContexts(StatementContext.class);
		}
		public StatementContext statement(int i) {
			return getRuleContext(StatementContext.class,i);
		}
		public List<TerminalNode> LPAREN() { return getTokens(RuneScriptParser.LPAREN); }
		public TerminalNode LPAREN(int i) {
			return getToken(RuneScriptParser.LPAREN, i);
		}
		public List<TerminalNode> RPAREN() { return getTokens(RuneScriptParser.RPAREN); }
		public TerminalNode RPAREN(int i) {
			return getToken(RuneScriptParser.RPAREN, i);
		}
		public ParameterListContext parameterList() {
			return getRuleContext(ParameterListContext.class,0);
		}
		public TypeListContext typeList() {
			return getRuleContext(TypeListContext.class,0);
		}
		public ScriptContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_script; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitScript(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ScriptContext script() throws RecognitionException {
		ScriptContext _localctx = new ScriptContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_script);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(92);
			match(LBRACK);
			setState(93);
			((ScriptContext)_localctx).trigger = identifier();
			setState(94);
			match(COMMA);
			setState(95);
			((ScriptContext)_localctx).name = identifier();
			setState(97);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==MUL) {
				{
				setState(96);
				match(MUL);
				}
			}

			setState(99);
			match(RBRACK);
			setState(113);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,5,_ctx) ) {
			case 1:
				{
				{
				setState(100);
				match(LPAREN);
				setState(102);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==IDENTIFIER) {
					{
					setState(101);
					parameterList();
					}
				}

				setState(104);
				match(RPAREN);
				}
				setState(111);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,4,_ctx) ) {
				case 1:
					{
					setState(106);
					match(LPAREN);
					setState(108);
					_errHandler.sync(this);
					_la = _input.LA(1);
					if (_la==IDENTIFIER) {
						{
						setState(107);
						typeList();
						}
					}

					setState(110);
					match(RPAREN);
					}
					break;
				}
				}
				break;
			}
			setState(118);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << LPAREN) | (1L << SEMICOLON) | (1L << LBRACE) | (1L << MOD) | (1L << DOLLAR) | (1L << CARET) | (1L << TILDE) | (1L << AT) | (1L << INCREMENT) | (1L << DECREMENT) | (1L << IF) | (1L << WHILE) | (1L << DEFAULT) | (1L << RETURN) | (1L << CALC) | (1L << DEF_TYPE) | (1L << SWITCH_TYPE) | (1L << INTEGER_LITERAL) | (1L << HEX_LITERAL) | (1L << COORD_LITERAL) | (1L << BOOLEAN_LITERAL) | (1L << CHAR_LITERAL) | (1L << NULL_LITERAL) | (1L << QUOTE_OPEN) | (1L << IDENTIFIER))) != 0)) {
				{
				{
				setState(115);
				statement();
				}
				}
				setState(120);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ParameterListContext extends ParserRuleContext {
		public List<ParameterContext> parameter() {
			return getRuleContexts(ParameterContext.class);
		}
		public ParameterContext parameter(int i) {
			return getRuleContext(ParameterContext.class,i);
		}
		public List<TerminalNode> COMMA() { return getTokens(RuneScriptParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(RuneScriptParser.COMMA, i);
		}
		public ParameterListContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_parameterList; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitParameterList(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ParameterListContext parameterList() throws RecognitionException {
		ParameterListContext _localctx = new ParameterListContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_parameterList);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(121);
			parameter();
			setState(126);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==COMMA) {
				{
				{
				setState(122);
				match(COMMA);
				setState(123);
				parameter();
				}
				}
				setState(128);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ParameterContext extends ParserRuleContext {
		public Token type;
		public TerminalNode DOLLAR() { return getToken(RuneScriptParser.DOLLAR, 0); }
		public AdvancedIdentifierContext advancedIdentifier() {
			return getRuleContext(AdvancedIdentifierContext.class,0);
		}
		public TerminalNode IDENTIFIER() { return getToken(RuneScriptParser.IDENTIFIER, 0); }
		public ParameterContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_parameter; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitParameter(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ParameterContext parameter() throws RecognitionException {
		ParameterContext _localctx = new ParameterContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_parameter);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(129);
			((ParameterContext)_localctx).type = match(IDENTIFIER);
			setState(130);
			match(DOLLAR);
			setState(131);
			advancedIdentifier();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class TypeListContext extends ParserRuleContext {
		public List<TerminalNode> IDENTIFIER() { return getTokens(RuneScriptParser.IDENTIFIER); }
		public TerminalNode IDENTIFIER(int i) {
			return getToken(RuneScriptParser.IDENTIFIER, i);
		}
		public List<TerminalNode> COMMA() { return getTokens(RuneScriptParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(RuneScriptParser.COMMA, i);
		}
		public TypeListContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_typeList; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitTypeList(this);
			else return visitor.visitChildren(this);
		}
	}

	public final TypeListContext typeList() throws RecognitionException {
		TypeListContext _localctx = new TypeListContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_typeList);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(133);
			match(IDENTIFIER);
			setState(138);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==COMMA) {
				{
				{
				setState(134);
				match(COMMA);
				setState(135);
				match(IDENTIFIER);
				}
				}
				setState(140);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class StatementContext extends ParserRuleContext {
		public BlockStatementContext blockStatement() {
			return getRuleContext(BlockStatementContext.class,0);
		}
		public ReturnStatementContext returnStatement() {
			return getRuleContext(ReturnStatementContext.class,0);
		}
		public IfStatementContext ifStatement() {
			return getRuleContext(IfStatementContext.class,0);
		}
		public WhileStatementContext whileStatement() {
			return getRuleContext(WhileStatementContext.class,0);
		}
		public SwitchStatementContext switchStatement() {
			return getRuleContext(SwitchStatementContext.class,0);
		}
		public DeclarationStatementContext declarationStatement() {
			return getRuleContext(DeclarationStatementContext.class,0);
		}
		public ArrayDeclarationStatementContext arrayDeclarationStatement() {
			return getRuleContext(ArrayDeclarationStatementContext.class,0);
		}
		public AssignmentStatementContext assignmentStatement() {
			return getRuleContext(AssignmentStatementContext.class,0);
		}
		public ExpressionStatementContext expressionStatement() {
			return getRuleContext(ExpressionStatementContext.class,0);
		}
		public EmptyStatementContext emptyStatement() {
			return getRuleContext(EmptyStatementContext.class,0);
		}
		public StatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_statement; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitStatement(this);
			else return visitor.visitChildren(this);
		}
	}

	public final StatementContext statement() throws RecognitionException {
		StatementContext _localctx = new StatementContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_statement);
		try {
			setState(151);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,9,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(141);
				blockStatement();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(142);
				returnStatement();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(143);
				ifStatement();
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(144);
				whileStatement();
				}
				break;
			case 5:
				enterOuterAlt(_localctx, 5);
				{
				setState(145);
				switchStatement();
				}
				break;
			case 6:
				enterOuterAlt(_localctx, 6);
				{
				setState(146);
				declarationStatement();
				}
				break;
			case 7:
				enterOuterAlt(_localctx, 7);
				{
				setState(147);
				arrayDeclarationStatement();
				}
				break;
			case 8:
				enterOuterAlt(_localctx, 8);
				{
				setState(148);
				assignmentStatement();
				}
				break;
			case 9:
				enterOuterAlt(_localctx, 9);
				{
				setState(149);
				expressionStatement();
				}
				break;
			case 10:
				enterOuterAlt(_localctx, 10);
				{
				setState(150);
				emptyStatement();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class BlockStatementContext extends ParserRuleContext {
		public TerminalNode LBRACE() { return getToken(RuneScriptParser.LBRACE, 0); }
		public TerminalNode RBRACE() { return getToken(RuneScriptParser.RBRACE, 0); }
		public List<StatementContext> statement() {
			return getRuleContexts(StatementContext.class);
		}
		public StatementContext statement(int i) {
			return getRuleContext(StatementContext.class,i);
		}
		public BlockStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_blockStatement; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitBlockStatement(this);
			else return visitor.visitChildren(this);
		}
	}

	public final BlockStatementContext blockStatement() throws RecognitionException {
		BlockStatementContext _localctx = new BlockStatementContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_blockStatement);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(153);
			match(LBRACE);
			setState(157);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << LPAREN) | (1L << SEMICOLON) | (1L << LBRACE) | (1L << MOD) | (1L << DOLLAR) | (1L << CARET) | (1L << TILDE) | (1L << AT) | (1L << INCREMENT) | (1L << DECREMENT) | (1L << IF) | (1L << WHILE) | (1L << DEFAULT) | (1L << RETURN) | (1L << CALC) | (1L << DEF_TYPE) | (1L << SWITCH_TYPE) | (1L << INTEGER_LITERAL) | (1L << HEX_LITERAL) | (1L << COORD_LITERAL) | (1L << BOOLEAN_LITERAL) | (1L << CHAR_LITERAL) | (1L << NULL_LITERAL) | (1L << QUOTE_OPEN) | (1L << IDENTIFIER))) != 0)) {
				{
				{
				setState(154);
				statement();
				}
				}
				setState(159);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(160);
			match(RBRACE);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ReturnStatementContext extends ParserRuleContext {
		public TerminalNode RETURN() { return getToken(RuneScriptParser.RETURN, 0); }
		public TerminalNode SEMICOLON() { return getToken(RuneScriptParser.SEMICOLON, 0); }
		public TerminalNode LPAREN() { return getToken(RuneScriptParser.LPAREN, 0); }
		public TerminalNode RPAREN() { return getToken(RuneScriptParser.RPAREN, 0); }
		public ExpressionListContext expressionList() {
			return getRuleContext(ExpressionListContext.class,0);
		}
		public ReturnStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_returnStatement; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitReturnStatement(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ReturnStatementContext returnStatement() throws RecognitionException {
		ReturnStatementContext _localctx = new ReturnStatementContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_returnStatement);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(162);
			match(RETURN);
			setState(168);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==LPAREN) {
				{
				setState(163);
				match(LPAREN);
				setState(165);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << LPAREN) | (1L << MOD) | (1L << DOLLAR) | (1L << CARET) | (1L << TILDE) | (1L << AT) | (1L << INCREMENT) | (1L << DECREMENT) | (1L << DEFAULT) | (1L << CALC) | (1L << DEF_TYPE) | (1L << SWITCH_TYPE) | (1L << INTEGER_LITERAL) | (1L << HEX_LITERAL) | (1L << COORD_LITERAL) | (1L << BOOLEAN_LITERAL) | (1L << CHAR_LITERAL) | (1L << NULL_LITERAL) | (1L << QUOTE_OPEN) | (1L << IDENTIFIER))) != 0)) {
					{
					setState(164);
					expressionList();
					}
				}

				setState(167);
				match(RPAREN);
				}
			}

			setState(170);
			match(SEMICOLON);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class IfStatementContext extends ParserRuleContext {
		public TerminalNode IF() { return getToken(RuneScriptParser.IF, 0); }
		public TerminalNode LPAREN() { return getToken(RuneScriptParser.LPAREN, 0); }
		public ConditionContext condition() {
			return getRuleContext(ConditionContext.class,0);
		}
		public TerminalNode RPAREN() { return getToken(RuneScriptParser.RPAREN, 0); }
		public List<StatementContext> statement() {
			return getRuleContexts(StatementContext.class);
		}
		public StatementContext statement(int i) {
			return getRuleContext(StatementContext.class,i);
		}
		public TerminalNode ELSE() { return getToken(RuneScriptParser.ELSE, 0); }
		public IfStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_ifStatement; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitIfStatement(this);
			else return visitor.visitChildren(this);
		}
	}

	public final IfStatementContext ifStatement() throws RecognitionException {
		IfStatementContext _localctx = new IfStatementContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_ifStatement);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(172);
			match(IF);
			setState(173);
			match(LPAREN);
			setState(174);
			condition(0);
			setState(175);
			match(RPAREN);
			setState(176);
			statement();
			setState(179);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,13,_ctx) ) {
			case 1:
				{
				setState(177);
				match(ELSE);
				setState(178);
				statement();
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class WhileStatementContext extends ParserRuleContext {
		public TerminalNode WHILE() { return getToken(RuneScriptParser.WHILE, 0); }
		public TerminalNode LPAREN() { return getToken(RuneScriptParser.LPAREN, 0); }
		public ConditionContext condition() {
			return getRuleContext(ConditionContext.class,0);
		}
		public TerminalNode RPAREN() { return getToken(RuneScriptParser.RPAREN, 0); }
		public StatementContext statement() {
			return getRuleContext(StatementContext.class,0);
		}
		public WhileStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_whileStatement; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitWhileStatement(this);
			else return visitor.visitChildren(this);
		}
	}

	public final WhileStatementContext whileStatement() throws RecognitionException {
		WhileStatementContext _localctx = new WhileStatementContext(_ctx, getState());
		enterRule(_localctx, 18, RULE_whileStatement);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(181);
			match(WHILE);
			setState(182);
			match(LPAREN);
			setState(183);
			condition(0);
			setState(184);
			match(RPAREN);
			setState(185);
			statement();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class SwitchStatementContext extends ParserRuleContext {
		public TerminalNode SWITCH_TYPE() { return getToken(RuneScriptParser.SWITCH_TYPE, 0); }
		public ParenthesisContext parenthesis() {
			return getRuleContext(ParenthesisContext.class,0);
		}
		public TerminalNode LBRACE() { return getToken(RuneScriptParser.LBRACE, 0); }
		public TerminalNode RBRACE() { return getToken(RuneScriptParser.RBRACE, 0); }
		public List<SwitchCaseContext> switchCase() {
			return getRuleContexts(SwitchCaseContext.class);
		}
		public SwitchCaseContext switchCase(int i) {
			return getRuleContext(SwitchCaseContext.class,i);
		}
		public SwitchStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_switchStatement; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitSwitchStatement(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SwitchStatementContext switchStatement() throws RecognitionException {
		SwitchStatementContext _localctx = new SwitchStatementContext(_ctx, getState());
		enterRule(_localctx, 20, RULE_switchStatement);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(187);
			match(SWITCH_TYPE);
			setState(188);
			parenthesis();
			setState(189);
			match(LBRACE);
			setState(193);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==CASE) {
				{
				{
				setState(190);
				switchCase();
				}
				}
				setState(195);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(196);
			match(RBRACE);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class SwitchCaseContext extends ParserRuleContext {
		public TerminalNode CASE() { return getToken(RuneScriptParser.CASE, 0); }
		public TerminalNode COLON() { return getToken(RuneScriptParser.COLON, 0); }
		public TerminalNode DEFAULT() { return getToken(RuneScriptParser.DEFAULT, 0); }
		public ExpressionListContext expressionList() {
			return getRuleContext(ExpressionListContext.class,0);
		}
		public List<StatementContext> statement() {
			return getRuleContexts(StatementContext.class);
		}
		public StatementContext statement(int i) {
			return getRuleContext(StatementContext.class,i);
		}
		public SwitchCaseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_switchCase; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitSwitchCase(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SwitchCaseContext switchCase() throws RecognitionException {
		SwitchCaseContext _localctx = new SwitchCaseContext(_ctx, getState());
		enterRule(_localctx, 22, RULE_switchCase);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(198);
			match(CASE);
			setState(201);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,15,_ctx) ) {
			case 1:
				{
				setState(199);
				match(DEFAULT);
				}
				break;
			case 2:
				{
				setState(200);
				expressionList();
				}
				break;
			}
			setState(203);
			match(COLON);
			setState(207);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << LPAREN) | (1L << SEMICOLON) | (1L << LBRACE) | (1L << MOD) | (1L << DOLLAR) | (1L << CARET) | (1L << TILDE) | (1L << AT) | (1L << INCREMENT) | (1L << DECREMENT) | (1L << IF) | (1L << WHILE) | (1L << DEFAULT) | (1L << RETURN) | (1L << CALC) | (1L << DEF_TYPE) | (1L << SWITCH_TYPE) | (1L << INTEGER_LITERAL) | (1L << HEX_LITERAL) | (1L << COORD_LITERAL) | (1L << BOOLEAN_LITERAL) | (1L << CHAR_LITERAL) | (1L << NULL_LITERAL) | (1L << QUOTE_OPEN) | (1L << IDENTIFIER))) != 0)) {
				{
				{
				setState(204);
				statement();
				}
				}
				setState(209);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class DeclarationStatementContext extends ParserRuleContext {
		public TerminalNode DEF_TYPE() { return getToken(RuneScriptParser.DEF_TYPE, 0); }
		public TerminalNode DOLLAR() { return getToken(RuneScriptParser.DOLLAR, 0); }
		public AdvancedIdentifierContext advancedIdentifier() {
			return getRuleContext(AdvancedIdentifierContext.class,0);
		}
		public TerminalNode SEMICOLON() { return getToken(RuneScriptParser.SEMICOLON, 0); }
		public TerminalNode EQ() { return getToken(RuneScriptParser.EQ, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public DeclarationStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_declarationStatement; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitDeclarationStatement(this);
			else return visitor.visitChildren(this);
		}
	}

	public final DeclarationStatementContext declarationStatement() throws RecognitionException {
		DeclarationStatementContext _localctx = new DeclarationStatementContext(_ctx, getState());
		enterRule(_localctx, 24, RULE_declarationStatement);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(210);
			match(DEF_TYPE);
			setState(211);
			match(DOLLAR);
			setState(212);
			advancedIdentifier();
			setState(215);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==EQ) {
				{
				setState(213);
				match(EQ);
				setState(214);
				expression();
				}
			}

			setState(217);
			match(SEMICOLON);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ArrayDeclarationStatementContext extends ParserRuleContext {
		public TerminalNode DEF_TYPE() { return getToken(RuneScriptParser.DEF_TYPE, 0); }
		public TerminalNode DOLLAR() { return getToken(RuneScriptParser.DOLLAR, 0); }
		public AdvancedIdentifierContext advancedIdentifier() {
			return getRuleContext(AdvancedIdentifierContext.class,0);
		}
		public ParenthesisContext parenthesis() {
			return getRuleContext(ParenthesisContext.class,0);
		}
		public TerminalNode SEMICOLON() { return getToken(RuneScriptParser.SEMICOLON, 0); }
		public ArrayDeclarationStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_arrayDeclarationStatement; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitArrayDeclarationStatement(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ArrayDeclarationStatementContext arrayDeclarationStatement() throws RecognitionException {
		ArrayDeclarationStatementContext _localctx = new ArrayDeclarationStatementContext(_ctx, getState());
		enterRule(_localctx, 26, RULE_arrayDeclarationStatement);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(219);
			match(DEF_TYPE);
			setState(220);
			match(DOLLAR);
			setState(221);
			advancedIdentifier();
			setState(222);
			parenthesis();
			setState(223);
			match(SEMICOLON);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AssignmentStatementContext extends ParserRuleContext {
		public AssignableVariableListContext assignableVariableList() {
			return getRuleContext(AssignableVariableListContext.class,0);
		}
		public TerminalNode EQ() { return getToken(RuneScriptParser.EQ, 0); }
		public ExpressionListContext expressionList() {
			return getRuleContext(ExpressionListContext.class,0);
		}
		public TerminalNode SEMICOLON() { return getToken(RuneScriptParser.SEMICOLON, 0); }
		public AssignmentStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_assignmentStatement; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitAssignmentStatement(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AssignmentStatementContext assignmentStatement() throws RecognitionException {
		AssignmentStatementContext _localctx = new AssignmentStatementContext(_ctx, getState());
		enterRule(_localctx, 28, RULE_assignmentStatement);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(225);
			assignableVariableList();
			setState(226);
			match(EQ);
			setState(227);
			expressionList();
			setState(228);
			match(SEMICOLON);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ExpressionStatementContext extends ParserRuleContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public TerminalNode SEMICOLON() { return getToken(RuneScriptParser.SEMICOLON, 0); }
		public ExpressionStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_expressionStatement; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitExpressionStatement(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ExpressionStatementContext expressionStatement() throws RecognitionException {
		ExpressionStatementContext _localctx = new ExpressionStatementContext(_ctx, getState());
		enterRule(_localctx, 30, RULE_expressionStatement);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(230);
			expression();
			setState(231);
			match(SEMICOLON);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class EmptyStatementContext extends ParserRuleContext {
		public TerminalNode SEMICOLON() { return getToken(RuneScriptParser.SEMICOLON, 0); }
		public EmptyStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_emptyStatement; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitEmptyStatement(this);
			else return visitor.visitChildren(this);
		}
	}

	public final EmptyStatementContext emptyStatement() throws RecognitionException {
		EmptyStatementContext _localctx = new EmptyStatementContext(_ctx, getState());
		enterRule(_localctx, 32, RULE_emptyStatement);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(233);
			match(SEMICOLON);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ExpressionListContext extends ParserRuleContext {
		public List<ExpressionContext> expression() {
			return getRuleContexts(ExpressionContext.class);
		}
		public ExpressionContext expression(int i) {
			return getRuleContext(ExpressionContext.class,i);
		}
		public List<TerminalNode> COMMA() { return getTokens(RuneScriptParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(RuneScriptParser.COMMA, i);
		}
		public ExpressionListContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_expressionList; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitExpressionList(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ExpressionListContext expressionList() throws RecognitionException {
		ExpressionListContext _localctx = new ExpressionListContext(_ctx, getState());
		enterRule(_localctx, 34, RULE_expressionList);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(235);
			expression();
			setState(240);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==COMMA) {
				{
				{
				setState(236);
				match(COMMA);
				setState(237);
				expression();
				}
				}
				setState(242);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ParenthesisContext extends ParserRuleContext {
		public TerminalNode LPAREN() { return getToken(RuneScriptParser.LPAREN, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public TerminalNode RPAREN() { return getToken(RuneScriptParser.RPAREN, 0); }
		public ParenthesisContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_parenthesis; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitParenthesis(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ParenthesisContext parenthesis() throws RecognitionException {
		ParenthesisContext _localctx = new ParenthesisContext(_ctx, getState());
		enterRule(_localctx, 36, RULE_parenthesis);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(243);
			match(LPAREN);
			setState(244);
			expression();
			setState(245);
			match(RPAREN);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class SingleExpressionContext extends ParserRuleContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public TerminalNode EOF() { return getToken(RuneScriptParser.EOF, 0); }
		public SingleExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_singleExpression; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitSingleExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SingleExpressionContext singleExpression() throws RecognitionException {
		SingleExpressionContext _localctx = new SingleExpressionContext(_ctx, getState());
		enterRule(_localctx, 38, RULE_singleExpression);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(247);
			expression();
			setState(248);
			match(EOF);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ExpressionContext extends ParserRuleContext {
		public ExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_expression; }
	 
		public ExpressionContext() { }
		public void copyFrom(ExpressionContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class ParenthesizedExpressionContext extends ExpressionContext {
		public ParenthesisContext parenthesis() {
			return getRuleContext(ParenthesisContext.class,0);
		}
		public ParenthesizedExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitParenthesizedExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class LocalVariableExpressionContext extends ExpressionContext {
		public LocalVariableContext localVariable() {
			return getRuleContext(LocalVariableContext.class,0);
		}
		public LocalVariableExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitLocalVariableExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class ConstantVariableExpressionContext extends ExpressionContext {
		public ConstantVariableContext constantVariable() {
			return getRuleContext(ConstantVariableContext.class,0);
		}
		public ConstantVariableExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitConstantVariableExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class LiteralExpressionContext extends ExpressionContext {
		public LiteralContext literal() {
			return getRuleContext(LiteralContext.class,0);
		}
		public LiteralExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitLiteralExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class PrefixExpressionContext extends ExpressionContext {
		public Token op;
		public AssignableVariableContext expr;
		public AssignableVariableContext assignableVariable() {
			return getRuleContext(AssignableVariableContext.class,0);
		}
		public TerminalNode INCREMENT() { return getToken(RuneScriptParser.INCREMENT, 0); }
		public TerminalNode DECREMENT() { return getToken(RuneScriptParser.DECREMENT, 0); }
		public PrefixExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitPrefixExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class PostfixExpressionContext extends ExpressionContext {
		public AssignableVariableContext expr;
		public Token op;
		public AssignableVariableContext assignableVariable() {
			return getRuleContext(AssignableVariableContext.class,0);
		}
		public TerminalNode INCREMENT() { return getToken(RuneScriptParser.INCREMENT, 0); }
		public TerminalNode DECREMENT() { return getToken(RuneScriptParser.DECREMENT, 0); }
		public PostfixExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitPostfixExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class JoinedStringExpressionContext extends ExpressionContext {
		public JoinedStringContext joinedString() {
			return getRuleContext(JoinedStringContext.class,0);
		}
		public JoinedStringExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitJoinedStringExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class CalcExpressionContext extends ExpressionContext {
		public CalcContext calc() {
			return getRuleContext(CalcContext.class,0);
		}
		public CalcExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitCalcExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class GameVariableExpressionContext extends ExpressionContext {
		public GameVariableContext gameVariable() {
			return getRuleContext(GameVariableContext.class,0);
		}
		public GameVariableExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitGameVariableExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class CallExpressionContext extends ExpressionContext {
		public CallContext call() {
			return getRuleContext(CallContext.class,0);
		}
		public CallExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitCallExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class LocalArrayVariableExpressionContext extends ExpressionContext {
		public LocalArrayVariableContext localArrayVariable() {
			return getRuleContext(LocalArrayVariableContext.class,0);
		}
		public LocalArrayVariableExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitLocalArrayVariableExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class IdentifierExpressionContext extends ExpressionContext {
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public IdentifierExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitIdentifierExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ExpressionContext expression() throws RecognitionException {
		ExpressionContext _localctx = new ExpressionContext(_ctx, getState());
		enterRule(_localctx, 40, RULE_expression);
		int _la;
		try {
			setState(265);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,19,_ctx) ) {
			case 1:
				_localctx = new ParenthesizedExpressionContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(250);
				parenthesis();
				}
				break;
			case 2:
				_localctx = new CalcExpressionContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(251);
				calc();
				}
				break;
			case 3:
				_localctx = new CallExpressionContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(252);
				call();
				}
				break;
			case 4:
				_localctx = new LocalVariableExpressionContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(253);
				localVariable();
				}
				break;
			case 5:
				_localctx = new LocalArrayVariableExpressionContext(_localctx);
				enterOuterAlt(_localctx, 5);
				{
				setState(254);
				localArrayVariable();
				}
				break;
			case 6:
				_localctx = new GameVariableExpressionContext(_localctx);
				enterOuterAlt(_localctx, 6);
				{
				setState(255);
				gameVariable();
				}
				break;
			case 7:
				_localctx = new ConstantVariableExpressionContext(_localctx);
				enterOuterAlt(_localctx, 7);
				{
				setState(256);
				constantVariable();
				}
				break;
			case 8:
				_localctx = new LiteralExpressionContext(_localctx);
				enterOuterAlt(_localctx, 8);
				{
				setState(257);
				literal();
				}
				break;
			case 9:
				_localctx = new JoinedStringExpressionContext(_localctx);
				enterOuterAlt(_localctx, 9);
				{
				setState(258);
				joinedString();
				}
				break;
			case 10:
				_localctx = new PrefixExpressionContext(_localctx);
				enterOuterAlt(_localctx, 10);
				{
				setState(259);
				((PrefixExpressionContext)_localctx).op = _input.LT(1);
				_la = _input.LA(1);
				if ( !(_la==INCREMENT || _la==DECREMENT) ) {
					((PrefixExpressionContext)_localctx).op = (Token)_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(260);
				((PrefixExpressionContext)_localctx).expr = assignableVariable();
				}
				break;
			case 11:
				_localctx = new PostfixExpressionContext(_localctx);
				enterOuterAlt(_localctx, 11);
				{
				setState(261);
				((PostfixExpressionContext)_localctx).expr = assignableVariable();
				setState(262);
				((PostfixExpressionContext)_localctx).op = _input.LT(1);
				_la = _input.LA(1);
				if ( !(_la==INCREMENT || _la==DECREMENT) ) {
					((PostfixExpressionContext)_localctx).op = (Token)_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
				break;
			case 12:
				_localctx = new IdentifierExpressionContext(_localctx);
				enterOuterAlt(_localctx, 12);
				{
				setState(264);
				identifier();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ConditionContext extends ParserRuleContext {
		public ConditionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_condition; }
	 
		public ConditionContext() { }
		public void copyFrom(ConditionContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class ConditionNormalExpressionContext extends ConditionContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public ConditionNormalExpressionContext(ConditionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitConditionNormalExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class ConditionBinaryExpressionContext extends ConditionContext {
		public Token op;
		public List<ConditionContext> condition() {
			return getRuleContexts(ConditionContext.class);
		}
		public ConditionContext condition(int i) {
			return getRuleContext(ConditionContext.class,i);
		}
		public TerminalNode LT() { return getToken(RuneScriptParser.LT, 0); }
		public TerminalNode GT() { return getToken(RuneScriptParser.GT, 0); }
		public TerminalNode LTE() { return getToken(RuneScriptParser.LTE, 0); }
		public TerminalNode GTE() { return getToken(RuneScriptParser.GTE, 0); }
		public TerminalNode EQ() { return getToken(RuneScriptParser.EQ, 0); }
		public TerminalNode EXCL() { return getToken(RuneScriptParser.EXCL, 0); }
		public TerminalNode AND() { return getToken(RuneScriptParser.AND, 0); }
		public TerminalNode OR() { return getToken(RuneScriptParser.OR, 0); }
		public ConditionBinaryExpressionContext(ConditionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitConditionBinaryExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class ConditionParenthesizedExpressionContext extends ConditionContext {
		public TerminalNode LPAREN() { return getToken(RuneScriptParser.LPAREN, 0); }
		public ConditionContext condition() {
			return getRuleContext(ConditionContext.class,0);
		}
		public TerminalNode RPAREN() { return getToken(RuneScriptParser.RPAREN, 0); }
		public ConditionParenthesizedExpressionContext(ConditionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitConditionParenthesizedExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ConditionContext condition() throws RecognitionException {
		return condition(0);
	}

	private ConditionContext condition(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		ConditionContext _localctx = new ConditionContext(_ctx, _parentState);
		ConditionContext _prevctx = _localctx;
		int _startState = 42;
		enterRecursionRule(_localctx, 42, RULE_condition, _p);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(273);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,20,_ctx) ) {
			case 1:
				{
				_localctx = new ConditionParenthesizedExpressionContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;

				setState(268);
				match(LPAREN);
				setState(269);
				condition(0);
				setState(270);
				match(RPAREN);
				}
				break;
			case 2:
				{
				_localctx = new ConditionNormalExpressionContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(272);
				expression();
				}
				break;
			}
			_ctx.stop = _input.LT(-1);
			setState(289);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,22,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					setState(287);
					_errHandler.sync(this);
					switch ( getInterpreter().adaptivePredict(_input,21,_ctx) ) {
					case 1:
						{
						_localctx = new ConditionBinaryExpressionContext(new ConditionContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_condition);
						setState(275);
						if (!(precpred(_ctx, 5))) throw new FailedPredicateException(this, "precpred(_ctx, 5)");
						setState(276);
						((ConditionBinaryExpressionContext)_localctx).op = _input.LT(1);
						_la = _input.LA(1);
						if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << GT) | (1L << GTE) | (1L << LT) | (1L << LTE))) != 0)) ) {
							((ConditionBinaryExpressionContext)_localctx).op = (Token)_errHandler.recoverInline(this);
						}
						else {
							if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
							_errHandler.reportMatch(this);
							consume();
						}
						setState(277);
						condition(6);
						}
						break;
					case 2:
						{
						_localctx = new ConditionBinaryExpressionContext(new ConditionContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_condition);
						setState(278);
						if (!(precpred(_ctx, 4))) throw new FailedPredicateException(this, "precpred(_ctx, 4)");
						setState(279);
						((ConditionBinaryExpressionContext)_localctx).op = _input.LT(1);
						_la = _input.LA(1);
						if ( !(_la==EQ || _la==EXCL) ) {
							((ConditionBinaryExpressionContext)_localctx).op = (Token)_errHandler.recoverInline(this);
						}
						else {
							if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
							_errHandler.reportMatch(this);
							consume();
						}
						setState(280);
						condition(5);
						}
						break;
					case 3:
						{
						_localctx = new ConditionBinaryExpressionContext(new ConditionContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_condition);
						setState(281);
						if (!(precpred(_ctx, 3))) throw new FailedPredicateException(this, "precpred(_ctx, 3)");
						setState(282);
						((ConditionBinaryExpressionContext)_localctx).op = match(AND);
						setState(283);
						condition(4);
						}
						break;
					case 4:
						{
						_localctx = new ConditionBinaryExpressionContext(new ConditionContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_condition);
						setState(284);
						if (!(precpred(_ctx, 2))) throw new FailedPredicateException(this, "precpred(_ctx, 2)");
						setState(285);
						((ConditionBinaryExpressionContext)_localctx).op = match(OR);
						setState(286);
						condition(3);
						}
						break;
					}
					} 
				}
				setState(291);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,22,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	public static class CalcContext extends ParserRuleContext {
		public TerminalNode CALC() { return getToken(RuneScriptParser.CALC, 0); }
		public TerminalNode LPAREN() { return getToken(RuneScriptParser.LPAREN, 0); }
		public ArithmeticContext arithmetic() {
			return getRuleContext(ArithmeticContext.class,0);
		}
		public TerminalNode RPAREN() { return getToken(RuneScriptParser.RPAREN, 0); }
		public CalcContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_calc; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitCalc(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CalcContext calc() throws RecognitionException {
		CalcContext _localctx = new CalcContext(_ctx, getState());
		enterRule(_localctx, 44, RULE_calc);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(292);
			match(CALC);
			setState(293);
			match(LPAREN);
			setState(294);
			arithmetic(0);
			setState(295);
			match(RPAREN);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ArithmeticContext extends ParserRuleContext {
		public ArithmeticContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_arithmetic; }
	 
		public ArithmeticContext() { }
		public void copyFrom(ArithmeticContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class ArithmeticBinaryExpressionContext extends ArithmeticContext {
		public Token op;
		public List<ArithmeticContext> arithmetic() {
			return getRuleContexts(ArithmeticContext.class);
		}
		public ArithmeticContext arithmetic(int i) {
			return getRuleContext(ArithmeticContext.class,i);
		}
		public TerminalNode MUL() { return getToken(RuneScriptParser.MUL, 0); }
		public TerminalNode DIV() { return getToken(RuneScriptParser.DIV, 0); }
		public TerminalNode MOD() { return getToken(RuneScriptParser.MOD, 0); }
		public TerminalNode PLUS() { return getToken(RuneScriptParser.PLUS, 0); }
		public TerminalNode MINUS() { return getToken(RuneScriptParser.MINUS, 0); }
		public TerminalNode AND() { return getToken(RuneScriptParser.AND, 0); }
		public TerminalNode OR() { return getToken(RuneScriptParser.OR, 0); }
		public ArithmeticBinaryExpressionContext(ArithmeticContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitArithmeticBinaryExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class ArithmeticParenthesizedExpressionContext extends ArithmeticContext {
		public TerminalNode LPAREN() { return getToken(RuneScriptParser.LPAREN, 0); }
		public ArithmeticContext arithmetic() {
			return getRuleContext(ArithmeticContext.class,0);
		}
		public TerminalNode RPAREN() { return getToken(RuneScriptParser.RPAREN, 0); }
		public ArithmeticParenthesizedExpressionContext(ArithmeticContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitArithmeticParenthesizedExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class ArithmeticNormalExpressionContext extends ArithmeticContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public ArithmeticNormalExpressionContext(ArithmeticContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitArithmeticNormalExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ArithmeticContext arithmetic() throws RecognitionException {
		return arithmetic(0);
	}

	private ArithmeticContext arithmetic(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		ArithmeticContext _localctx = new ArithmeticContext(_ctx, _parentState);
		ArithmeticContext _prevctx = _localctx;
		int _startState = 46;
		enterRecursionRule(_localctx, 46, RULE_arithmetic, _p);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(303);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,23,_ctx) ) {
			case 1:
				{
				_localctx = new ArithmeticParenthesizedExpressionContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;

				setState(298);
				match(LPAREN);
				setState(299);
				arithmetic(0);
				setState(300);
				match(RPAREN);
				}
				break;
			case 2:
				{
				_localctx = new ArithmeticNormalExpressionContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(302);
				expression();
				}
				break;
			}
			_ctx.stop = _input.LT(-1);
			setState(319);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,25,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					setState(317);
					_errHandler.sync(this);
					switch ( getInterpreter().adaptivePredict(_input,24,_ctx) ) {
					case 1:
						{
						_localctx = new ArithmeticBinaryExpressionContext(new ArithmeticContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_arithmetic);
						setState(305);
						if (!(precpred(_ctx, 5))) throw new FailedPredicateException(this, "precpred(_ctx, 5)");
						setState(306);
						((ArithmeticBinaryExpressionContext)_localctx).op = _input.LT(1);
						_la = _input.LA(1);
						if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << MUL) | (1L << DIV) | (1L << MOD))) != 0)) ) {
							((ArithmeticBinaryExpressionContext)_localctx).op = (Token)_errHandler.recoverInline(this);
						}
						else {
							if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
							_errHandler.reportMatch(this);
							consume();
						}
						setState(307);
						arithmetic(6);
						}
						break;
					case 2:
						{
						_localctx = new ArithmeticBinaryExpressionContext(new ArithmeticContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_arithmetic);
						setState(308);
						if (!(precpred(_ctx, 4))) throw new FailedPredicateException(this, "precpred(_ctx, 4)");
						setState(309);
						((ArithmeticBinaryExpressionContext)_localctx).op = _input.LT(1);
						_la = _input.LA(1);
						if ( !(_la==PLUS || _la==MINUS) ) {
							((ArithmeticBinaryExpressionContext)_localctx).op = (Token)_errHandler.recoverInline(this);
						}
						else {
							if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
							_errHandler.reportMatch(this);
							consume();
						}
						setState(310);
						arithmetic(5);
						}
						break;
					case 3:
						{
						_localctx = new ArithmeticBinaryExpressionContext(new ArithmeticContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_arithmetic);
						setState(311);
						if (!(precpred(_ctx, 3))) throw new FailedPredicateException(this, "precpred(_ctx, 3)");
						setState(312);
						((ArithmeticBinaryExpressionContext)_localctx).op = match(AND);
						setState(313);
						arithmetic(4);
						}
						break;
					case 4:
						{
						_localctx = new ArithmeticBinaryExpressionContext(new ArithmeticContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_arithmetic);
						setState(314);
						if (!(precpred(_ctx, 2))) throw new FailedPredicateException(this, "precpred(_ctx, 2)");
						setState(315);
						((ArithmeticBinaryExpressionContext)_localctx).op = match(OR);
						setState(316);
						arithmetic(3);
						}
						break;
					}
					} 
				}
				setState(321);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,25,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	public static class CallContext extends ParserRuleContext {
		public CallContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_call; }
	 
		public CallContext() { }
		public void copyFrom(CallContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class JumpCallExpressionContext extends CallContext {
		public TerminalNode AT() { return getToken(RuneScriptParser.AT, 0); }
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public TerminalNode LPAREN() { return getToken(RuneScriptParser.LPAREN, 0); }
		public TerminalNode RPAREN() { return getToken(RuneScriptParser.RPAREN, 0); }
		public ExpressionListContext expressionList() {
			return getRuleContext(ExpressionListContext.class,0);
		}
		public JumpCallExpressionContext(CallContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitJumpCallExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class CommandCallExpressionContext extends CallContext {
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public TerminalNode MUL() { return getToken(RuneScriptParser.MUL, 0); }
		public List<TerminalNode> LPAREN() { return getTokens(RuneScriptParser.LPAREN); }
		public TerminalNode LPAREN(int i) {
			return getToken(RuneScriptParser.LPAREN, i);
		}
		public List<TerminalNode> RPAREN() { return getTokens(RuneScriptParser.RPAREN); }
		public TerminalNode RPAREN(int i) {
			return getToken(RuneScriptParser.RPAREN, i);
		}
		public List<ExpressionListContext> expressionList() {
			return getRuleContexts(ExpressionListContext.class);
		}
		public ExpressionListContext expressionList(int i) {
			return getRuleContext(ExpressionListContext.class,i);
		}
		public CommandCallExpressionContext(CallContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitCommandCallExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class ProcCallExpressionContext extends CallContext {
		public TerminalNode TILDE() { return getToken(RuneScriptParser.TILDE, 0); }
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public TerminalNode LPAREN() { return getToken(RuneScriptParser.LPAREN, 0); }
		public TerminalNode RPAREN() { return getToken(RuneScriptParser.RPAREN, 0); }
		public ExpressionListContext expressionList() {
			return getRuleContext(ExpressionListContext.class,0);
		}
		public ProcCallExpressionContext(CallContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitProcCallExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CallContext call() throws RecognitionException {
		CallContext _localctx = new CallContext(_ctx, getState());
		enterRule(_localctx, 48, RULE_call);
		int _la;
		try {
			setState(360);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,33,_ctx) ) {
			case 1:
				_localctx = new CommandCallExpressionContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(322);
				identifier();
				setState(323);
				match(MUL);
				setState(324);
				match(LPAREN);
				setState(326);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << LPAREN) | (1L << MOD) | (1L << DOLLAR) | (1L << CARET) | (1L << TILDE) | (1L << AT) | (1L << INCREMENT) | (1L << DECREMENT) | (1L << DEFAULT) | (1L << CALC) | (1L << DEF_TYPE) | (1L << SWITCH_TYPE) | (1L << INTEGER_LITERAL) | (1L << HEX_LITERAL) | (1L << COORD_LITERAL) | (1L << BOOLEAN_LITERAL) | (1L << CHAR_LITERAL) | (1L << NULL_LITERAL) | (1L << QUOTE_OPEN) | (1L << IDENTIFIER))) != 0)) {
					{
					setState(325);
					expressionList();
					}
				}

				setState(328);
				match(RPAREN);
				setState(329);
				match(LPAREN);
				setState(331);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << LPAREN) | (1L << MOD) | (1L << DOLLAR) | (1L << CARET) | (1L << TILDE) | (1L << AT) | (1L << INCREMENT) | (1L << DECREMENT) | (1L << DEFAULT) | (1L << CALC) | (1L << DEF_TYPE) | (1L << SWITCH_TYPE) | (1L << INTEGER_LITERAL) | (1L << HEX_LITERAL) | (1L << COORD_LITERAL) | (1L << BOOLEAN_LITERAL) | (1L << CHAR_LITERAL) | (1L << NULL_LITERAL) | (1L << QUOTE_OPEN) | (1L << IDENTIFIER))) != 0)) {
					{
					setState(330);
					expressionList();
					}
				}

				setState(333);
				match(RPAREN);
				}
				break;
			case 2:
				_localctx = new CommandCallExpressionContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(335);
				identifier();
				setState(336);
				match(LPAREN);
				setState(338);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << LPAREN) | (1L << MOD) | (1L << DOLLAR) | (1L << CARET) | (1L << TILDE) | (1L << AT) | (1L << INCREMENT) | (1L << DECREMENT) | (1L << DEFAULT) | (1L << CALC) | (1L << DEF_TYPE) | (1L << SWITCH_TYPE) | (1L << INTEGER_LITERAL) | (1L << HEX_LITERAL) | (1L << COORD_LITERAL) | (1L << BOOLEAN_LITERAL) | (1L << CHAR_LITERAL) | (1L << NULL_LITERAL) | (1L << QUOTE_OPEN) | (1L << IDENTIFIER))) != 0)) {
					{
					setState(337);
					expressionList();
					}
				}

				setState(340);
				match(RPAREN);
				}
				break;
			case 3:
				_localctx = new ProcCallExpressionContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(342);
				match(TILDE);
				setState(343);
				identifier();
				setState(349);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,30,_ctx) ) {
				case 1:
					{
					setState(344);
					match(LPAREN);
					setState(346);
					_errHandler.sync(this);
					_la = _input.LA(1);
					if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << LPAREN) | (1L << MOD) | (1L << DOLLAR) | (1L << CARET) | (1L << TILDE) | (1L << AT) | (1L << INCREMENT) | (1L << DECREMENT) | (1L << DEFAULT) | (1L << CALC) | (1L << DEF_TYPE) | (1L << SWITCH_TYPE) | (1L << INTEGER_LITERAL) | (1L << HEX_LITERAL) | (1L << COORD_LITERAL) | (1L << BOOLEAN_LITERAL) | (1L << CHAR_LITERAL) | (1L << NULL_LITERAL) | (1L << QUOTE_OPEN) | (1L << IDENTIFIER))) != 0)) {
						{
						setState(345);
						expressionList();
						}
					}

					setState(348);
					match(RPAREN);
					}
					break;
				}
				}
				break;
			case 4:
				_localctx = new JumpCallExpressionContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(351);
				match(AT);
				setState(352);
				identifier();
				setState(358);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,32,_ctx) ) {
				case 1:
					{
					setState(353);
					match(LPAREN);
					setState(355);
					_errHandler.sync(this);
					_la = _input.LA(1);
					if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << LPAREN) | (1L << MOD) | (1L << DOLLAR) | (1L << CARET) | (1L << TILDE) | (1L << AT) | (1L << INCREMENT) | (1L << DECREMENT) | (1L << DEFAULT) | (1L << CALC) | (1L << DEF_TYPE) | (1L << SWITCH_TYPE) | (1L << INTEGER_LITERAL) | (1L << HEX_LITERAL) | (1L << COORD_LITERAL) | (1L << BOOLEAN_LITERAL) | (1L << CHAR_LITERAL) | (1L << NULL_LITERAL) | (1L << QUOTE_OPEN) | (1L << IDENTIFIER))) != 0)) {
						{
						setState(354);
						expressionList();
						}
					}

					setState(357);
					match(RPAREN);
					}
					break;
				}
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ClientScriptContext extends ParserRuleContext {
		public ExpressionListContext args;
		public ExpressionListContext triggers;
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public TerminalNode EOF() { return getToken(RuneScriptParser.EOF, 0); }
		public TerminalNode LPAREN() { return getToken(RuneScriptParser.LPAREN, 0); }
		public TerminalNode RPAREN() { return getToken(RuneScriptParser.RPAREN, 0); }
		public TerminalNode LBRACE() { return getToken(RuneScriptParser.LBRACE, 0); }
		public TerminalNode RBRACE() { return getToken(RuneScriptParser.RBRACE, 0); }
		public List<ExpressionListContext> expressionList() {
			return getRuleContexts(ExpressionListContext.class);
		}
		public ExpressionListContext expressionList(int i) {
			return getRuleContext(ExpressionListContext.class,i);
		}
		public ClientScriptContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_clientScript; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitClientScript(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ClientScriptContext clientScript() throws RecognitionException {
		ClientScriptContext _localctx = new ClientScriptContext(_ctx, getState());
		enterRule(_localctx, 50, RULE_clientScript);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(362);
			identifier();
			setState(368);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==LPAREN) {
				{
				setState(363);
				match(LPAREN);
				setState(365);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << LPAREN) | (1L << MOD) | (1L << DOLLAR) | (1L << CARET) | (1L << TILDE) | (1L << AT) | (1L << INCREMENT) | (1L << DECREMENT) | (1L << DEFAULT) | (1L << CALC) | (1L << DEF_TYPE) | (1L << SWITCH_TYPE) | (1L << INTEGER_LITERAL) | (1L << HEX_LITERAL) | (1L << COORD_LITERAL) | (1L << BOOLEAN_LITERAL) | (1L << CHAR_LITERAL) | (1L << NULL_LITERAL) | (1L << QUOTE_OPEN) | (1L << IDENTIFIER))) != 0)) {
					{
					setState(364);
					((ClientScriptContext)_localctx).args = expressionList();
					}
				}

				setState(367);
				match(RPAREN);
				}
			}

			setState(375);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==LBRACE) {
				{
				setState(370);
				match(LBRACE);
				setState(372);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << LPAREN) | (1L << MOD) | (1L << DOLLAR) | (1L << CARET) | (1L << TILDE) | (1L << AT) | (1L << INCREMENT) | (1L << DECREMENT) | (1L << DEFAULT) | (1L << CALC) | (1L << DEF_TYPE) | (1L << SWITCH_TYPE) | (1L << INTEGER_LITERAL) | (1L << HEX_LITERAL) | (1L << COORD_LITERAL) | (1L << BOOLEAN_LITERAL) | (1L << CHAR_LITERAL) | (1L << NULL_LITERAL) | (1L << QUOTE_OPEN) | (1L << IDENTIFIER))) != 0)) {
					{
					setState(371);
					((ClientScriptContext)_localctx).triggers = expressionList();
					}
				}

				setState(374);
				match(RBRACE);
				}
			}

			setState(377);
			match(EOF);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AssignableVariableListContext extends ParserRuleContext {
		public List<AssignableVariableContext> assignableVariable() {
			return getRuleContexts(AssignableVariableContext.class);
		}
		public AssignableVariableContext assignableVariable(int i) {
			return getRuleContext(AssignableVariableContext.class,i);
		}
		public List<TerminalNode> COMMA() { return getTokens(RuneScriptParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(RuneScriptParser.COMMA, i);
		}
		public AssignableVariableListContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_assignableVariableList; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitAssignableVariableList(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AssignableVariableListContext assignableVariableList() throws RecognitionException {
		AssignableVariableListContext _localctx = new AssignableVariableListContext(_ctx, getState());
		enterRule(_localctx, 52, RULE_assignableVariableList);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(379);
			assignableVariable();
			setState(384);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==COMMA) {
				{
				{
				setState(380);
				match(COMMA);
				setState(381);
				assignableVariable();
				}
				}
				setState(386);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AssignableVariableContext extends ParserRuleContext {
		public LocalVariableContext localVariable() {
			return getRuleContext(LocalVariableContext.class,0);
		}
		public LocalArrayVariableContext localArrayVariable() {
			return getRuleContext(LocalArrayVariableContext.class,0);
		}
		public GameVariableContext gameVariable() {
			return getRuleContext(GameVariableContext.class,0);
		}
		public AssignableVariableContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_assignableVariable; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitAssignableVariable(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AssignableVariableContext assignableVariable() throws RecognitionException {
		AssignableVariableContext _localctx = new AssignableVariableContext(_ctx, getState());
		enterRule(_localctx, 54, RULE_assignableVariable);
		try {
			setState(390);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,39,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(387);
				localVariable();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(388);
				localArrayVariable();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(389);
				gameVariable();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class LocalVariableContext extends ParserRuleContext {
		public TerminalNode DOLLAR() { return getToken(RuneScriptParser.DOLLAR, 0); }
		public AdvancedIdentifierContext advancedIdentifier() {
			return getRuleContext(AdvancedIdentifierContext.class,0);
		}
		public LocalVariableContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_localVariable; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitLocalVariable(this);
			else return visitor.visitChildren(this);
		}
	}

	public final LocalVariableContext localVariable() throws RecognitionException {
		LocalVariableContext _localctx = new LocalVariableContext(_ctx, getState());
		enterRule(_localctx, 56, RULE_localVariable);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(392);
			match(DOLLAR);
			setState(393);
			advancedIdentifier();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class LocalArrayVariableContext extends ParserRuleContext {
		public TerminalNode DOLLAR() { return getToken(RuneScriptParser.DOLLAR, 0); }
		public AdvancedIdentifierContext advancedIdentifier() {
			return getRuleContext(AdvancedIdentifierContext.class,0);
		}
		public ParenthesisContext parenthesis() {
			return getRuleContext(ParenthesisContext.class,0);
		}
		public LocalArrayVariableContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_localArrayVariable; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitLocalArrayVariable(this);
			else return visitor.visitChildren(this);
		}
	}

	public final LocalArrayVariableContext localArrayVariable() throws RecognitionException {
		LocalArrayVariableContext _localctx = new LocalArrayVariableContext(_ctx, getState());
		enterRule(_localctx, 58, RULE_localArrayVariable);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(395);
			match(DOLLAR);
			setState(396);
			advancedIdentifier();
			setState(397);
			parenthesis();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class GameVariableContext extends ParserRuleContext {
		public TerminalNode MOD() { return getToken(RuneScriptParser.MOD, 0); }
		public AdvancedIdentifierContext advancedIdentifier() {
			return getRuleContext(AdvancedIdentifierContext.class,0);
		}
		public GameVariableContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_gameVariable; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitGameVariable(this);
			else return visitor.visitChildren(this);
		}
	}

	public final GameVariableContext gameVariable() throws RecognitionException {
		GameVariableContext _localctx = new GameVariableContext(_ctx, getState());
		enterRule(_localctx, 60, RULE_gameVariable);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(399);
			match(MOD);
			setState(400);
			advancedIdentifier();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ConstantVariableContext extends ParserRuleContext {
		public TerminalNode CARET() { return getToken(RuneScriptParser.CARET, 0); }
		public AdvancedIdentifierContext advancedIdentifier() {
			return getRuleContext(AdvancedIdentifierContext.class,0);
		}
		public ConstantVariableContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_constantVariable; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitConstantVariable(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ConstantVariableContext constantVariable() throws RecognitionException {
		ConstantVariableContext _localctx = new ConstantVariableContext(_ctx, getState());
		enterRule(_localctx, 62, RULE_constantVariable);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(402);
			match(CARET);
			setState(403);
			advancedIdentifier();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class LiteralContext extends ParserRuleContext {
		public LiteralContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_literal; }
	 
		public LiteralContext() { }
		public void copyFrom(LiteralContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class StringLiteralExpressionContext extends LiteralContext {
		public StringLiteralContext stringLiteral() {
			return getRuleContext(StringLiteralContext.class,0);
		}
		public StringLiteralExpressionContext(LiteralContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitStringLiteralExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class BooleanLiteralContext extends LiteralContext {
		public TerminalNode BOOLEAN_LITERAL() { return getToken(RuneScriptParser.BOOLEAN_LITERAL, 0); }
		public BooleanLiteralContext(LiteralContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitBooleanLiteral(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class HexLiteralContext extends LiteralContext {
		public TerminalNode HEX_LITERAL() { return getToken(RuneScriptParser.HEX_LITERAL, 0); }
		public HexLiteralContext(LiteralContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitHexLiteral(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class CoordLiteralContext extends LiteralContext {
		public TerminalNode COORD_LITERAL() { return getToken(RuneScriptParser.COORD_LITERAL, 0); }
		public CoordLiteralContext(LiteralContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitCoordLiteral(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class NullLiteralContext extends LiteralContext {
		public TerminalNode NULL_LITERAL() { return getToken(RuneScriptParser.NULL_LITERAL, 0); }
		public NullLiteralContext(LiteralContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitNullLiteral(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class IntegerLiteralContext extends LiteralContext {
		public TerminalNode INTEGER_LITERAL() { return getToken(RuneScriptParser.INTEGER_LITERAL, 0); }
		public IntegerLiteralContext(LiteralContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitIntegerLiteral(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class CharacterLiteralContext extends LiteralContext {
		public TerminalNode CHAR_LITERAL() { return getToken(RuneScriptParser.CHAR_LITERAL, 0); }
		public CharacterLiteralContext(LiteralContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitCharacterLiteral(this);
			else return visitor.visitChildren(this);
		}
	}

	public final LiteralContext literal() throws RecognitionException {
		LiteralContext _localctx = new LiteralContext(_ctx, getState());
		enterRule(_localctx, 64, RULE_literal);
		try {
			setState(412);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case INTEGER_LITERAL:
				_localctx = new IntegerLiteralContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(405);
				match(INTEGER_LITERAL);
				}
				break;
			case HEX_LITERAL:
				_localctx = new HexLiteralContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(406);
				match(HEX_LITERAL);
				}
				break;
			case COORD_LITERAL:
				_localctx = new CoordLiteralContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(407);
				match(COORD_LITERAL);
				}
				break;
			case BOOLEAN_LITERAL:
				_localctx = new BooleanLiteralContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(408);
				match(BOOLEAN_LITERAL);
				}
				break;
			case CHAR_LITERAL:
				_localctx = new CharacterLiteralContext(_localctx);
				enterOuterAlt(_localctx, 5);
				{
				setState(409);
				match(CHAR_LITERAL);
				}
				break;
			case NULL_LITERAL:
				_localctx = new NullLiteralContext(_localctx);
				enterOuterAlt(_localctx, 6);
				{
				setState(410);
				match(NULL_LITERAL);
				}
				break;
			case QUOTE_OPEN:
				_localctx = new StringLiteralExpressionContext(_localctx);
				enterOuterAlt(_localctx, 7);
				{
				setState(411);
				stringLiteral();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class StringLiteralContext extends ParserRuleContext {
		public TerminalNode QUOTE_OPEN() { return getToken(RuneScriptParser.QUOTE_OPEN, 0); }
		public TerminalNode QUOTE_CLOSE() { return getToken(RuneScriptParser.QUOTE_CLOSE, 0); }
		public List<StringLiteralContentContext> stringLiteralContent() {
			return getRuleContexts(StringLiteralContentContext.class);
		}
		public StringLiteralContentContext stringLiteralContent(int i) {
			return getRuleContext(StringLiteralContentContext.class,i);
		}
		public StringLiteralContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_stringLiteral; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitStringLiteral(this);
			else return visitor.visitChildren(this);
		}
	}

	public final StringLiteralContext stringLiteral() throws RecognitionException {
		StringLiteralContext _localctx = new StringLiteralContext(_ctx, getState());
		enterRule(_localctx, 66, RULE_stringLiteral);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(414);
			match(QUOTE_OPEN);
			setState(418);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==STRING_TEXT) {
				{
				{
				setState(415);
				stringLiteralContent();
				}
				}
				setState(420);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(421);
			match(QUOTE_CLOSE);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class StringLiteralContentContext extends ParserRuleContext {
		public TerminalNode STRING_TEXT() { return getToken(RuneScriptParser.STRING_TEXT, 0); }
		public StringLiteralContentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_stringLiteralContent; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitStringLiteralContent(this);
			else return visitor.visitChildren(this);
		}
	}

	public final StringLiteralContentContext stringLiteralContent() throws RecognitionException {
		StringLiteralContentContext _localctx = new StringLiteralContentContext(_ctx, getState());
		enterRule(_localctx, 68, RULE_stringLiteralContent);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(423);
			match(STRING_TEXT);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class JoinedStringContext extends ParserRuleContext {
		public TerminalNode QUOTE_OPEN() { return getToken(RuneScriptParser.QUOTE_OPEN, 0); }
		public TerminalNode QUOTE_CLOSE() { return getToken(RuneScriptParser.QUOTE_CLOSE, 0); }
		public List<StringLiteralContentContext> stringLiteralContent() {
			return getRuleContexts(StringLiteralContentContext.class);
		}
		public StringLiteralContentContext stringLiteralContent(int i) {
			return getRuleContext(StringLiteralContentContext.class,i);
		}
		public List<StringTagContext> stringTag() {
			return getRuleContexts(StringTagContext.class);
		}
		public StringTagContext stringTag(int i) {
			return getRuleContext(StringTagContext.class,i);
		}
		public List<StringPTagContext> stringPTag() {
			return getRuleContexts(StringPTagContext.class);
		}
		public StringPTagContext stringPTag(int i) {
			return getRuleContext(StringPTagContext.class,i);
		}
		public List<StringTemplateContext> stringTemplate() {
			return getRuleContexts(StringTemplateContext.class);
		}
		public StringTemplateContext stringTemplate(int i) {
			return getRuleContext(StringTemplateContext.class,i);
		}
		public List<StringExpressionContext> stringExpression() {
			return getRuleContexts(StringExpressionContext.class);
		}
		public StringExpressionContext stringExpression(int i) {
			return getRuleContext(StringExpressionContext.class,i);
		}
		public JoinedStringContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_joinedString; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitJoinedString(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JoinedStringContext joinedString() throws RecognitionException {
		JoinedStringContext _localctx = new JoinedStringContext(_ctx, getState());
		enterRule(_localctx, 70, RULE_joinedString);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(425);
			match(QUOTE_OPEN);
			setState(433);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << STRING_TEXT) | (1L << STRING_TAG) | (1L << STRING_CLOSE_TAG) | (1L << STRING_PARTIAL_TAG) | (1L << STRING_P_TAG) | (1L << STRING_EXPR_START) | (1L << STRING_TEMPLATE))) != 0)) {
				{
				setState(431);
				_errHandler.sync(this);
				switch (_input.LA(1)) {
				case STRING_TEXT:
					{
					setState(426);
					stringLiteralContent();
					}
					break;
				case STRING_TAG:
				case STRING_CLOSE_TAG:
				case STRING_PARTIAL_TAG:
					{
					setState(427);
					stringTag();
					}
					break;
				case STRING_P_TAG:
					{
					setState(428);
					stringPTag();
					}
					break;
				case STRING_TEMPLATE:
					{
					setState(429);
					stringTemplate();
					}
					break;
				case STRING_EXPR_START:
					{
					setState(430);
					stringExpression();
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				}
				setState(435);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(436);
			match(QUOTE_CLOSE);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class StringTagContext extends ParserRuleContext {
		public TerminalNode STRING_TAG() { return getToken(RuneScriptParser.STRING_TAG, 0); }
		public TerminalNode STRING_CLOSE_TAG() { return getToken(RuneScriptParser.STRING_CLOSE_TAG, 0); }
		public TerminalNode STRING_PARTIAL_TAG() { return getToken(RuneScriptParser.STRING_PARTIAL_TAG, 0); }
		public StringTagContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_stringTag; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitStringTag(this);
			else return visitor.visitChildren(this);
		}
	}

	public final StringTagContext stringTag() throws RecognitionException {
		StringTagContext _localctx = new StringTagContext(_ctx, getState());
		enterRule(_localctx, 72, RULE_stringTag);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(438);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << STRING_TAG) | (1L << STRING_CLOSE_TAG) | (1L << STRING_PARTIAL_TAG))) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class StringPTagContext extends ParserRuleContext {
		public TerminalNode STRING_P_TAG() { return getToken(RuneScriptParser.STRING_P_TAG, 0); }
		public StringPTagContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_stringPTag; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitStringPTag(this);
			else return visitor.visitChildren(this);
		}
	}

	public final StringPTagContext stringPTag() throws RecognitionException {
		StringPTagContext _localctx = new StringPTagContext(_ctx, getState());
		enterRule(_localctx, 74, RULE_stringPTag);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(440);
			match(STRING_P_TAG);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class StringTemplateContext extends ParserRuleContext {
		public TerminalNode STRING_TEMPLATE() { return getToken(RuneScriptParser.STRING_TEMPLATE, 0); }
		public StringTemplateContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_stringTemplate; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitStringTemplate(this);
			else return visitor.visitChildren(this);
		}
	}

	public final StringTemplateContext stringTemplate() throws RecognitionException {
		StringTemplateContext _localctx = new StringTemplateContext(_ctx, getState());
		enterRule(_localctx, 76, RULE_stringTemplate);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(442);
			match(STRING_TEMPLATE);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class StringExpressionContext extends ParserRuleContext {
		public TerminalNode STRING_EXPR_START() { return getToken(RuneScriptParser.STRING_EXPR_START, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public TerminalNode STRING_EXPR_END() { return getToken(RuneScriptParser.STRING_EXPR_END, 0); }
		public StringExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_stringExpression; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitStringExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final StringExpressionContext stringExpression() throws RecognitionException {
		StringExpressionContext _localctx = new StringExpressionContext(_ctx, getState());
		enterRule(_localctx, 78, RULE_stringExpression);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(444);
			match(STRING_EXPR_START);
			setState(445);
			expression();
			setState(446);
			match(STRING_EXPR_END);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class IdentifierContext extends ParserRuleContext {
		public TerminalNode IDENTIFIER() { return getToken(RuneScriptParser.IDENTIFIER, 0); }
		public TerminalNode HEX_LITERAL() { return getToken(RuneScriptParser.HEX_LITERAL, 0); }
		public TerminalNode BOOLEAN_LITERAL() { return getToken(RuneScriptParser.BOOLEAN_LITERAL, 0); }
		public TerminalNode NULL_LITERAL() { return getToken(RuneScriptParser.NULL_LITERAL, 0); }
		public TerminalNode SWITCH_TYPE() { return getToken(RuneScriptParser.SWITCH_TYPE, 0); }
		public TerminalNode DEF_TYPE() { return getToken(RuneScriptParser.DEF_TYPE, 0); }
		public TerminalNode DEFAULT() { return getToken(RuneScriptParser.DEFAULT, 0); }
		public IdentifierContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_identifier; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitIdentifier(this);
			else return visitor.visitChildren(this);
		}
	}

	public final IdentifierContext identifier() throws RecognitionException {
		IdentifierContext _localctx = new IdentifierContext(_ctx, getState());
		enterRule(_localctx, 80, RULE_identifier);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(448);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << DEFAULT) | (1L << DEF_TYPE) | (1L << SWITCH_TYPE) | (1L << HEX_LITERAL) | (1L << BOOLEAN_LITERAL) | (1L << NULL_LITERAL) | (1L << IDENTIFIER))) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AdvancedIdentifierContext extends ParserRuleContext {
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public TerminalNode INTEGER_LITERAL() { return getToken(RuneScriptParser.INTEGER_LITERAL, 0); }
		public TerminalNode IF() { return getToken(RuneScriptParser.IF, 0); }
		public TerminalNode ELSE() { return getToken(RuneScriptParser.ELSE, 0); }
		public TerminalNode WHILE() { return getToken(RuneScriptParser.WHILE, 0); }
		public TerminalNode RETURN() { return getToken(RuneScriptParser.RETURN, 0); }
		public TerminalNode CALC() { return getToken(RuneScriptParser.CALC, 0); }
		public AdvancedIdentifierContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_advancedIdentifier; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RuneScriptParserVisitor ) return ((RuneScriptParserVisitor<? extends T>)visitor).visitAdvancedIdentifier(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AdvancedIdentifierContext advancedIdentifier() throws RecognitionException {
		AdvancedIdentifierContext _localctx = new AdvancedIdentifierContext(_ctx, getState());
		enterRule(_localctx, 82, RULE_advancedIdentifier);
		try {
			setState(457);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case DEFAULT:
			case DEF_TYPE:
			case SWITCH_TYPE:
			case HEX_LITERAL:
			case BOOLEAN_LITERAL:
			case NULL_LITERAL:
			case IDENTIFIER:
				enterOuterAlt(_localctx, 1);
				{
				setState(450);
				identifier();
				}
				break;
			case INTEGER_LITERAL:
				enterOuterAlt(_localctx, 2);
				{
				setState(451);
				match(INTEGER_LITERAL);
				}
				break;
			case IF:
				enterOuterAlt(_localctx, 3);
				{
				setState(452);
				match(IF);
				}
				break;
			case ELSE:
				enterOuterAlt(_localctx, 4);
				{
				setState(453);
				match(ELSE);
				}
				break;
			case WHILE:
				enterOuterAlt(_localctx, 5);
				{
				setState(454);
				match(WHILE);
				}
				break;
			case RETURN:
				enterOuterAlt(_localctx, 6);
				{
				setState(455);
				match(RETURN);
				}
				break;
			case CALC:
				enterOuterAlt(_localctx, 7);
				{
				setState(456);
				match(CALC);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public boolean sempred(RuleContext _localctx, int ruleIndex, int predIndex) {
		switch (ruleIndex) {
		case 21:
			return condition_sempred((ConditionContext)_localctx, predIndex);
		case 23:
			return arithmetic_sempred((ArithmeticContext)_localctx, predIndex);
		}
		return true;
	}
	private boolean condition_sempred(ConditionContext _localctx, int predIndex) {
		switch (predIndex) {
		case 0:
			return precpred(_ctx, 5);
		case 1:
			return precpred(_ctx, 4);
		case 2:
			return precpred(_ctx, 3);
		case 3:
			return precpred(_ctx, 2);
		}
		return true;
	}
	private boolean arithmetic_sempred(ArithmeticContext _localctx, int predIndex) {
		switch (predIndex) {
		case 4:
			return precpred(_ctx, 5);
		case 5:
			return precpred(_ctx, 4);
		case 6:
			return precpred(_ctx, 3);
		case 7:
			return precpred(_ctx, 2);
		}
		return true;
	}

	public static final String _serializedATN =
		"\u0004\u00019\u01cc\u0002\u0000\u0007\u0000\u0002\u0001\u0007\u0001\u0002"+
		"\u0002\u0007\u0002\u0002\u0003\u0007\u0003\u0002\u0004\u0007\u0004\u0002"+
		"\u0005\u0007\u0005\u0002\u0006\u0007\u0006\u0002\u0007\u0007\u0007\u0002"+
		"\b\u0007\b\u0002\t\u0007\t\u0002\n\u0007\n\u0002\u000b\u0007\u000b\u0002"+
		"\f\u0007\f\u0002\r\u0007\r\u0002\u000e\u0007\u000e\u0002\u000f\u0007\u000f"+
		"\u0002\u0010\u0007\u0010\u0002\u0011\u0007\u0011\u0002\u0012\u0007\u0012"+
		"\u0002\u0013\u0007\u0013\u0002\u0014\u0007\u0014\u0002\u0015\u0007\u0015"+
		"\u0002\u0016\u0007\u0016\u0002\u0017\u0007\u0017\u0002\u0018\u0007\u0018"+
		"\u0002\u0019\u0007\u0019\u0002\u001a\u0007\u001a\u0002\u001b\u0007\u001b"+
		"\u0002\u001c\u0007\u001c\u0002\u001d\u0007\u001d\u0002\u001e\u0007\u001e"+
		"\u0002\u001f\u0007\u001f\u0002 \u0007 \u0002!\u0007!\u0002\"\u0007\"\u0002"+
		"#\u0007#\u0002$\u0007$\u0002%\u0007%\u0002&\u0007&\u0002\'\u0007\'\u0002"+
		"(\u0007(\u0002)\u0007)\u0001\u0000\u0005\u0000V\b\u0000\n\u0000\f\u0000"+
		"Y\t\u0000\u0001\u0000\u0001\u0000\u0001\u0001\u0001\u0001\u0001\u0001"+
		"\u0001\u0001\u0001\u0001\u0003\u0001b\b\u0001\u0001\u0001\u0001\u0001"+
		"\u0001\u0001\u0003\u0001g\b\u0001\u0001\u0001\u0001\u0001\u0001\u0001"+
		"\u0001\u0001\u0003\u0001m\b\u0001\u0001\u0001\u0003\u0001p\b\u0001\u0003"+
		"\u0001r\b\u0001\u0001\u0001\u0005\u0001u\b\u0001\n\u0001\f\u0001x\t\u0001"+
		"\u0001\u0002\u0001\u0002\u0001\u0002\u0005\u0002}\b\u0002\n\u0002\f\u0002"+
		"\u0080\t\u0002\u0001\u0003\u0001\u0003\u0001\u0003\u0001\u0003\u0001\u0004"+
		"\u0001\u0004\u0001\u0004\u0005\u0004\u0089\b\u0004\n\u0004\f\u0004\u008c"+
		"\t\u0004\u0001\u0005\u0001\u0005\u0001\u0005\u0001\u0005\u0001\u0005\u0001"+
		"\u0005\u0001\u0005\u0001\u0005\u0001\u0005\u0001\u0005\u0003\u0005\u0098"+
		"\b\u0005\u0001\u0006\u0001\u0006\u0005\u0006\u009c\b\u0006\n\u0006\f\u0006"+
		"\u009f\t\u0006\u0001\u0006\u0001\u0006\u0001\u0007\u0001\u0007\u0001\u0007"+
		"\u0003\u0007\u00a6\b\u0007\u0001\u0007\u0003\u0007\u00a9\b\u0007\u0001"+
		"\u0007\u0001\u0007\u0001\b\u0001\b\u0001\b\u0001\b\u0001\b\u0001\b\u0001"+
		"\b\u0003\b\u00b4\b\b\u0001\t\u0001\t\u0001\t\u0001\t\u0001\t\u0001\t\u0001"+
		"\n\u0001\n\u0001\n\u0001\n\u0005\n\u00c0\b\n\n\n\f\n\u00c3\t\n\u0001\n"+
		"\u0001\n\u0001\u000b\u0001\u000b\u0001\u000b\u0003\u000b\u00ca\b\u000b"+
		"\u0001\u000b\u0001\u000b\u0005\u000b\u00ce\b\u000b\n\u000b\f\u000b\u00d1"+
		"\t\u000b\u0001\f\u0001\f\u0001\f\u0001\f\u0001\f\u0003\f\u00d8\b\f\u0001"+
		"\f\u0001\f\u0001\r\u0001\r\u0001\r\u0001\r\u0001\r\u0001\r\u0001\u000e"+
		"\u0001\u000e\u0001\u000e\u0001\u000e\u0001\u000e\u0001\u000f\u0001\u000f"+
		"\u0001\u000f\u0001\u0010\u0001\u0010\u0001\u0011\u0001\u0011\u0001\u0011"+
		"\u0005\u0011\u00ef\b\u0011\n\u0011\f\u0011\u00f2\t\u0011\u0001\u0012\u0001"+
		"\u0012\u0001\u0012\u0001\u0012\u0001\u0013\u0001\u0013\u0001\u0013\u0001"+
		"\u0014\u0001\u0014\u0001\u0014\u0001\u0014\u0001\u0014\u0001\u0014\u0001"+
		"\u0014\u0001\u0014\u0001\u0014\u0001\u0014\u0001\u0014\u0001\u0014\u0001"+
		"\u0014\u0001\u0014\u0001\u0014\u0003\u0014\u010a\b\u0014\u0001\u0015\u0001"+
		"\u0015\u0001\u0015\u0001\u0015\u0001\u0015\u0001\u0015\u0003\u0015\u0112"+
		"\b\u0015\u0001\u0015\u0001\u0015\u0001\u0015\u0001\u0015\u0001\u0015\u0001"+
		"\u0015\u0001\u0015\u0001\u0015\u0001\u0015\u0001\u0015\u0001\u0015\u0001"+
		"\u0015\u0005\u0015\u0120\b\u0015\n\u0015\f\u0015\u0123\t\u0015\u0001\u0016"+
		"\u0001\u0016\u0001\u0016\u0001\u0016\u0001\u0016\u0001\u0017\u0001\u0017"+
		"\u0001\u0017\u0001\u0017\u0001\u0017\u0001\u0017\u0003\u0017\u0130\b\u0017"+
		"\u0001\u0017\u0001\u0017\u0001\u0017\u0001\u0017\u0001\u0017\u0001\u0017"+
		"\u0001\u0017\u0001\u0017\u0001\u0017\u0001\u0017\u0001\u0017\u0001\u0017"+
		"\u0005\u0017\u013e\b\u0017\n\u0017\f\u0017\u0141\t\u0017\u0001\u0018\u0001"+
		"\u0018\u0001\u0018\u0001\u0018\u0003\u0018\u0147\b\u0018\u0001\u0018\u0001"+
		"\u0018\u0001\u0018\u0003\u0018\u014c\b\u0018\u0001\u0018\u0001\u0018\u0001"+
		"\u0018\u0001\u0018\u0001\u0018\u0003\u0018\u0153\b\u0018\u0001\u0018\u0001"+
		"\u0018\u0001\u0018\u0001\u0018\u0001\u0018\u0001\u0018\u0003\u0018\u015b"+
		"\b\u0018\u0001\u0018\u0003\u0018\u015e\b\u0018\u0001\u0018\u0001\u0018"+
		"\u0001\u0018\u0001\u0018\u0003\u0018\u0164\b\u0018\u0001\u0018\u0003\u0018"+
		"\u0167\b\u0018\u0003\u0018\u0169\b\u0018\u0001\u0019\u0001\u0019\u0001"+
		"\u0019\u0003\u0019\u016e\b\u0019\u0001\u0019\u0003\u0019\u0171\b\u0019"+
		"\u0001\u0019\u0001\u0019\u0003\u0019\u0175\b\u0019\u0001\u0019\u0003\u0019"+
		"\u0178\b\u0019\u0001\u0019\u0001\u0019\u0001\u001a\u0001\u001a\u0001\u001a"+
		"\u0005\u001a\u017f\b\u001a\n\u001a\f\u001a\u0182\t\u001a\u0001\u001b\u0001"+
		"\u001b\u0001\u001b\u0003\u001b\u0187\b\u001b\u0001\u001c\u0001\u001c\u0001"+
		"\u001c\u0001\u001d\u0001\u001d\u0001\u001d\u0001\u001d\u0001\u001e\u0001"+
		"\u001e\u0001\u001e\u0001\u001f\u0001\u001f\u0001\u001f\u0001 \u0001 \u0001"+
		" \u0001 \u0001 \u0001 \u0001 \u0003 \u019d\b \u0001!\u0001!\u0005!\u01a1"+
		"\b!\n!\f!\u01a4\t!\u0001!\u0001!\u0001\"\u0001\"\u0001#\u0001#\u0001#"+
		"\u0001#\u0001#\u0001#\u0005#\u01b0\b#\n#\f#\u01b3\t#\u0001#\u0001#\u0001"+
		"$\u0001$\u0001%\u0001%\u0001&\u0001&\u0001\'\u0001\'\u0001\'\u0001\'\u0001"+
		"(\u0001(\u0001)\u0001)\u0001)\u0001)\u0001)\u0001)\u0001)\u0003)\u01ca"+
		"\b)\u0001)\u0000\u0002*.*\u0000\u0002\u0004\u0006\b\n\f\u000e\u0010\u0012"+
		"\u0014\u0016\u0018\u001a\u001c\u001e \"$&(*,.02468:<>@BDFHJLNPR\u0000"+
		"\u0007\u0001\u0000\u001b\u001c\u0001\u0000\u0017\u001a\u0001\u0000\u0011"+
		"\u0012\u0001\u0000\f\u000e\u0001\u0000\n\u000b\u0001\u000035\u0006\u0000"+
		"!!$%\'\'))++//\u01f4\u0000W\u0001\u0000\u0000\u0000\u0002\\\u0001\u0000"+
		"\u0000\u0000\u0004y\u0001\u0000\u0000\u0000\u0006\u0081\u0001\u0000\u0000"+
		"\u0000\b\u0085\u0001\u0000\u0000\u0000\n\u0097\u0001\u0000\u0000\u0000"+
		"\f\u0099\u0001\u0000\u0000\u0000\u000e\u00a2\u0001\u0000\u0000\u0000\u0010"+
		"\u00ac\u0001\u0000\u0000\u0000\u0012\u00b5\u0001\u0000\u0000\u0000\u0014"+
		"\u00bb\u0001\u0000\u0000\u0000\u0016\u00c6\u0001\u0000\u0000\u0000\u0018"+
		"\u00d2\u0001\u0000\u0000\u0000\u001a\u00db\u0001\u0000\u0000\u0000\u001c"+
		"\u00e1\u0001\u0000\u0000\u0000\u001e\u00e6\u0001\u0000\u0000\u0000 \u00e9"+
		"\u0001\u0000\u0000\u0000\"\u00eb\u0001\u0000\u0000\u0000$\u00f3\u0001"+
		"\u0000\u0000\u0000&\u00f7\u0001\u0000\u0000\u0000(\u0109\u0001\u0000\u0000"+
		"\u0000*\u0111\u0001\u0000\u0000\u0000,\u0124\u0001\u0000\u0000\u0000."+
		"\u012f\u0001\u0000\u0000\u00000\u0168\u0001\u0000\u0000\u00002\u016a\u0001"+
		"\u0000\u0000\u00004\u017b\u0001\u0000\u0000\u00006\u0186\u0001\u0000\u0000"+
		"\u00008\u0188\u0001\u0000\u0000\u0000:\u018b\u0001\u0000\u0000\u0000<"+
		"\u018f\u0001\u0000\u0000\u0000>\u0192\u0001\u0000\u0000\u0000@\u019c\u0001"+
		"\u0000\u0000\u0000B\u019e\u0001\u0000\u0000\u0000D\u01a7\u0001\u0000\u0000"+
		"\u0000F\u01a9\u0001\u0000\u0000\u0000H\u01b6\u0001\u0000\u0000\u0000J"+
		"\u01b8\u0001\u0000\u0000\u0000L\u01ba\u0001\u0000\u0000\u0000N\u01bc\u0001"+
		"\u0000\u0000\u0000P\u01c0\u0001\u0000\u0000\u0000R\u01c9\u0001\u0000\u0000"+
		"\u0000TV\u0003\u0002\u0001\u0000UT\u0001\u0000\u0000\u0000VY\u0001\u0000"+
		"\u0000\u0000WU\u0001\u0000\u0000\u0000WX\u0001\u0000\u0000\u0000XZ\u0001"+
		"\u0000\u0000\u0000YW\u0001\u0000\u0000\u0000Z[\u0005\u0000\u0000\u0001"+
		"[\u0001\u0001\u0000\u0000\u0000\\]\u0005\u0006\u0000\u0000]^\u0003P(\u0000"+
		"^_\u0005\u0005\u0000\u0000_a\u0003P(\u0000`b\u0005\f\u0000\u0000a`\u0001"+
		"\u0000\u0000\u0000ab\u0001\u0000\u0000\u0000bc\u0001\u0000\u0000\u0000"+
		"cq\u0005\u0007\u0000\u0000df\u0005\u0001\u0000\u0000eg\u0003\u0004\u0002"+
		"\u0000fe\u0001\u0000\u0000\u0000fg\u0001\u0000\u0000\u0000gh\u0001\u0000"+
		"\u0000\u0000hi\u0005\u0002\u0000\u0000io\u0001\u0000\u0000\u0000jl\u0005"+
		"\u0001\u0000\u0000km\u0003\b\u0004\u0000lk\u0001\u0000\u0000\u0000lm\u0001"+
		"\u0000\u0000\u0000mn\u0001\u0000\u0000\u0000np\u0005\u0002\u0000\u0000"+
		"oj\u0001\u0000\u0000\u0000op\u0001\u0000\u0000\u0000pr\u0001\u0000\u0000"+
		"\u0000qd\u0001\u0000\u0000\u0000qr\u0001\u0000\u0000\u0000rv\u0001\u0000"+
		"\u0000\u0000su\u0003\n\u0005\u0000ts\u0001\u0000\u0000\u0000ux\u0001\u0000"+
		"\u0000\u0000vt\u0001\u0000\u0000\u0000vw\u0001\u0000\u0000\u0000w\u0003"+
		"\u0001\u0000\u0000\u0000xv\u0001\u0000\u0000\u0000y~\u0003\u0006\u0003"+
		"\u0000z{\u0005\u0005\u0000\u0000{}\u0003\u0006\u0003\u0000|z\u0001\u0000"+
		"\u0000\u0000}\u0080\u0001\u0000\u0000\u0000~|\u0001\u0000\u0000\u0000"+
		"~\u007f\u0001\u0000\u0000\u0000\u007f\u0005\u0001\u0000\u0000\u0000\u0080"+
		"~\u0001\u0000\u0000\u0000\u0081\u0082\u0005/\u0000\u0000\u0082\u0083\u0005"+
		"\u0013\u0000\u0000\u0083\u0084\u0003R)\u0000\u0084\u0007\u0001\u0000\u0000"+
		"\u0000\u0085\u008a\u0005/\u0000\u0000\u0086\u0087\u0005\u0005\u0000\u0000"+
		"\u0087\u0089\u0005/\u0000\u0000\u0088\u0086\u0001\u0000\u0000\u0000\u0089"+
		"\u008c\u0001\u0000\u0000\u0000\u008a\u0088\u0001\u0000\u0000\u0000\u008a"+
		"\u008b\u0001\u0000\u0000\u0000\u008b\t\u0001\u0000\u0000\u0000\u008c\u008a"+
		"\u0001\u0000\u0000\u0000\u008d\u0098\u0003\f\u0006\u0000\u008e\u0098\u0003"+
		"\u000e\u0007\u0000\u008f\u0098\u0003\u0010\b\u0000\u0090\u0098\u0003\u0012"+
		"\t\u0000\u0091\u0098\u0003\u0014\n\u0000\u0092\u0098\u0003\u0018\f\u0000"+
		"\u0093\u0098\u0003\u001a\r\u0000\u0094\u0098\u0003\u001c\u000e\u0000\u0095"+
		"\u0098\u0003\u001e\u000f\u0000\u0096\u0098\u0003 \u0010\u0000\u0097\u008d"+
		"\u0001\u0000\u0000\u0000\u0097\u008e\u0001\u0000\u0000\u0000\u0097\u008f"+
		"\u0001\u0000\u0000\u0000\u0097\u0090\u0001\u0000\u0000\u0000\u0097\u0091"+
		"\u0001\u0000\u0000\u0000\u0097\u0092\u0001\u0000\u0000\u0000\u0097\u0093"+
		"\u0001\u0000\u0000\u0000\u0097\u0094\u0001\u0000\u0000\u0000\u0097\u0095"+
		"\u0001\u0000\u0000\u0000\u0097\u0096\u0001\u0000\u0000\u0000\u0098\u000b"+
		"\u0001\u0000\u0000\u0000\u0099\u009d\u0005\b\u0000\u0000\u009a\u009c\u0003"+
		"\n\u0005\u0000\u009b\u009a\u0001\u0000\u0000\u0000\u009c\u009f\u0001\u0000"+
		"\u0000\u0000\u009d\u009b\u0001\u0000\u0000\u0000\u009d\u009e\u0001\u0000"+
		"\u0000\u0000\u009e\u00a0\u0001\u0000\u0000\u0000\u009f\u009d\u0001\u0000"+
		"\u0000\u0000\u00a0\u00a1\u0005\t\u0000\u0000\u00a1\r\u0001\u0000\u0000"+
		"\u0000\u00a2\u00a8\u0005\"\u0000\u0000\u00a3\u00a5\u0005\u0001\u0000\u0000"+
		"\u00a4\u00a6\u0003\"\u0011\u0000\u00a5\u00a4\u0001\u0000\u0000\u0000\u00a5"+
		"\u00a6\u0001\u0000\u0000\u0000\u00a6\u00a7\u0001\u0000\u0000\u0000\u00a7"+
		"\u00a9\u0005\u0002\u0000\u0000\u00a8\u00a3\u0001\u0000\u0000\u0000\u00a8"+
		"\u00a9\u0001\u0000\u0000\u0000\u00a9\u00aa\u0001\u0000\u0000\u0000\u00aa"+
		"\u00ab\u0005\u0004\u0000\u0000\u00ab\u000f\u0001\u0000\u0000\u0000\u00ac"+
		"\u00ad\u0005\u001d\u0000\u0000\u00ad\u00ae\u0005\u0001\u0000\u0000\u00ae"+
		"\u00af\u0003*\u0015\u0000\u00af\u00b0\u0005\u0002\u0000\u0000\u00b0\u00b3"+
		"\u0003\n\u0005\u0000\u00b1\u00b2\u0005\u001e\u0000\u0000\u00b2\u00b4\u0003"+
		"\n\u0005\u0000\u00b3\u00b1\u0001\u0000\u0000\u0000\u00b3\u00b4\u0001\u0000"+
		"\u0000\u0000\u00b4\u0011\u0001\u0000\u0000\u0000\u00b5\u00b6\u0005\u001f"+
		"\u0000\u0000\u00b6\u00b7\u0005\u0001\u0000\u0000\u00b7\u00b8\u0003*\u0015"+
		"\u0000\u00b8\u00b9\u0005\u0002\u0000\u0000\u00b9\u00ba\u0003\n\u0005\u0000"+
		"\u00ba\u0013\u0001\u0000\u0000\u0000\u00bb\u00bc\u0005%\u0000\u0000\u00bc"+
		"\u00bd\u0003$\u0012\u0000\u00bd\u00c1\u0005\b\u0000\u0000\u00be\u00c0"+
		"\u0003\u0016\u000b\u0000\u00bf\u00be\u0001\u0000\u0000\u0000\u00c0\u00c3"+
		"\u0001\u0000\u0000\u0000\u00c1\u00bf\u0001\u0000\u0000\u0000\u00c1\u00c2"+
		"\u0001\u0000\u0000\u0000\u00c2\u00c4\u0001\u0000\u0000\u0000\u00c3\u00c1"+
		"\u0001\u0000\u0000\u0000\u00c4\u00c5\u0005\t\u0000\u0000\u00c5\u0015\u0001"+
		"\u0000\u0000\u0000\u00c6\u00c9\u0005 \u0000\u0000\u00c7\u00ca\u0005!\u0000"+
		"\u0000\u00c8\u00ca\u0003\"\u0011\u0000\u00c9\u00c7\u0001\u0000\u0000\u0000"+
		"\u00c9\u00c8\u0001\u0000\u0000\u0000\u00ca\u00cb\u0001\u0000\u0000\u0000"+
		"\u00cb\u00cf\u0005\u0003\u0000\u0000\u00cc\u00ce\u0003\n\u0005\u0000\u00cd"+
		"\u00cc\u0001\u0000\u0000\u0000\u00ce\u00d1\u0001\u0000\u0000\u0000\u00cf"+
		"\u00cd\u0001\u0000\u0000\u0000\u00cf\u00d0\u0001\u0000\u0000\u0000\u00d0"+
		"\u0017\u0001\u0000\u0000\u0000\u00d1\u00cf\u0001\u0000\u0000\u0000\u00d2"+
		"\u00d3\u0005$\u0000\u0000\u00d3\u00d4\u0005\u0013\u0000\u0000\u00d4\u00d7"+
		"\u0003R)\u0000\u00d5\u00d6\u0005\u0011\u0000\u0000\u00d6\u00d8\u0003("+
		"\u0014\u0000\u00d7\u00d5\u0001\u0000\u0000\u0000\u00d7\u00d8\u0001\u0000"+
		"\u0000\u0000\u00d8\u00d9\u0001\u0000\u0000\u0000\u00d9\u00da\u0005\u0004"+
		"\u0000\u0000\u00da\u0019\u0001\u0000\u0000\u0000\u00db\u00dc\u0005$\u0000"+
		"\u0000\u00dc\u00dd\u0005\u0013\u0000\u0000\u00dd\u00de\u0003R)\u0000\u00de"+
		"\u00df\u0003$\u0012\u0000\u00df\u00e0\u0005\u0004\u0000\u0000\u00e0\u001b"+
		"\u0001\u0000\u0000\u0000\u00e1\u00e2\u00034\u001a\u0000\u00e2\u00e3\u0005"+
		"\u0011\u0000\u0000\u00e3\u00e4\u0003\"\u0011\u0000\u00e4\u00e5\u0005\u0004"+
		"\u0000\u0000\u00e5\u001d\u0001\u0000\u0000\u0000\u00e6\u00e7\u0003(\u0014"+
		"\u0000\u00e7\u00e8\u0005\u0004\u0000\u0000\u00e8\u001f\u0001\u0000\u0000"+
		"\u0000\u00e9\u00ea\u0005\u0004\u0000\u0000\u00ea!\u0001\u0000\u0000\u0000"+
		"\u00eb\u00f0\u0003(\u0014\u0000\u00ec\u00ed\u0005\u0005\u0000\u0000\u00ed"+
		"\u00ef\u0003(\u0014\u0000\u00ee\u00ec\u0001\u0000\u0000\u0000\u00ef\u00f2"+
		"\u0001\u0000\u0000\u0000\u00f0\u00ee\u0001\u0000\u0000\u0000\u00f0\u00f1"+
		"\u0001\u0000\u0000\u0000\u00f1#\u0001\u0000\u0000\u0000\u00f2\u00f0\u0001"+
		"\u0000\u0000\u0000\u00f3\u00f4\u0005\u0001\u0000\u0000\u00f4\u00f5\u0003"+
		"(\u0014\u0000\u00f5\u00f6\u0005\u0002\u0000\u0000\u00f6%\u0001\u0000\u0000"+
		"\u0000\u00f7\u00f8\u0003(\u0014\u0000\u00f8\u00f9\u0005\u0000\u0000\u0001"+
		"\u00f9\'\u0001\u0000\u0000\u0000\u00fa\u010a\u0003$\u0012\u0000\u00fb"+
		"\u010a\u0003,\u0016\u0000\u00fc\u010a\u00030\u0018\u0000\u00fd\u010a\u0003"+
		"8\u001c\u0000\u00fe\u010a\u0003:\u001d\u0000\u00ff\u010a\u0003<\u001e"+
		"\u0000\u0100\u010a\u0003>\u001f\u0000\u0101\u010a\u0003@ \u0000\u0102"+
		"\u010a\u0003F#\u0000\u0103\u0104\u0007\u0000\u0000\u0000\u0104\u010a\u0003"+
		"6\u001b\u0000\u0105\u0106\u00036\u001b\u0000\u0106\u0107\u0007\u0000\u0000"+
		"\u0000\u0107\u010a\u0001\u0000\u0000\u0000\u0108\u010a\u0003P(\u0000\u0109"+
		"\u00fa\u0001\u0000\u0000\u0000\u0109\u00fb\u0001\u0000\u0000\u0000\u0109"+
		"\u00fc\u0001\u0000\u0000\u0000\u0109\u00fd\u0001\u0000\u0000\u0000\u0109"+
		"\u00fe\u0001\u0000\u0000\u0000\u0109\u00ff\u0001\u0000\u0000\u0000\u0109"+
		"\u0100\u0001\u0000\u0000\u0000\u0109\u0101\u0001\u0000\u0000\u0000\u0109"+
		"\u0102\u0001\u0000\u0000\u0000\u0109\u0103\u0001\u0000\u0000\u0000\u0109"+
		"\u0105\u0001\u0000\u0000\u0000\u0109\u0108\u0001\u0000\u0000\u0000\u010a"+
		")\u0001\u0000\u0000\u0000\u010b\u010c\u0006\u0015\uffff\uffff\u0000\u010c"+
		"\u010d\u0005\u0001\u0000\u0000\u010d\u010e\u0003*\u0015\u0000\u010e\u010f"+
		"\u0005\u0002\u0000\u0000\u010f\u0112\u0001\u0000\u0000\u0000\u0110\u0112"+
		"\u0003(\u0014\u0000\u0111\u010b\u0001\u0000\u0000\u0000\u0111\u0110\u0001"+
		"\u0000\u0000\u0000\u0112\u0121\u0001\u0000\u0000\u0000\u0113\u0114\n\u0005"+
		"\u0000\u0000\u0114\u0115\u0007\u0001\u0000\u0000\u0115\u0120\u0003*\u0015"+
		"\u0006\u0116\u0117\n\u0004\u0000\u0000\u0117\u0118\u0007\u0002\u0000\u0000"+
		"\u0118\u0120\u0003*\u0015\u0005\u0119\u011a\n\u0003\u0000\u0000\u011a"+
		"\u011b\u0005\u000f\u0000\u0000\u011b\u0120\u0003*\u0015\u0004\u011c\u011d"+
		"\n\u0002\u0000\u0000\u011d\u011e\u0005\u0010\u0000\u0000\u011e\u0120\u0003"+
		"*\u0015\u0003\u011f\u0113\u0001\u0000\u0000\u0000\u011f\u0116\u0001\u0000"+
		"\u0000\u0000\u011f\u0119\u0001\u0000\u0000\u0000\u011f\u011c\u0001\u0000"+
		"\u0000\u0000\u0120\u0123\u0001\u0000\u0000\u0000\u0121\u011f\u0001\u0000"+
		"\u0000\u0000\u0121\u0122\u0001\u0000\u0000\u0000\u0122+\u0001\u0000\u0000"+
		"\u0000\u0123\u0121\u0001\u0000\u0000\u0000\u0124\u0125\u0005#\u0000\u0000"+
		"\u0125\u0126\u0005\u0001\u0000\u0000\u0126\u0127\u0003.\u0017\u0000\u0127"+
		"\u0128\u0005\u0002\u0000\u0000\u0128-\u0001\u0000\u0000\u0000\u0129\u012a"+
		"\u0006\u0017\uffff\uffff\u0000\u012a\u012b\u0005\u0001\u0000\u0000\u012b"+
		"\u012c\u0003.\u0017\u0000\u012c\u012d\u0005\u0002\u0000\u0000\u012d\u0130"+
		"\u0001\u0000\u0000\u0000\u012e\u0130\u0003(\u0014\u0000\u012f\u0129\u0001"+
		"\u0000\u0000\u0000\u012f\u012e\u0001\u0000\u0000\u0000\u0130\u013f\u0001"+
		"\u0000\u0000\u0000\u0131\u0132\n\u0005\u0000\u0000\u0132\u0133\u0007\u0003"+
		"\u0000\u0000\u0133\u013e\u0003.\u0017\u0006\u0134\u0135\n\u0004\u0000"+
		"\u0000\u0135\u0136\u0007\u0004\u0000\u0000\u0136\u013e\u0003.\u0017\u0005"+
		"\u0137\u0138\n\u0003\u0000\u0000\u0138\u0139\u0005\u000f\u0000\u0000\u0139"+
		"\u013e\u0003.\u0017\u0004\u013a\u013b\n\u0002\u0000\u0000\u013b\u013c"+
		"\u0005\u0010\u0000\u0000\u013c\u013e\u0003.\u0017\u0003\u013d\u0131\u0001"+
		"\u0000\u0000\u0000\u013d\u0134\u0001\u0000\u0000\u0000\u013d\u0137\u0001"+
		"\u0000\u0000\u0000\u013d\u013a\u0001\u0000\u0000\u0000\u013e\u0141\u0001"+
		"\u0000\u0000\u0000\u013f\u013d\u0001\u0000\u0000\u0000\u013f\u0140\u0001"+
		"\u0000\u0000\u0000\u0140/\u0001\u0000\u0000\u0000\u0141\u013f\u0001\u0000"+
		"\u0000\u0000\u0142\u0143\u0003P(\u0000\u0143\u0144\u0005\f\u0000\u0000"+
		"\u0144\u0146\u0005\u0001\u0000\u0000\u0145\u0147\u0003\"\u0011\u0000\u0146"+
		"\u0145\u0001\u0000\u0000\u0000\u0146\u0147\u0001\u0000\u0000\u0000\u0147"+
		"\u0148\u0001\u0000\u0000\u0000\u0148\u0149\u0005\u0002\u0000\u0000\u0149"+
		"\u014b\u0005\u0001\u0000\u0000\u014a\u014c\u0003\"\u0011\u0000\u014b\u014a"+
		"\u0001\u0000\u0000\u0000\u014b\u014c\u0001\u0000\u0000\u0000\u014c\u014d"+
		"\u0001\u0000\u0000\u0000\u014d\u014e\u0005\u0002\u0000\u0000\u014e\u0169"+
		"\u0001\u0000\u0000\u0000\u014f\u0150\u0003P(\u0000\u0150\u0152\u0005\u0001"+
		"\u0000\u0000\u0151\u0153\u0003\"\u0011\u0000\u0152\u0151\u0001\u0000\u0000"+
		"\u0000\u0152\u0153\u0001\u0000\u0000\u0000\u0153\u0154\u0001\u0000\u0000"+
		"\u0000\u0154\u0155\u0005\u0002\u0000\u0000\u0155\u0169\u0001\u0000\u0000"+
		"\u0000\u0156\u0157\u0005\u0015\u0000\u0000\u0157\u015d\u0003P(\u0000\u0158"+
		"\u015a\u0005\u0001\u0000\u0000\u0159\u015b\u0003\"\u0011\u0000\u015a\u0159"+
		"\u0001\u0000\u0000\u0000\u015a\u015b\u0001\u0000\u0000\u0000\u015b\u015c"+
		"\u0001\u0000\u0000\u0000\u015c\u015e\u0005\u0002\u0000\u0000\u015d\u0158"+
		"\u0001\u0000\u0000\u0000\u015d\u015e\u0001\u0000\u0000\u0000\u015e\u0169"+
		"\u0001\u0000\u0000\u0000\u015f\u0160\u0005\u0016\u0000\u0000\u0160\u0166"+
		"\u0003P(\u0000\u0161\u0163\u0005\u0001\u0000\u0000\u0162\u0164\u0003\""+
		"\u0011\u0000\u0163\u0162\u0001\u0000\u0000\u0000\u0163\u0164\u0001\u0000"+
		"\u0000\u0000\u0164\u0165\u0001\u0000\u0000\u0000\u0165\u0167\u0005\u0002"+
		"\u0000\u0000\u0166\u0161\u0001\u0000\u0000\u0000\u0166\u0167\u0001\u0000"+
		"\u0000\u0000\u0167\u0169\u0001\u0000\u0000\u0000\u0168\u0142\u0001\u0000"+
		"\u0000\u0000\u0168\u014f\u0001\u0000\u0000\u0000\u0168\u0156\u0001\u0000"+
		"\u0000\u0000\u0168\u015f\u0001\u0000\u0000\u0000\u01691\u0001\u0000\u0000"+
		"\u0000\u016a\u0170\u0003P(\u0000\u016b\u016d\u0005\u0001\u0000\u0000\u016c"+
		"\u016e\u0003\"\u0011\u0000\u016d\u016c\u0001\u0000\u0000\u0000\u016d\u016e"+
		"\u0001\u0000\u0000\u0000\u016e\u016f\u0001\u0000\u0000\u0000\u016f\u0171"+
		"\u0005\u0002\u0000\u0000\u0170\u016b\u0001\u0000\u0000\u0000\u0170\u0171"+
		"\u0001\u0000\u0000\u0000\u0171\u0177\u0001\u0000\u0000\u0000\u0172\u0174"+
		"\u0005\b\u0000\u0000\u0173\u0175\u0003\"\u0011\u0000\u0174\u0173\u0001"+
		"\u0000\u0000\u0000\u0174\u0175\u0001\u0000\u0000\u0000\u0175\u0176\u0001"+
		"\u0000\u0000\u0000\u0176\u0178\u0005\t\u0000\u0000\u0177\u0172\u0001\u0000"+
		"\u0000\u0000\u0177\u0178\u0001\u0000\u0000\u0000\u0178\u0179\u0001\u0000"+
		"\u0000\u0000\u0179\u017a\u0005\u0000\u0000\u0001\u017a3\u0001\u0000\u0000"+
		"\u0000\u017b\u0180\u00036\u001b\u0000\u017c\u017d\u0005\u0005\u0000\u0000"+
		"\u017d\u017f\u00036\u001b\u0000\u017e\u017c\u0001\u0000\u0000\u0000\u017f"+
		"\u0182\u0001\u0000\u0000\u0000\u0180\u017e\u0001\u0000\u0000\u0000\u0180"+
		"\u0181\u0001\u0000\u0000\u0000\u01815\u0001\u0000\u0000\u0000\u0182\u0180"+
		"\u0001\u0000\u0000\u0000\u0183\u0187\u00038\u001c\u0000\u0184\u0187\u0003"+
		":\u001d\u0000\u0185\u0187\u0003<\u001e\u0000\u0186\u0183\u0001\u0000\u0000"+
		"\u0000\u0186\u0184\u0001\u0000\u0000\u0000\u0186\u0185\u0001\u0000\u0000"+
		"\u0000\u01877\u0001\u0000\u0000\u0000\u0188\u0189\u0005\u0013\u0000\u0000"+
		"\u0189\u018a\u0003R)\u0000\u018a9\u0001\u0000\u0000\u0000\u018b\u018c"+
		"\u0005\u0013\u0000\u0000\u018c\u018d\u0003R)\u0000\u018d\u018e\u0003$"+
		"\u0012\u0000\u018e;\u0001\u0000\u0000\u0000\u018f\u0190\u0005\u000e\u0000"+
		"\u0000\u0190\u0191\u0003R)\u0000\u0191=\u0001\u0000\u0000\u0000\u0192"+
		"\u0193\u0005\u0014\u0000\u0000\u0193\u0194\u0003R)\u0000\u0194?\u0001"+
		"\u0000\u0000\u0000\u0195\u019d\u0005&\u0000\u0000\u0196\u019d\u0005\'"+
		"\u0000\u0000\u0197\u019d\u0005(\u0000\u0000\u0198\u019d\u0005)\u0000\u0000"+
		"\u0199\u019d\u0005*\u0000\u0000\u019a\u019d\u0005+\u0000\u0000\u019b\u019d"+
		"\u0003B!\u0000\u019c\u0195\u0001\u0000\u0000\u0000\u019c\u0196\u0001\u0000"+
		"\u0000\u0000\u019c\u0197\u0001\u0000\u0000\u0000\u019c\u0198\u0001\u0000"+
		"\u0000\u0000\u019c\u0199\u0001\u0000\u0000\u0000\u019c\u019a\u0001\u0000"+
		"\u0000\u0000\u019c\u019b\u0001\u0000\u0000\u0000\u019dA\u0001\u0000\u0000"+
		"\u0000\u019e\u01a2\u0005.\u0000\u0000\u019f\u01a1\u0003D\"\u0000\u01a0"+
		"\u019f\u0001\u0000\u0000\u0000\u01a1\u01a4\u0001\u0000\u0000\u0000\u01a2"+
		"\u01a0\u0001\u0000\u0000\u0000\u01a2\u01a3\u0001\u0000\u0000\u0000\u01a3"+
		"\u01a5\u0001\u0000\u0000\u0000\u01a4\u01a2\u0001\u0000\u0000\u0000\u01a5"+
		"\u01a6\u00051\u0000\u0000\u01a6C\u0001\u0000\u0000\u0000\u01a7\u01a8\u0005"+
		"2\u0000\u0000\u01a8E\u0001\u0000\u0000\u0000\u01a9\u01b1\u0005.\u0000"+
		"\u0000\u01aa\u01b0\u0003D\"\u0000\u01ab\u01b0\u0003H$\u0000\u01ac\u01b0"+
		"\u0003J%\u0000\u01ad\u01b0\u0003L&\u0000\u01ae\u01b0\u0003N\'\u0000\u01af"+
		"\u01aa\u0001\u0000\u0000\u0000\u01af\u01ab\u0001\u0000\u0000\u0000\u01af"+
		"\u01ac\u0001\u0000\u0000\u0000\u01af\u01ad\u0001\u0000\u0000\u0000\u01af"+
		"\u01ae\u0001\u0000\u0000\u0000\u01b0\u01b3\u0001\u0000\u0000\u0000\u01b1"+
		"\u01af\u0001\u0000\u0000\u0000\u01b1\u01b2\u0001\u0000\u0000\u0000\u01b2"+
		"\u01b4\u0001\u0000\u0000\u0000\u01b3\u01b1\u0001\u0000\u0000\u0000\u01b4"+
		"\u01b5\u00051\u0000\u0000\u01b5G\u0001\u0000\u0000\u0000\u01b6\u01b7\u0007"+
		"\u0005\u0000\u0000\u01b7I\u0001\u0000\u0000\u0000\u01b8\u01b9\u00056\u0000"+
		"\u0000\u01b9K\u0001\u0000\u0000\u0000\u01ba\u01bb\u00059\u0000\u0000\u01bb"+
		"M\u0001\u0000\u0000\u0000\u01bc\u01bd\u00057\u0000\u0000\u01bd\u01be\u0003"+
		"(\u0014\u0000\u01be\u01bf\u00058\u0000\u0000\u01bfO\u0001\u0000\u0000"+
		"\u0000\u01c0\u01c1\u0007\u0006\u0000\u0000\u01c1Q\u0001\u0000\u0000\u0000"+
		"\u01c2\u01ca\u0003P(\u0000\u01c3\u01ca\u0005&\u0000\u0000\u01c4\u01ca"+
		"\u0005\u001d\u0000\u0000\u01c5\u01ca\u0005\u001e\u0000\u0000\u01c6\u01ca"+
		"\u0005\u001f\u0000\u0000\u01c7\u01ca\u0005\"\u0000\u0000\u01c8\u01ca\u0005"+
		"#\u0000\u0000\u01c9\u01c2\u0001\u0000\u0000\u0000\u01c9\u01c3\u0001\u0000"+
		"\u0000\u0000\u01c9\u01c4\u0001\u0000\u0000\u0000\u01c9\u01c5\u0001\u0000"+
		"\u0000\u0000\u01c9\u01c6\u0001\u0000\u0000\u0000\u01c9\u01c7\u0001\u0000"+
		"\u0000\u0000\u01c9\u01c8\u0001\u0000\u0000\u0000\u01caS\u0001\u0000\u0000"+
		"\u0000-Wafloqv~\u008a\u0097\u009d\u00a5\u00a8\u00b3\u00c1\u00c9\u00cf"+
		"\u00d7\u00f0\u0109\u0111\u011f\u0121\u012f\u013d\u013f\u0146\u014b\u0152"+
		"\u015a\u015d\u0163\u0166\u0168\u016d\u0170\u0174\u0177\u0180\u0186\u019c"+
		"\u01a2\u01af\u01b1\u01c9";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}